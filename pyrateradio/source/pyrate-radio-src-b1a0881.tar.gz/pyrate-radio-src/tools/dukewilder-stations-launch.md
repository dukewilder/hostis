# dukewilder: the launch stations pass

Paste this to the Claude on dukewilder. It fills HOSTIS's own stations on the harbour (pyrate-lantern) for launch and raises three new ones: Drift, Concert Hall and Brass. Shanties becomes shanties and sea songs alone, and its band records move to Brass. The Numbers and the other two Lanterns are left alone.

---

Work through the steps in order and report at the end.

## Rules

- Everything that reaches the internet goes through the harbour's VPN network: the git fetch and every download below. No published ports, no router changes.
- Do not touch Jellyfin, the arr stack, Monero, the main gluetun, pyrate-hold, pyrate-releases or pyrate-tunnel.
- Delete nothing. Replaced files move into a `<station>-retired` folder beside the seed folder. Ask Dylan before deleting anything, those folders included.
- Never print a WireGuard key, a Tor secret, or any Lantern's `hold.key`, `node.key`, `seed.key`, `keys/` files or words file. Never run the Lantern with `--words`. Report paths, never contents.

## 1. Before changing anything

1. Fetch the latest commit of branch `content-launch` through the tunnel, the same way as the last rebuild. If Dylan says it has been merged, fetch `radio` instead.
2. Confirm the harbour's binary knows `--reseed`:
   ```
   docker run --rm --network none pyrate-lantern:latest --no-such-flag
   ```
   If `--reseed` is not in the list, stop and report.
3. From `docker inspect pyrate-lantern`, note:
   - every `--seed "Name|About|/folder|kind"` argument, in order, and the host folder behind each `/folder`;
   - the parent host folder that holds the seed folders (`<seed parent>` below);
   - the network mode, from `docker inspect -f '{{.HostConfig.NetworkMode}}' pyrate-lantern`;
   - the user the container runs as.
4. Run `df -h` on the disk that holds `<seed parent>` and on the disk that holds the harbour's data folder. This pass needs about 18 GB free on the first and 7 GB on the second. If either has less, stop and report.
5. In The Public Domain's seed folder, look for any audio file whose title (the part of its name after ` - `) is exactly `Farewell Blues`, `The Wabash Blues`, `Milenberg Joys` or `George M. Cohan Medley`. Report what you find. The Lantern skips a new recording whose title its station already has, so step 3.6 renames the new one if there is a clash.
6. Note the harbour's last `in the Log` line and its station count.

## 2. Fetch the new recordings, while the harbour runs

The station kits are in `<checkout>/radio/stations/` and the manifests in `<checkout>/radio/tools/stations/`. Every fetch below runs the same way, through the harbour's network, with the manifest and folder named in the table:

```
docker run --rm --network <harbour network mode> \
  -v <checkout>/radio/tools/stations:/t:ro -v <host folder>:/out \
  python:3.12-slim python /t/fetch.py /t/<manifest> /out
```

Each checks every file against its archive.org SHA-1, keeps files already there and whole, and ends with `N recordings in /out, 0 failed`. Run any one again if something failed: it fetches only what is missing.

1. **The new stations.** Copy `<checkout>/radio/stations/drift`, `concert-hall` and `brass` into `<seed parent>`, keeping their names. No seed points at them yet, so fetch straight into them.
2. **Readings and Contraband** play their books in order, in the order their files were set, so the running harbour must not see their new files arrive a few at a time. Fetch them into folders beside their seed folders:
   - Readings: fetch into a new, empty `<seed parent>/readings-new`.
   - Contraband: first make `<seed parent>/contraband-new` as hard links of the Contraband seed folder, so its 68 recordings are not fetched again and take no space: `cp -al <seed parent>/contraband <seed parent>/contraband-new`. Then fetch into `contraband-new`.
3. **Netlabel, Poets' Corner and The Public Domain** shuffle, so fetch straight into their seed folders. The harbour sets what arrives at its next scan.

| Station | Manifest | Host folder | Ends with | Adds |
|---|---|---|---|---|
| Drift | `drift.json` | `<seed parent>/drift` | `348 recordings` | 3.5 GB |
| Concert Hall | `concert-hall.json` | `<seed parent>/concert-hall` | `177 recordings` | 0.9 GB |
| Brass | `brass.json` | `<seed parent>/brass` | `126 recordings` | 0.7 GB |
| Readings | `readings.json` | `<seed parent>/readings-new` | `343 recordings` | 3.8 GB |
| Contraband | `contraband.json` | `<seed parent>/contraband-new` | `357 recordings` | 4.1 GB |
| Netlabel | `netlabel.json` | Netlabel's seed folder | `370 recordings` | 2.6 GB |
| Poets' Corner | `poets.json` | Poets' Corner's seed folder | `221 recordings` | 60 MB |
| The Public Domain | `public-domain.json` | its seed folder | `4 recordings` | 30 MB |

Concert Hall's Musopen recordings arrive as `.flac`, which the Lantern reads. Make sure the harbour's user can read every new file.

## 3. Stop the harbour and rearrange the folders

Stop pyrate-lantern (`docker compose stop pyrate-lantern`, or however it was started). Then, with the harbour stopped:

1. **Shanties.** Its marches and band records leave, and four field recordings that are not sea songs retire. This moves them, with their `.source.txt` files, and prints only counts:
   ```
   docker run --rm --network none \
     -v <checkout>/radio/tools/stations:/t:ro -v <seed parent>:/p \
     python:3.12-slim python /t/tidy.py /t/shanties.json /p/shanties /p/shanties-retired
   ```
   It should end `0 renamed, 24 moved to /p/shanties-retired, 99 of 99 in place`. Use Shanties' own seed folder if it is not called `shanties`. The band records among them are already in `brass`, fetched in step 2.
2. **Readings.** Move every file from `readings-new` into Readings' seed folder. Overwrite nothing (`mv -n`). `readings-new` should then be empty.
3. **Contraband.** Move every file from `contraband-new` into Contraband's seed folder without overwriting (`mv -n`). What stays behind in `contraband-new` is the hard-linked copy of the 68 recordings already there, which takes no space. Leave it, and report its file count.
4. **The kits.** Copy these files from `<checkout>/radio/stations/<station>/` into each station's seed folder. Where a file of the same name is already there, move the old one into that station's `-retired` folder first.

   | Station | Files |
   |---|---|
   | Netlabel | `programme.json` |
   | Shanties | `notices.txt` |
   | Contraband | `notices.txt` |
   | The Public Domain | `notices.txt` |

   Drift, Concert Hall and Brass already have their `bell.ogg`, `programme.json` and `notices.txt` from step 2.1. Their covers are still to be drawn, so they go up without art for now.
5. Make sure the harbour's user can read every file in every seed folder.
6. If step 1.5 found a clash, rename the new Public Domain file and its `.source.txt` from `U.S. Air Force Band - <title>` to `U.S. Air Force Band - <title> (U.S. Air Force Band)`, and report it.

## 4. Start the harbour with the new seeds

Edit only the harbour's compose entry, and only these arguments. Keep every other argument, environment value, mount and the order of the existing seeds exactly as they are. Use each seed's existing folder path, as the container sees it, and keep any home port a seed already carries as a fifth field.

1. Three seeds get new words:
   ```
   --seed "Readings|Johnson's General History of the Pyrates, Treasure Island, Captain Blood, Moby-Dick and more of the sea, read aloud chapter by chapter.|<its path>|talk"
   --seed "Shanties|Shanties, sea songs and pirate songs off 78s and field recordings, every one free to air.|<its path>|mono"
   --seed "Contraband|Books that kings, censors and courts tried to stop, read aloud round the clock. Milton, Paine, Douglass, Whitman, Wilde, Joyce, Lawrence.|<its path>|talk/explicit"
   ```
   Keep Shanties' kind as it is now if it is already `mono`. Contraband's kind gains `/explicit`: it carries Lady Chatterley's Lover and others once tried for obscenity, so it marks itself explicit and stays off the open dial until a listener asks for explicit stations. The Lantern sets this on the next start even though the station already exists; expect a `rating set` line for it.
2. Add three seeds after the last:
   ```
   --seed "Drift|Long ambient, drone and piano for work and sleep, from musicians who set it free under Creative Commons.|<path>/drift|music"
   --seed "Concert Hall|Bach, Chopin, Beethoven and more, in modern recordings free for anyone to play.|<path>/concert-hall|music"
   --seed "Brass|Sousa's marches to 1926 by the Marine Band, with the bands of the Navy, Army and Air Force.|<path>/brass|music"
   ```
3. For this one start only, add `--reseed "Shanties"`. It sets the 99 recordings in the folder again and withdraws every old one, so the 24 that left go off the clock while the station stays on the air.
4. Bring the harbour up and follow `docker logs -f pyrate-lantern`. Setting this much takes hours; Contraband and Readings are the slow ones. Expect, for each station:
   - **Netlabel:** 283 `set` lines, then `programme set`.
   - **Poets' Corner:** 47 `set` lines.
   - **The Public Domain:** 4 `set` lines and `notice up`.
   - **Readings:** `colours set` and 343 `set` lines.
   - **Shanties:** `colours set` if its words changed, `reseeding Shanties: N ...` (N is about 123), 99 `set` lines, then `reseeded Shanties: N old recordings withdrawn, 0 kept`, and a `notice taken down` and `notice up`.
   - **Contraband:** `colours set`, 289 `set` lines, one `notice taken down` and two `notice up`.
   - **Drift, Concert Hall and Brass:** each raised new, with `kinds set`, a `set` line for each recording (348, 177 and 126), `the bell is set`, `programme set` and its notices up (one, one and two).

   If Shanties reports any number other than `0 kept`, stop and report the line. Report any `could not set` line and any `programme.json names a recording not on the clock` line. It is done when the minute lines show `in the Log` again and no more `set` lines arrive.
5. Take `--reseed "Shanties"` out and recreate the harbour once more. It prints one `station <name>: <id>` line for each seeded station. Report them all. The ids of Drift, Concert Hall and Brass are new, and Dylan puts them into the app and the site. A station id is public; its words are not, and stay where the Lantern keeps them.

## 5. Check

- `docker ps` shows the three Lanterns up, with no published ports.
- The harbour's station count in `in the Log` is three more than in step 1.
- GET https://relay.hostis.black/ping answers 200, and two minutes after the last restart the harbour's pkarr record still lists https://relay.hostis.black/.
- The memory of the harbour after ten minutes, and the size of its data folder before step 4 and now.
- `df -h` on both disks again.
- No line containing `panicked` or `error` in the harbour's log since step 4.

## Report

- The `--no-such-flag` output line that lists the flags.
- The free space from steps 1 and 5, and what step 1.5 found.
- The last line of each `fetch.py` run and of the `tidy.py` run.
- The `reseeding` and `reseeded` lines, and any line step 4 says to report.
- All `station <name>: <id>` lines.
- The checks in step 5.
- The sizes of `shanties-retired`, `readings-new` and `contraband-new`, and a question to Dylan: may they be deleted? Delete nothing until he says yes.
- Anything that did not go as written.
