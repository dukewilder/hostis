# Light a Lantern

A Lantern is a node that never sleeps. It carries every station it hears of, relays for phones that cannot reach each other, and keeps the network findable. Every Lantern is another full copy of every station.

**With Docker** (any Linux machine, a Raspberry Pi, a VPS):

    git clone --depth 1 --branch radio https://github.com/dukewilder/hostis
    docker build -t pyrate-lantern -f hostis/radio/Dockerfile hostis/radio
    docker run -d --name lantern --restart unless-stopped -v pyrate:/data \
      -v /media/usb/pyrate:/pass:ro -e PYRATE_HOLD_PASS_FILE=/pass/hold-pass pyrate-lantern

First put a passphrase of twelve characters or more in `hold-pass` on a USB stick or another disk (four or five random words make a good one). The Lantern seals everything it keeps under it, and without it the Lantern opens nothing and starts nothing. Take the stick out and the box stays shut at its next start. Lose the passphrase and everything the Lantern kept is lost with it.

It opens no ports and needs none. Behind a VPN it works the same, through the relays.

**Dark, beside Tor, in one command.** On any Linux machine with Docker (or a Debian or Ubuntu one without), from a checkout or on its own:

    curl -fsSL https://raw.githubusercontent.com/dukewilder/hostis/radio/radio/lantern-dark/install.sh -o dark.sh && bash dark.sh

It asks for the passphrase once, unseen, keeps it in `lantern-dark/hold-pass` where only root reads it (or in the file `PYRATE_HOLD_PASS_PATH` names, such as one on a USB stick), and starts Tor and a Lantern side by side with `docker compose`. The Lantern sits on a network whose only way out is Tor, runs dark (relays only, through Tor's tunnel, no address published, nothing in the DHT), carries every station blind and keeps each log under a megabyte. No port is published. A dark Lantern holds, backs up and passes on sealed sound for the network, reached only through relays, so it serves fewer listeners than an open one. Run the command again to update.

**A relay beside it, on a server.** A browser cannot open ports, so every browser listener reaches the network through a relay, and each new relay is one more door. On a fresh Debian or Ubuntu server, as root:

    curl -fsSL https://raw.githubusercontent.com/dukewilder/hostis/radio/radio/tools/vps/install.sh -o pyrate.sh && bash pyrate.sh

It asks for the relay's name (an A record pointing at the server, grey cloud if it is on Cloudflare), or makes a free one from the server's address, and for the Lantern's passphrase, once and unseen. It installs iroh-relay at the iroh version the radio is built with, checked against its checksum, with its own Let's Encrypt certificate; runs the Lantern above with `PYRATE_RELAY_URL` set to the relay and restarts both on boot; and lets in only SSH, 80, 443 and 7842/udp. It prints the relay's address and the Lantern's id. Run it again to update. The passphrase is kept in `/etc/pyrate/hold-pass`, readable by root alone, and is never printed. A rented server's disk is its provider's to read, so for more than that, copy the file somewhere safe once the Lantern is up and delete it from the server: the Lantern keeps running, and asks for the file back at its next start. A server installed before 0.9.20 kept its hold key in the clear; the first run of the new install seals it under the passphrase and removes the plain file.

**How a new relay is found.** A Lantern homes on the relay it reaches fastest, and on the same server that is its own. Every couple of minutes it signs a harbour note naming that relay, and publishes the same to number0's lookup. Phones, computers and browser tabs that know the Lantern as a carrier take the note into their address book and reach it through that relay. Make the Lantern a first door (`id@https://relay/` in the app's harbour list) and the app takes its relay as one of its own for next time.

**How a node finds the network.** No one box is in charge. A node starts from the peers it met before, the peers named in links it was handed, the network's own address book and its first doors, HOSTIS's harbours among them. If none of those answers, it fetches a seed list of volunteers' Lanterns from any of several mirrors, signed by two of the three release keys (a list with one signature is refused), and then looks in the mainline BitTorrent DHT. A Lantern that does not run dark leaves a signed note there every half hour naming its id and its relay, and nothing else; `PYRATE_DHT=0` stops it. Phones and the app on a computer only look up, and only when nothing else answers; a node running dark never touches the DHT. Start a Lantern with `--release-keys` (the image does) and it takes seed lists too. To offer your Lantern to a seed list, send its `id@relay` line (`lantern --dir <data> --id` prints the id) to whoever holds a release key; they write the list with `release seeds` and two of them sign it.

**Its keys.** Everything a Lantern keeps is sealed under its hold key, and the hold key is sealed under your passphrase in `hold.sealed` (Argon2id, about a second a guess), so the disk alone opens nothing. The Lantern takes the passphrase from the first of these it finds.
- `--hold-pass-fd 3`, with `3< /media/usb/pyrate/hold-pass` after it, a file descriptor;
- `PYRATE_HOLD_PASS_FILE`, a file, best on a removable disk or in a secrets store such as Docker's (`/run/secrets/...`) or systemd's (`LoadCredential=`);
- `PYRATE_HOLD_PASS_CMD`, a command that prints it, such as `secret-tool lookup service pyrate-hold` for a desktop keyring or `security find-generic-password -w -s pyrate-hold` on a Mac;
- the terminal, where it asks, unseen (twice the first time).

Without it the Lantern opens nothing, starts nothing and says so. A wrong one opens nothing and changes nothing. The first start with a passphrase seals an older Lantern's `hold.key`, beside the data or where `PYRATE_HOLD_KEY` named it, and removes the plain file. To keep the key on disk in the clear instead, start with `--hold-key-on-disk`, and the Lantern warns at every start that whoever takes that disk opens everything. `--scuttle` destroys the key, sealed or plain, and everything kept becomes noise. Never print or share the passphrase or a `hold.key`. `python3 tools/test/lantern_disk.py <data folder>` checks that nothing in the folder lies in the clear but signed releases and your `maroon.txt`.

**What it carries for others.** Logs carried for other stations share 1 GB, no station more than 256 MB; a station that outgrows its share is taken no further for a week, and when the whole is full the newest station nobody has listened to through this Lantern in a day goes first. Your own stations are never counted. Set the total with `-e PYRATE_LOG_MB=<megabytes>` (16 or more); one station may then take half of it. Once a minute the Lantern hands memory it has finished with back to the system.

**Its log.** Docker keeps a Lantern's log on disk in the clear, so the log gives counts and your own stations and names no carried station, no peer and not the Lantern's own id. Start with `--show-ids` to see those, for a test or to find the id. `-e PYRATE_QUIET=1` stops nearly everything.

**Your own stations on your own site.** Add `--http 127.0.0.1:8080` and `--seed "Name|About|/folder|music"` (or `talk`, or `mono` for old records and anything else recorded in one channel: half the bytes of stereo; to move a seeded station to another kind, start once with `--reseed "Name"`: every recording in the folder is set again, and once they are on the clock the old ones are withdrawn, along with any whose file has left the folder), then put a web server or tunnel in front of port 8080. The page plays your Lantern's stations and nothing else, and any page can embed a station with one `<audio>` tag. The page and its streams are ordinary web: whoever runs the Lantern, and any proxy or tunnel in front of it, can see a listener's address beside the station played, and the page says so. Keep no access logs if you would rather not hold that. Podcast feeds name the address the page was reached at: set `-e PYRATE_PUBLIC_URL=https://your.address` to fix it, or `-e PYRATE_TRUST_PROXY=1` if a proxy in front sets `X-Forwarded-Host`. Without either, the Lantern trusts only the request's own Host.

**Quota.** `--quota-gb` caps what it carries. Fifty gigabytes holds about 1,700 hours of music.

**Art.** Put `station.jpg` (the cover) and `banner.jpg` in a seed folder and the Lantern raises them as the station's art within ten minutes. A `cover.jpg` beside recordings, or an album cover inside them, shows while they play. Change a picture by replacing the file.

**What a Lantern carries.** Every station in the Log, by default. Put a station's id on a line of `maroon.txt` in the data folder (a `#` and a note after it if you like) and this Lantern drops it, art and log included, within a minute. Lists other people share are in the same form. Start with `--carry-own` to carry only your own stations.

It carries them blind. A Lantern answers no clear request for a station it carries, says nothing of carrying it, ends no phone's stem for it, serves it on no web page or feed and passes its sound on only sealed, by name. Your own stations are open. Name others to keep open with `--open`, followed by a station id, a file of ids (such as HOSTIS's list, `browser/harbour.json`) or `all`. A Lantern kept open for every station helps phones' stations onto the network, and anyone can see that it carries them.

**The bell.** A `bell.wav` (or .mp3, .ogg) in a seed folder plays on the hour. Replace the file and the new one takes over; the old one is withdrawn. `tools/bell.py` writes a daily one from the Annals; run it from cron each morning.

**Podcasts.** `tools/feed2folder.py <feed url> <seed folder>` brings your own show's episodes into a seed folder, and the Lantern puts them on the clock. Going the other way, `/feed/<station id>.xml` on the web listener is the station's own podcast feed, newest recording first, so any podcast app can follow it. Episodes are made into MP3s the first time they are asked for, and kept sealed under the hold key.

**The programme.** A `programme.json` in a seed folder is the station's programme, in the same form the app writes, and the Lantern sets it whenever the file changes. Times are the folder's own: give `"utc_offset_min"` (-360 for Chicago in winter). Name recordings by title, by "Artist - Title", or by file name.

    {
      "utc_offset_min": -360,
      "mode": { "kind": "daily", "start_min": 0 },
      "hours": [ { "days": 127, "start_min": 1080, "len_min": 360 } ],
      "slots": [
        { "title": "The Evening Watch", "about": "Low to high as the light goes.",
          "span": { "days": 31, "start_min": 1140, "len_min": 30 },
          "fill": { "kind": "tracks", "tracks": ["Low Tone", "Tester - Mid Tone"], "shuffle": false } },
        { "title": "Night Call", "span": { "days": 127, "start_min": 1290, "len_min": 60 },
          "fill": { "kind": "library" }, "live": true }
      ]
    }

Modes are `shuffle`, `in_order`, `newest_first`, `daily` and `weekly` (with `"day"`, 0 for Monday). Days are a sum: Monday 1, Tuesday 2, Wednesday 4, Thursday 8, Friday 16, Saturday 32, Sunday 64; 127 is every day. Minutes count from midnight, so 1080 is six in the evening. A slot's fill is `library`, `tracks`, `newest` (with `"count"`) or `hand` (with a hand's `"key"`). Leave out `hours` for round the clock. The bell keeps ringing unless the file names an `"ident"`.

**Notices.** A `notices.txt` in a seed folder holds the station's notices, one paragraph each. A new paragraph goes up on the station's page; delete it and the notice comes down. Notices posted from a phone are left alone.

**The open player.** A Lantern at a name of its own can serve the open player, the browser radio that plays every station and raises new ones, at `/listen/`. The image carries a copy (built here, or the one the app names, fetched from IPFS and checked block by block): run it with `-p 8080:8080` and `--http 0.0.0.0:8080 --player /usr/share/pyrate/player` after the image name. Outside Docker, `python3 tools/open_player.py --dir <folder>` makes the folder and `--player <folder>` serves it. The old `/player/` address sends visitors on to `/listen/`. Every Lantern that serves it is one more copy no takedown of any one site can close; the rented-server install (`tools/vps/install.sh`) serves it over HTTPS and prints its address. A Lantern at a HOSTIS name never serves it: hostis.black carries HOSTIS's stations alone. Any IPFS node can keep the player alive too, with `pin_player.sh`, hourly from cron.
