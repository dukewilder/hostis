//! Pyrate Radio in a browser tab.
//!
//! A tab is a full listener on the network. It joins the Log by gossip, checks every card
//! and every entry against the station's key, works out what is on from the station's own
//! clock, and fetches six-second chunks by their fingerprints from whoever carries them.
//! A browser cannot open its own ports, so everything goes through relays: the stations a
//! tab hears from never learn its address, and the relay sees only sealed traffic.
//!
//! What a tab holds lives in memory and goes when the tab closes. While it is open, it
//! answers other nodes for the chunks and logs it has.
//!
//! No rights reserved.

use std::{
    collections::{HashMap, HashSet, VecDeque},
    sync::{Arc, Mutex},
};

use anyhow::{Result, anyhow};
use iroh::{
    Endpoint, EndpointId, SecretKey,
    endpoint::{Connection, presets},
    protocol::{AcceptError, ProtocolHandler, Router},
};
use iroh_gossip::{
    api::{Event, GossipSender},
    net::{GOSSIP_ALPN, Gossip as GossipNet},
    proto::TopicId,
};
use n0_future::{
    StreamExt,
    task::spawn,
    time::{Duration, sleep, timeout},
};
use pyrate_core::{Archive, Body, Hash, SignedEntry, StationId, clock::Clock};
use serde_json::{Value, json};
use wasm_bindgen::prelude::*;

#[path = "../../node/src/net.rs"]
#[allow(dead_code)]
mod net;
use net::{ALPN, Announce, Gossip, MAX_FRAME, Request, Response, Sketch};

/// The same relays the app uses: number0's, and the crew's own.
const CREW_RELAYS: &[&str] = &["https://relay.hostis.black"];

/// number0's address lookup, asked only about the harbours this tab was built with. A tab that
/// asked it about every carrier would tell number0 which stations it was after. Every other
/// peer is found in the network's own book of signed notes.
#[derive(Debug)]
struct DoorsOnly(Arc<HashSet<EndpointId>>);
#[derive(Debug)]
struct DoorsLookup<T>(T, Arc<HashSet<EndpointId>>);
impl<T: iroh::address_lookup::AddressLookup> iroh::address_lookup::AddressLookup for DoorsLookup<T> {
    fn resolve(&self, id: EndpointId) -> Option<n0_future::boxed::BoxStream<Result<iroh::address_lookup::Item, iroh::address_lookup::Error>>> {
        if self.1.contains(&id) { self.0.resolve(id) } else { None }
    }
}
impl iroh::address_lookup::AddressLookupBuilder for DoorsOnly {
    fn into_address_lookup(self, ep: &Endpoint) -> std::result::Result<impl iroh::address_lookup::AddressLookup, iroh::address_lookup::AddressLookupBuilderError> {
        Ok(DoorsLookup(iroh::address_lookup::AddressLookupBuilder::into_address_lookup(iroh::address_lookup::PkarrResolver::n0_dns(), ep)?, self.0))
    }
}
/// How long a card that says live is believed: a keeper on the air sends a fresh one every few
/// chunks, so a card older than this is from a show that has ended.
const LIVE_CARD_MS: u64 = 2 * 60_000;

/// Chunks kept in memory: about forty minutes of music.
const HOLD_BYTES: usize = 24 * 1024 * 1024;

/// The tab's own notes, kept out of the console unless the page is opened with `?debug`:
/// they name this visit's node and the stations it syncs, which nothing else on the
/// machine needs to read.
fn say(msg: &str) {
    static ON: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    let on = *ON.get_or_init(|| web_sys::window().and_then(|w| w.location().search().ok()).is_some_and(|q| q.contains("debug")));
    if on {
        static T0: std::sync::OnceLock<f64> = std::sync::OnceLock::new();
        let t = js_sys::Date::now() - *T0.get_or_init(js_sys::Date::now);
        web_sys::console::log_1(&format!("pyrate {:>7.2}: {msg}", t / 1000.0).into());
    }
}

fn hex(b: &[u8]) -> String {
    b.iter().map(|x| format!("{x:02x}")).collect()
}

fn unhex32(s: &str) -> Result<[u8; 32]> {
    pyrate_core::unhex32(s).ok_or_else(|| anyhow!("not a 64-character id"))
}

fn js(e: anyhow::Error) -> JsValue {
    JsValue::from_str(&e.to_string())
}

#[derive(Default)]
struct Listing {
    announce: Option<Announce>,
    carriers: HashMap<[u8; 32], (u64, u64)>,
    /// Listeners' decks for this station, by deck key, reached only in three hops.
    decks: HashMap<[u8; 32], net::DeckNote>,
    sketches: HashMap<u64, Sketch>,
    heard: HashMap<u64, HashSet<[u8; 32]>>,
}

impl Listing {
    fn fresh(&self, now: u64) -> bool {
        self.announce.as_ref().is_some_and(|a| now.saturating_sub(a.at_ms) < 15 * 60_000)
            || self.carriers.values().any(|(_, seen)| now.saturating_sub(*seen) < 10 * 60_000)
    }

    fn aboard(&self, now: u64) -> u64 {
        let hour = now / 3_600_000;
        let mut s = self.sketches.get(&hour).cloned().unwrap_or_default();
        if now % 3_600_000 < 10 * 60_000 {
            if let Some(p) = self.sketches.get(&(hour.saturating_sub(1))) {
                s.merge(&p.0);
            }
        }
        net::round_aboard(s.estimate())
    }
}

/// A private route's hop, as the nodes read it: forward a sealed request, or open one. The
/// variants and their order are the node's (`node/src/hop.rs`); a tab only ever sends these two.
#[derive(serde::Serialize, serde::Deserialize)]
enum Hop {
    Forward { next: [u8; 32], blob: Vec<u8> },
    Sealed { eph: [u8; 32], ct: Vec<u8> },
    /// A station's entries and chunks on the stem: the tab broadcasts as a phone does, never
    /// showing the network its own station first. `hops` is always zero.
    Stem { station: StationId, entries: Vec<Vec<u8>>, chunks: Vec<(Hash, Vec<u8>)>, announce: Option<Announce>, hops: u8 },
    /// Tab to tab only: an offer of a direct link from a requester to its guard, answered with
    /// the guard's own. A node knows no such hop and gives nothing back.
    Rtc { sdp: String },
}

/// A station this tab keeps: the key it signs with (a deputy, or the master while it is
/// raised), its proof of work, and the chunks still to sail. Nothing of it touches the disk
/// here; the page keeps the deputy's seed, and the network keeps everything else.
struct Mine {
    key: pyrate_core::StationKey,
    pow: Option<u64>,
    chunks: HashMap<Hash, Vec<u8>>,
    unsent: VecDeque<Hash>,
    /// When the last full pass of the chunks sailed, so they go round again now and then.
    passed: u64,
    /// Entries the keeper has written here, and how many of them a stem has taken: an edit with
    /// no sound to carry sails at once, rather than with the next card minutes later.
    wrote: u64,
    sailed: u64,
}

/// Chunks to a stem's cargo, and bytes at most: well inside a node's frame.
const STEM_CHUNKS: usize = 40;
const STEM_BYTES: usize = 3 * 1024 * 1024;

/// What a tab asks an exit for. The order is the node's (`node/src/hop.rs`).
#[allow(dead_code)]
#[derive(serde::Serialize, serde::Deserialize)]
enum Ask {
    Log { station: StationId, from: u64 },
    Chunk { station: StationId, hash: Hash },
    Token { station: StationId, hour: u64, token: [u8; 32], nonce: u64 },
    Sealed { station: StationId, name: Hash },
    Stem { station: StationId, entries: Vec<Vec<u8>>, chunks: Vec<(Hash, Vec<u8>)>, announce: Option<Announce> },
    /// The middle of a three-hop route: pass `blob` to `next`, and the answer back under this
    /// hop's seal. A tab with the switch on is a middle; the requester is never seen.
    Relay { next: [u8; 32], blob: Vec<u8> },
    /// The way in to a deck: `lead` (sealed to this radio) names the listener; `blob` goes to it.
    Lead { lead: Vec<u8>, blob: Vec<u8> },
}

/// Why a route failed: its first hop could not be reached, or the hop gave no answer.
#[derive(Debug)]
enum RouteFail {
    FirstHop,
    NoAnswer,
    Other,
}

impl Ask {
    fn station(&self) -> Option<StationId> {
        match self {
            Ask::Log { station, .. } | Ask::Chunk { station, .. } | Ask::Token { station, .. } | Ask::Sealed { station, .. } | Ask::Stem { station, .. } => Some(*station),
            Ask::Relay { .. } | Ask::Lead { .. } => None,
        }
    }
}

/// Chunks and pictures this tab has fetched, oldest out first.
#[derive(Default)]
struct Hold {
    items: VecDeque<(Hash, Vec<u8>)>,
    bytes: usize,
}

impl Hold {
    fn get(&self, h: &Hash) -> Option<Vec<u8>> {
        self.items.iter().find(|(k, _)| k == h).map(|(_, v)| v.clone())
    }

    fn put(&mut self, h: Hash, b: Vec<u8>) {
        if self.items.iter().any(|(k, _)| *k == h) {
            return;
        }
        self.bytes += b.len();
        self.items.push_back((h, b));
        while self.bytes > HOLD_BYTES {
            let Some((_, old)) = self.items.pop_front() else { break };
            self.bytes -= old.len();
        }
    }
}

/// One of this tab's decks: a station it serves to the crew, under a key made for the deck
/// alone, reached only through `intro`, whose lead names this tab. The note names neither.
struct Deck {
    station: StationId,
    seed: [u8; 32],
    id: [u8; 32],
    intro: Option<EndpointId>,
    lead: Vec<u8>,
    said: u64,
    /// Kept as ballast (a station it does not play), not played.
    ballast: bool,
    /// The sealed names of this station's chunks the tab has fetched, with when: a deck serves
    /// only what it has held for the last ten minutes, or stock it kept.
    names: HashMap<Hash, (Hash, u64)>,
}

/// A tab's part in the crew: what it passes on for others, the decks it serves, and what it
/// knows of the other radios of the crew. All of it in memory, gone when the tab closes, but
/// ballast a computer keeps for the next visit (see `stock_take`).
/// Doors (node/src/door.rs): listeners' apps this tab reaches over a WebRTC data channel, with
/// no relay. Each is kept with the sources that named it: built into this copy (1), remembered
/// from an earlier visit (2), carried in the link that opened the page (3), or passed on by a
/// radio (that radio's id, folded). A door named by one source alone is a hint: it may be asked
/// for cards, never drawn as a guard (see `trusted`).
#[derive(Default)]
struct Doors {
    known: HashMap<[u8; 32], (net::DoorNote, Vec<u8>, Vec<u32>)>,
    /// The door this tab is through now, and since when.
    open: Option<(EndpointId, u64)>,
    /// Crew radios (tabs) behind a door, and the door.
    behind: HashMap<EndpointId, EndpointId>,
    /// When a relay last answered, and last failed.
    relay_ok: u64,
    relay_bad: u64,
    /// Which source first named each radio this tab knows of: a guard, a middle and an exit are
    /// never all three from one.
    intro: HashMap<EndpointId, u32>,
    /// The source the items now being taken in came from.
    now_from: u32,
    /// Requests and bytes over the door's channel; forwards it carried for tabs behind doors.
    asks: u64,
    bytes: u64,
    served: u64,
    /// Routes drawn, and those where no exit apart from the guard (another relay home, /16 and
    /// introducer) could be found and one was used all the same.
    routes: u64,
    routes_shared: u64,
    /// The last hundred routes' exits and middles, for the 25% cap.
    recent: VecDeque<EndpointId>,
    capped: u64,
    /// The minute the door was last asked for its cards.
    cards_minute: u64,
    /// Streams the kept guard turned away in a row.
    busy: u32,
    /// Doors the link that opened the page named, by address and fingerprint: a note for one of
    /// them counts the link as one more source.
    hints: Vec<(String, [u8; 32])>,
}

const SRC_BUILT_IN: u32 = 1;
const SRC_REMEMBERED: u32 = 2;
const SRC_LINK: u32 = 3;
/// Handed to the page by the Lantern or app that served it, unsigned: one source like any other.
const SRC_SERVED: u32 = 4;

/// How long a door must have been open before it may be a guard (rule A). A test build sets a
/// shorter wait with PYRATE_DOOR_AGE_MS.
const DOOR_AGE_MS: u64 = match option_env!("PYRATE_DOOR_AGE_MS") {
    Some(v) => match u64::from_str_radix(v, 10) {
        Ok(n) => n,
        Err(_) => 10 * 60_000,
    },
    None => 10 * 60_000,
};

fn src_of(id: &EndpointId) -> u32 {
    0x100 | u32::from_le_bytes(id.as_bytes()[..4].try_into().unwrap()) << 8
}

impl Doors {
    /// A door may be a guard when this copy carries it, it was used before, or two sources name it.
    fn trusted(&self, d: &[u8; 32]) -> bool {
        self.known.get(d).is_some_and(|(_, _, s)| s.contains(&SRC_BUILT_IN) || s.contains(&SRC_REMEMBERED) || s.len() >= 2)
    }
    fn add(&mut self, note: net::DoorNote, raw: Vec<u8>, src: u32) {
        let hinted = self.hints.iter().any(|(a, f)| *f == note.fp && *a == note.addr.to_string());
        let e = self.known.entry(note.node).or_insert_with(|| (note.clone(), raw.clone(), vec![]));
        if hinted && !e.2.contains(&SRC_LINK) {
            e.2.push(SRC_LINK);
        }
        if e.0.at_ms <= note.at_ms {
            e.0 = note;
            e.1 = raw;
        }
        if src != 0 && !e.2.contains(&src) && e.2.len() < 8 {
            e.2.push(src);
        }
        if self.known.len() > 256 {
            let mut v: Vec<([u8; 32], u64)> = self.known.iter().map(|(k, (n, _, _))| (*k, n.at_ms)).collect();
            v.sort_by_key(|x| x.1);
            for (k, _) in v.into_iter().take(64) {
                self.known.remove(&k);
            }
        }
    }
}

#[derive(Default)]
struct Crew {
    /// Radios of the crew heard of: the relay each named and when.
    radios: HashMap<EndpointId, (String, u64)>,
    /// Relays of the nodes heard of, from their own notes: for remembering quick peers.
    relays: HashMap<EndpointId, String>,
    /// When this tab first heard of each radio: a newcomer is never its first hop.
    first_seen: HashMap<EndpointId, u64>,
    /// This visit's first hops so far: the guard set, which a middle is never drawn from.
    guards: Vec<EndpointId>,
    /// The guards kept from earlier visits: first choice for a first hop while they answer, so
    /// a crowd of new radios cannot become a returning listener's first hop.
    kept: Vec<EndpointId>,
    /// Stations played this visit: never drawn as ballast, so nothing played is kept on disk.
    played: HashSet<StationId>,
    decks: Vec<Deck>,
    said_crew: u64,
    /// Bytes passed on in the current minute, and that minute.
    minute: (u64, u64),
    /// What this tab fetched for itself lately, and when: its own listening rate.
    own: VecDeque<(u64, usize)>,
    /// Chunks being fetched now, so a second ask waits on the first fetch.
    inflight: HashSet<Hash>,
    /// When each station last brought this tab a chunk: a station not heard for a minute is cold.
    warm: HashMap<StationId, u64>,
    /// Decks that gave nothing lately, and when.
    suspect: HashMap<[u8; 32], u64>,
    /// Bytes passed on for others today, and the day.
    today: (u64, u64),
    from_decks: u64,
    from_others: u64,
    bytes_decks: u64,
    bytes_others: u64,
    served: u64,
    served_stock: u64,
    refused: u64,
    /// The most of a minute's budget ever passed on, as a share of it: never above one.
    peak: f64,
    /// Chunk asks of the crew's decks, by outcome (see `deck_fetch`).
    tries: [u64; 6],
    /// When this tab's crew first ticked, and whether a ballast chunk is on its way.
    born: u64,
    ballast_busy: bool,
    /// Radios a hop could not reach in the last minute, and when.
    unreached: HashMap<EndpointId, u64>,
    /// The direct link to the guard: guards it was tried with this visit, bytes it carried, bytes
    /// the guard's leg took over the relay, and asks over a link that were not forwards (refused).
    rtc_tried: HashSet<EndpointId>,
    /// Requesters this tab has offered a direct link as their guard: they may see its address,
    /// so none of them is ever a way in to its decks.
    rtc_clients: HashSet<EndpointId>,
    rtc_bytes: u64,
    relay_first_bytes: u64,
    rtc_refused: u64,
    rtc_served: u64,
    ballast_hour: u64,
    /// Ballast chunks fetched and not yet handed to the page to keep.
    stock_out: Vec<(StationId, Hash, Vec<u8>)>,
    /// Chunks kept from earlier visits: sealed name to station and address.
    stock: HashMap<Hash, (StationId, Hash)>,
}

/// A computer passes on up to six times its own listening, a phone once: each carries itself
/// and some. Its own listening counts as at least 96 kbit/s.
const BUDGET_FLOOR: u64 = 720 * 1024;
/// How long a radio must be known before it may be a first hop: ten minutes for a node, half
/// an hour for a radio known only as crew (a tab, most likely, which costs nothing to make).
const NEWCOMER_MS: u64 = 10 * 60_000;
const NEWCOMER_TAB_MS: u64 = 30 * 60_000;
/// How long a radio's word that it is of the crew is believed: it says so every two minutes, so
/// one silent for four has most likely gone (a closed tab says nothing as it goes).
const CREW_FRESH_MS: u64 = 4 * 60_000;
/// How long a deck or a middle that gave nothing is passed over: long enough that a gone one
/// costs little, short enough that one that only stumbled comes back soon.
const SUSPECT_MS: u64 = 45_000;

/// One three-hop request as a tab builds it (the node's `hop::three_hops`): what goes to the
/// first hop, and the ciphers that open the answer, outermost first.
fn three_hops(middle: &[u8; 32], exit: &[u8; 32], ask: &[u8], deck: Option<(&[u8; 32], &[u8])>) -> Option<(Vec<u8>, Vec<pyrate_core::route::Cipher>)> {
    use pyrate_core::route::seal_to;
    let mut ciphers = Vec::new();
    let (eph, ct, c) = seal_to(exit, ask)?;
    ciphers.push(c);
    let mut to = *exit;
    let mut inner = postcard::to_stdvec(&Hop::Sealed { eph, ct }).ok()?;
    if let Some((intro, lead)) = deck {
        let (eph, ct, c) = seal_to(intro, &postcard::to_stdvec(&Ask::Lead { lead: lead.to_vec(), blob: inner }).ok()?)?;
        ciphers.push(c);
        to = *intro;
        inner = postcard::to_stdvec(&Hop::Sealed { eph, ct }).ok()?;
    }
    let (eph, ct, c) = seal_to(middle, &postcard::to_stdvec(&Ask::Relay { next: to, blob: inner }).ok()?)?;
    ciphers.push(c);
    ciphers.reverse();
    let blob = postcard::to_stdvec(&Hop::Sealed { eph, ct }).ok()?;
    Some((postcard::to_stdvec(&Hop::Forward { next: *middle, blob }).ok()?, ciphers))
}

/// A station's chatter as this tab holds it: the room's sender and the last lines.
struct Room {
    tx: GossipSender,
    /// When the tab joined, so the oldest room goes first when there are too many.
    since: u64,
    lines: VecDeque<pyrate_core::chat::Signed>,
    seen: pyrate_core::chat::Seen,
    neighbours: usize,
}

struct Ship {
    ep: Endpoint,
    gossip: GossipNet,
    /// Addresses learnt from links: harbours, and a flock's host.
    book: iroh::address_lookup::MemoryLookup,
    /// Flock: the host this tab follows, the clock it keeps, the station it plays.
    flock: Mutex<Option<(EndpointId, [u8; 8])>>,
    flock_off: std::sync::atomic::AtomicI64,
    flock_station: Mutex<Option<StationId>>,
    /// Pocket stations this tab was invited to: their keys and the hosts to start from.
    pockets: Mutex<HashMap<StationId, ([u8; 32], Vec<EndpointId>)>>,
    /// Each pocket's own topic, for telling its members only that this tab is aboard.
    pocket_tx: Mutex<HashMap<StationId, GossipSender>>,
    rooms: Mutex<HashMap<StationId, Room>>,
    harbour: Vec<EndpointId>,
    tx: Mutex<Option<GossipSender>>,
    log: Mutex<HashMap<StationId, Listing>>,
    archives: Mutex<HashMap<StationId, Archive>>,
    hold: Mutex<Hold>,
    conns: Mutex<HashMap<EndpointId, Connection>>,
    neighbours: Mutex<HashSet<EndpointId>>,
    /// Keyed hashes from this make the hourly listener tokens. It never leaves the tab.
    token_key: [u8; 32],
    tuned: Mutex<Option<StationId>>,
    tokens_sent: Mutex<HashMap<StationId, u64>>,
    syncing: Mutex<HashSet<StationId>>,
    drift: Mutex<pyrate_core::drift::Drift>,
    /// Nodes that failed to answer lately, and when: asked only after the others.
    failed: Mutex<HashMap<[u8; 32], u64>>,
    /// Whether the visitor is listening: only then is the tab counted aboard.
    listening: std::sync::atomic::AtomicBool,
    /// The first hop of this visit's private routes.
    first_hop: Mutex<Option<EndpointId>>,
    /// Exits whose route gave no answer lately, and when: drawn only after the others.
    suspect: Mutex<HashMap<EndpointId, u64>>,
    /// Off unless the listener turns it on: carriers asked directly when two hops fail.
    direct_ok: std::sync::atomic::AtomicBool,
    /// Each station's clock, rebuilt only when its log grows: the player asks every second.
    clocks: Mutex<HashMap<StationId, (u64, Clock)>>,
    /// When each log was last played or synced, so the least used go first when trimming.
    touched: Mutex<HashMap<StationId, u64>>,
    /// Stations that struck their colours: never searched for, listed or played again.
    struck: Mutex<HashSet<StationId>>,
    last_trim: std::sync::atomic::AtomicU64,
    mine: Mutex<HashMap<StationId, Mine>>,
    /// The first hop of this visit's stems, kept for the visit.
    stem_guard: Mutex<Option<EndpointId>>,
    sailing: std::sync::atomic::AtomicBool,
    /// Peers already asked for the cards they know.
    cards_asked: Mutex<HashSet<EndpointId>>,
    /// Routes in a row through the visit's first hop that brought nothing back.
    hop_misses: std::sync::atomic::AtomicU32,
    /// Radios a connection is being made to now: a second request waits for it.
    connecting: Mutex<HashSet<EndpointId>>,
    /// How long each radio has lately taken to answer, in milliseconds, smoothed.
    answers: Mutex<HashMap<EndpointId, f64>>,
    /// Radios that turned a hop away lately (a tab, a phone that relays for nobody), and when:
    /// left out of routes and stems for half an hour. And those that carried a route this visit.
    norelay: Mutex<HashMap<EndpointId, u64>>,
    relayed: Mutex<HashSet<EndpointId>>,
    /// The tab's node seed, for opening what the crew seals to it.
    secret: [u8; 32],
    /// "Carry the radio while you listen". Off is the tab as it was: it passes nothing on,
    /// serves nothing, and fetches through no deck.
    crew_on: std::sync::atomic::AtomicBool,
    /// A phone (touch, or on mobile data): it passes on no more than it listens to, and keeps
    /// no ballast.
    mobile: std::sync::atomic::AtomicBool,
    crew: Mutex<Crew>,
    doors: Mutex<Doors>,
}

/// A relay named in a link someone passed on: HTTPS only, so a link cannot send the tab's
/// traffic through a plain-text relay (a loopback relay is allowed, for testing).
fn relay_from_link(s: &str) -> Option<iroh::RelayUrl> {
    let url: iroh::RelayUrl = s.parse().ok()?;
    let t = url.to_string();
    let local = ["http://127.0.0.1:", "http://127.0.0.1/", "http://localhost:", "http://localhost/", "http://[::1]"].iter().any(|p| t.starts_with(p));
    (t.starts_with("https://") || local).then_some(url)
}

/// A number below `n` from the browser's own randomness.
fn pick(n: usize) -> usize {
    let mut b = [0u8; 8];
    let _ = getrandom::fill(&mut b);
    (u64::from_le_bytes(b) % n.max(1) as u64) as usize
}

fn raw_now() -> u64 {
    js_sys::Date::now() as u64
}

impl Ship {
    /// The tab's clock, corrected by the median gap to the stations' own signed times,
    /// as the app does.
    /// The hour as this tab plays it: the network's clock, set to a flock's host if it follows one.
    fn now(&self) -> u64 {
        (self.base_now() as i64 + self.flock_off.load(std::sync::atomic::Ordering::Relaxed)) as u64
    }

    fn base_now(&self) -> u64 {
        (raw_now() as i64 + self.drift.lock().unwrap().offset()) as u64
    }

    fn serve(&self, req: Request) -> Response {
        match req {
            // A tab answers nobody about what it holds: whoever could ask it for a station's log
            // or the chunks just played would learn what this visitor is hearing. It takes from
            // the network and gives back its count, its chatter and nothing else.
            Request::Log { .. } => Response::Entries(vec![]),
            Request::Chunk { .. } => Response::Chunk(None),
            Request::SealedChunk { .. } => Response::Sealed(None),
            Request::Flock { .. } => Response::Flock { now_ms: 0, station: None },
            Request::PocketLog { .. } => Response::Entries(vec![]),
            // Hops are answered in `on_hop`, never here.
            Request::Hop(_) => Response::Hop(vec![]),
            // A pocket's lines go only to whoever asks by its tag, and sealed.
            Request::Chatter { station } if self.pockets.lock().unwrap().contains_key(&station) => Response::Chatter(vec![]),
            // The last sixty open lines, as a node gives them: hails are for their recipients.
            Request::Chatter { station } => Response::Chatter(
                self.rooms
                    .lock()
                    .unwrap()
                    .get(&station)
                    .map(|r| {
                        let open: Vec<_> = r.lines.iter().filter(|l| !matches!(l.line.say, pyrate_core::chat::Say::Hail { .. })).collect();
                        open[open.len().saturating_sub(60)..].iter().filter_map(|l| postcard::to_allocvec(l).ok()).collect()
                    })
                    .unwrap_or_default(),
            ),
            Request::Cards => Response::Cards(vec![]),
            Request::PocketChatter { tag } => {
                let found = self.pockets.lock().unwrap().iter().find(|(_, (k, _))| pyrate_core::pocket::tag(k) == tag).map(|(st, (k, _))| (*st, *k));
                let Some((st, key)) = found else { return Response::Chatter(vec![]) };
                Response::Chatter(
                    self.rooms.lock().unwrap().get(&st).map(|r| r.lines.iter().rev().take(60).rev().filter_map(|l| postcard::to_allocvec(l).ok()).map(|b| pyrate_core::pocket::seal(&key, &b)).collect()).unwrap_or_default(),
                )
            }
        }
    }

    /// The tab's voice under a station's colours: from its own kept key, so the same voice
    /// comes back on the next visit from this browser.
    fn voice(&self, st: &StationId) -> pyrate_core::StationKey {
        let secret = *blake3::keyed_hash(&self.token_key, b"pyrate/chat/secret").as_bytes();
        pyrate_core::chat::voice(&secret, st)
    }

    fn hear(&self, st: StationId, l: pyrate_core::chat::Signed) -> bool {
        if !pyrate_core::chat::check(&l, &st, self.now()) || matches!(l.line.say, pyrate_core::chat::Say::Hail { .. }) {
            return false;
        }
        let mut rooms = self.rooms.lock().unwrap();
        let Some(r) = rooms.get_mut(&st) else { return false };
        if !r.seen.insert(pyrate_core::chat::id(&l), l.line.at_ms, self.now()) {
            return false;
        }
        r.lines.push_back(l);
        r.lines.make_contiguous().sort_by_key(|l| l.line.at_ms);
        while r.lines.len() > 200 {
            r.lines.pop_front();
        }
        true
    }

    async fn chat_join(self: &Arc<Self>, st: StationId) -> Result<()> {
        if self.rooms.lock().unwrap().contains_key(&st) {
            return Ok(());
        }
        // A pocket's room is its members' alone: a topic drawn from its key, met through its
        // hosts, every line sealed with the key.
        let pocket = self.pockets.lock().unwrap().get(&st).cloned();
        let key = pocket.as_ref().map(|p| p.0);
        let mut peers = match &pocket { Some((_, hosts)) => hosts.clone(), None => self.harbour.clone() };
        if let Some(l) = self.log.lock().unwrap().get(&st) {
            peers.extend(l.carriers.keys().filter_map(|n| EndpointId::from_bytes(n).ok()));
        }
        peers.retain(|p| *p != self.ep.id());
        peers.sort();
        peers.dedup();
        peers.truncate(12);
        let topic = key.map(|k| pyrate_core::pocket::chat_topic(&k)).unwrap_or_else(|| pyrate_core::chat::topic(&st));
        let sub = self.gossip.subscribe(TopicId::from_bytes(topic), peers.clone()).await.map_err(|e| anyhow!("{e}"))?;
        let (tx, mut rx) = sub.split();
        {
            // A tab keeps at most three rooms open; joining a fourth leaves the oldest.
            let mut rooms = self.rooms.lock().unwrap();
            while rooms.len() >= 3 {
                let Some(old) = rooms.iter().filter(|(k, _)| **k != st).min_by_key(|(_, r)| r.since).map(|(k, _)| *k) else { break };
                rooms.remove(&old);
            }
            rooms.insert(st, Room { tx, since: raw_now(), lines: VecDeque::new(), seen: Default::default(), neighbours: 0 });
        }
        let me = self.clone();
        spawn(async move {
            while let Some(ev) = rx.next().await {
                match ev {
                    Ok(Event::Received(m)) => {
                        let bytes = match &key {
                            Some(k) => pyrate_core::pocket::open(k, &m.content),
                            None => Some(m.content.to_vec()),
                        };
                        if let Some(l) = bytes.and_then(|b| postcard::from_bytes(&b).ok()) {
                            me.hear(st, l);
                        }
                    }
                    // The harbours sit in every room to carry it: they are not people listening.
                    Ok(Event::NeighborUp(n)) if !me.harbour.contains(&n) => {
                        if let Some(r) = me.rooms.lock().unwrap().get_mut(&st) {
                            r.neighbours += 1;
                        }
                    }
                    Ok(Event::NeighborDown(n)) if !me.harbour.contains(&n) => {
                        if let Some(r) = me.rooms.lock().unwrap().get_mut(&st) {
                            r.neighbours = r.neighbours.saturating_sub(1);
                        }
                    }
                    _ => {}
                }
                if !me.rooms.lock().unwrap().contains_key(&st) {
                    break;
                }
            }
        });
        let me = self.clone();
        spawn(async move {
            let ask = match &key {
                Some(k) => Request::PocketChatter { tag: pyrate_core::pocket::tag(k) },
                None => Request::Chatter { station: st },
            };
            for p in peers.into_iter().take(3) {
                if let Ok(Response::Chatter(lines)) = me.ask(p, &ask).await {
                    let got = lines
                        .iter()
                        .filter_map(|b| match &key { Some(k) => pyrate_core::pocket::open(k, b), None => Some(b.clone()) })
                        .filter_map(|b| postcard::from_bytes::<pyrate_core::chat::Signed>(&b).ok())
                        .filter(|l| me.hear(st, l.clone()))
                        .count();
                    if got > 0 {
                        break;
                    }
                }
            }
        });
        Ok(())
    }

    /// A line as it goes out: sealed with the key in a pocket's room, as it is elsewhere.
    fn room_bytes(&self, st: &StationId, bytes: Vec<u8>) -> Vec<u8> {
        match self.pockets.lock().unwrap().get(st) {
            Some((key, _)) => pyrate_core::pocket::seal(key, &bytes),
            None => bytes,
        }
    }

    async fn conn(&self, node: EndpointId) -> Result<Connection> {
        // One connection per radio: a request made while another is connecting waits for it
        // rather than opening a second through the same relay.
        for _ in 0..300 {
            if let Some(c) = self.conns.lock().unwrap().get(&node) {
                if c.close_reason().is_none() {
                    return Ok(c.clone());
                }
            }
            if self.connecting.lock().unwrap().insert(node) {
                break;
            }
            sleep(Duration::from_millis(50)).await;
        }
        struct Done<'a>(&'a Mutex<HashSet<EndpointId>>, EndpointId);
        impl Drop for Done<'_> {
            fn drop(&mut self) {
                self.0.lock().unwrap().remove(&self.1);
            }
        }
        let _done = Done(&self.connecting, node);
        let t = raw_now();
        let c = match timeout(Duration::from_secs(15), self.ep.connect(node, ALPN)).await {
            Ok(Ok(c)) => c,
            Ok(Err(e)) => {
                say(&format!("connect {} failed after {} ms: {e}", node.fmt_short(), raw_now() - t));
                return Err(anyhow!("connect: {e}"));
            }
            Err(_) => {
                say(&format!("connect {} timed out", node.fmt_short()));
                return Err(anyhow!("connect timed out"));
            }
        };
        say(&format!("connected to {} in {} ms", node.fmt_short(), raw_now() - t));
        self.conns.lock().unwrap().insert(node, c.clone());
        Ok(c)
    }

    async fn ask(&self, node: EndpointId, req: &Request) -> Result<Response> {
        // Through the door. The door itself is asked over its channel for hops (it is this tab's
        // guard) and cards, nothing else. With no relay answering, a hop for any other radio goes
        // to the door as a forward, which it passes on as a relay would; the hop is sealed to
        // that radio, so the door learns only that this tab talks to it. Nothing else is asked
        // of anyone without a relay: what a tab wants goes by routes.
        let door = self.door_now();
        if let Some(d) = door {
            if node == d && matches!(req, Request::Hop(_) | Request::Cards) {
                return self.ask_door(req).await;
            }
            if self.door_only() {
                match req {
                    Request::Hop(b) if matches!(postcard::from_bytes::<Hop>(b), Ok(Hop::Sealed { .. })) => {
                        let fwd = postcard::to_stdvec(&Hop::Forward { next: *node.as_bytes(), blob: b.clone() })?;
                        return self.ask_door(&Request::Hop(fwd)).await;
                    }
                    Request::Cards => return self.ask_door(req).await,
                    _ => {}
                }
            }
        }
        // A tab behind another door: to that door, as a forward it passes on.
        if let Request::Hop(b) = req {
            let behind = self.doors.lock().unwrap().behind.get(&node).copied();
            if let Some(via) = behind.filter(|v| *v != node && *v != self.ep.id()) {
                if matches!(postcard::from_bytes::<Hop>(b), Ok(Hop::Sealed { .. })) {
                    let fwd = postcard::to_stdvec(&Hop::Forward { next: *node.as_bytes(), blob: b.clone() })?;
                    return Box::pin(self.ask(via, &Request::Hop(fwd))).await;
                }
            }
        }
        // To the tab's own guard, over the direct link when one is open; back on the relay at
        // once if it fails. No other radio is ever asked this way.
        let first = *self.first_hop.lock().unwrap() == Some(node);
        let forward = matches!(req, Request::Hop(b) if matches!(postcard::from_bytes::<Hop>(b), Ok(Hop::Forward { .. })));
        if first && forward && self.crew_on() && self.crew.lock().unwrap().rtc_tried.contains(&node) {
            let out = postcard::to_stdvec(req)?;
            if let Ok(p) = rtc_ask(&node.to_string(), &out) {
                if let Ok(v) = wasm_bindgen_futures::JsFuture::from(p).await {
                    let b = js_sys::Uint8Array::new(&v).to_vec();
                    if let Ok(r) = postcard::from_bytes::<Response>(&b) {
                        self.crew.lock().unwrap().rtc_bytes += (out.len() + b.len()) as u64;
                        return Ok(r);
                    }
                }
            }
        }
        let r = self.ask_relay(node, req).await;
        if first {
            if let Ok(Response::Hop(b)) = &r {
                let n = postcard::to_stdvec(req).map(|x| x.len()).unwrap_or(0) + b.len();
                self.crew.lock().unwrap().relay_first_bytes += n as u64;
            }
        }
        r
    }

    async fn ask_relay(&self, node: EndpointId, req: &Request) -> Result<Response> {
        let c = match self.conn(node).await {
            Ok(c) => c,
            Err(e) => {
                self.doors.lock().unwrap().relay_bad = raw_now();
                let now = self.now();
                let mut f = self.failed.lock().unwrap();
                f.retain(|_, t| now.saturating_sub(*t) < net::FAILED_MS);
                f.insert(*node.as_bytes(), now);
                return Err(e);
            }
        };
        let fut = async {
            let (mut send, mut recv) = c.open_bi().await?;
            send.write_all(&postcard::to_stdvec(req)?).await?;
            send.finish()?;
            let bytes = recv.read_to_end(MAX_FRAME).await?;
            anyhow::Ok(postcard::from_bytes(&bytes)?)
        };
        let t = raw_now();
        match timeout(Duration::from_secs(20), fut).await {
            Ok(Ok(r)) => {
                self.answered(node, (raw_now() - t) as f64);
                self.doors.lock().unwrap().relay_ok = raw_now();
                Ok(r)
            }
            Ok(Err(e)) => {
                // A stream turned away on a connection that stands is a busy radio, not a lost
                // one: the connection is kept.
                let mut cs = self.conns.lock().unwrap();
                if !(e.to_string().contains("reset by peer") && cs.get(&node).is_some_and(|c| c.close_reason().is_none())) {
                    cs.remove(&node);
                }
                Err(e)
            }
            Err(_) => {
                self.answered(node, 20_000.0);
                self.conns.lock().unwrap().remove(&node);
                self.failed.lock().unwrap().insert(*node.as_bytes(), self.now());
                Err(anyhow!("request timed out"))
            }
        }
    }

    /// The door this tab is through, if any.
    fn door_now(&self) -> Option<EndpointId> {
        self.doors.lock().unwrap().open.map(|(d, _)| d)
    }

    /// Through a door with no relay answering: everything goes through the door. A relay that
    /// answered in the last twenty seconds keeps the tab on its usual paths, the door its guard.
    fn door_only(&self) -> bool {
        let d = self.doors.lock().unwrap();
        d.open.is_some() && raw_now().saturating_sub(d.relay_ok) > 20_000
    }

    /// One request over the door's channel.
    async fn ask_door(&self, req: &Request) -> Result<Response> {
        let out = postcard::to_stdvec(req)?;
        let p = door_ask_js(&out).map_err(|_| anyhow!("no door"))?;
        let t = raw_now();
        let v = wasm_bindgen_futures::JsFuture::from(p).await.map_err(|_| anyhow!("the door did not answer"))?;
        let b = js_sys::Uint8Array::new(&v).to_vec();
        {
            let mut d = self.doors.lock().unwrap();
            d.asks += 1;
            d.bytes += (out.len() + b.len()) as u64;
        }
        if let Some(d) = self.door_now() {
            self.answered(d, (raw_now() - t) as f64);
        }
        Ok(postcard::from_bytes(&b)?)
    }

    /// Where a radio is homed: its relay, or for a door its /16 (/32 for IPv6), or the door a
    /// tab is behind. Two radios with the same home are seen together by whoever runs it.
    fn home(&self, n: &EndpointId) -> Option<String> {
        let d = self.doors.lock().unwrap();
        if let Some((note, _, _)) = d.known.get(n.as_bytes()) {
            return Some(match note.addr.ip() {
                std::net::IpAddr::V4(v) => format!("ip4:{}.{}", v.octets()[0], v.octets()[1]),
                std::net::IpAddr::V6(v) => format!("ip6:{:x}:{:x}", v.segments()[0], v.segments()[1]),
            });
        }
        if let Some(b) = d.behind.get(n) {
            return Some(format!("door:{b}"));
        }
        drop(d);
        let c = self.crew.lock().unwrap();
        c.relays.get(n).cloned().or_else(|| c.radios.get(n).map(|(r, _)| r.clone()))
    }

    /// Whether two radios of a route stand apart: not homed together, and not named to this tab
    /// by the same source.
    fn apart(&self, a: &EndpointId, b: &EndpointId) -> bool {
        if a == b {
            return false;
        }
        if let (Some(x), Some(y)) = (self.home(a), self.home(b)) {
            if x == y {
                return false;
            }
        }
        let d = self.doors.lock().unwrap();
        !matches!((d.intro.get(a), d.intro.get(b)), (Some(x), Some(y)) if x == y)
    }

    /// No one radio takes more than a quarter of this tab's last hundred exits and middles,
    /// once there are twenty to count and more than four radios to share them (with four or
    /// fewer, a quarter each cannot be had, and the cap would only block).
    fn under_cap(&self, n: &EndpointId) -> bool {
        let d = self.doors.lock().unwrap();
        let k = d.recent.len();
        let mut seen: Vec<&EndpointId> = d.recent.iter().collect();
        seen.sort();
        seen.dedup();
        k < 20 || seen.len() <= 4 || d.recent.iter().filter(|x| *x == n).count() * 4 < k
    }

    fn drawn(&self, n: EndpointId) {
        let mut d = self.doors.lock().unwrap();
        d.recent.push_back(n);
        if d.recent.len() > 100 {
            d.recent.pop_front();
        }
    }

    /// Who to ask for a station: its carriers, freshest first, then the harbour Lanterns,
    /// which carry everything they hear of. A pocket is asked of its own circle only.
    fn carriers(&self, station: &StationId) -> Vec<EndpointId> {
        let pocket = self.pockets.lock().unwrap().contains_key(station);
        let me = *self.ep.id().as_bytes();
        let now = self.now();
        let failed = self.failed.lock().unwrap().clone();
        let ranked = self
            .log
            .lock()
            .unwrap()
            .get(station)
            .map(|l| net::rank_carriers(&l.carriers, &me, l.announce.as_ref().map(|a| a.head), |n| failed.get(n).is_some_and(|t| now.saturating_sub(*t) < net::FAILED_MS), |n| self.harbour.iter().any(|h| h.as_bytes() == n)))
            .unwrap_or_default();
        let mut out: Vec<EndpointId> = ranked.into_iter().filter_map(|n| EndpointId::from_bytes(&n).ok()).collect();
        if pocket {
            return out;
        }
        for h in &self.harbour {
            if !out.contains(h) {
                out.push(*h);
            }
        }
        out
    }

    /// Entries from a log, checked and appended. True as well when the station has struck.
    fn take_entries(&self, station: StationId, raw: Vec<Vec<u8>>) -> (usize, bool) {
        let mut added = 0;
        let mut archives = self.archives.lock().unwrap();
        let a = archives.entry(station).or_insert_with(|| Archive::new(station));
        for b in raw {
            // A tab holds at most 32 MB of any one log.
            if a.bytes() + b.len() as u64 > TAB_LOG_MAX {
                break;
            }
            let Ok(e) = SignedEntry::from_bytes(&b) else { break };
            if e.entry.seq < a.len() {
                continue;
            }
            if a.append(e).is_err() {
                break;
            }
            added += 1;
        }
        if a.is_struck() {
            archives.remove(&station);
            drop(archives);
            self.struck.lock().unwrap().insert(station);
            self.log.lock().unwrap().remove(&station);
            self.clocks.lock().unwrap().remove(&station);
            return (added, true);
        }
        if a.len() == 0 {
            archives.remove(&station);
        }
        (added, false)
    }

    async fn sync(&self, station: StationId) -> Result<usize> {
        let pocket = self.pockets.lock().unwrap().get(&station).cloned();
        if let Some((key, hosts)) = pocket {
            return self.pocket_sync(station, key, hosts).await;
        }
        // Two hops first, as the app does: the carrier that answers never sees this tab.
        let mut added = 0;
        let mut private = false;
        // Exits answer a quarter of a megabyte at a time: enough rounds for the longest log a tab
        // keeps. Three rounds with no answer end the try, and the set asks again shortly.
        let mut misses = 0;
        for _ in 0..140 {
            let from = self.archives.lock().unwrap().get(&station).map(|a| a.len()).unwrap_or(0);
            // A log this tab has never seen goes out along two routes at once; the first to
            // bring entries wins.
            let asked = if from == 0 { self.first_page(station).await } else { self.ask_hedged(&Ask::Log { station, from }).await };
            let Ok(Response::Entries(raw)) = asked else {
                misses += 1;
                if misses >= 3 {
                    break;
                }
                continue;
            };
            let got = raw.len();
            // An exit that found no carrier answers with nothing. For a log this tab has never
            // seen, that is no answer at all, so another exit is asked.
            if got == 0 && from == 0 {
                misses += 1;
                if misses >= 3 {
                    break;
                }
                continue;
            }
            private = true;
            let (n, struck) = self.take_entries(station, raw);
            added += n;
            // Pages are limited by bytes: keep asking while each brings something new.
            if struck || got == 0 || n == 0 {
                break;
            }
        }
        if private {
            return Ok(added);
        }
        if !self.direct_ok.load(std::sync::atomic::Ordering::Relaxed) {
            return Err(anyhow!("no two-hop route yet"));
        }
        for node in self.carriers(&station).into_iter().take(12) {
            for _ in 0..64 {
                let before = added;
                let from = self.archives.lock().unwrap().get(&station).map(|a| a.len()).unwrap_or(0);
                let raw = match self.ask(node, &Request::Log { station, from }).await {
                    Ok(Response::Entries(raw)) => raw,
                    Ok(_) => break,
                    Err(e) => {
                        say(&format!("log from {}: {e}", node.fmt_short()));
                        break;
                    }
                };
                let got = raw.len();
                let mut archives = self.archives.lock().unwrap();
                let a = archives.entry(station).or_insert_with(|| Archive::new(station));
                for b in raw {
                    // A tab holds at most 32 MB of any one log.
                    if a.bytes() + b.len() as u64 > TAB_LOG_MAX {
                        break;
                    }
                    let Ok(e) = SignedEntry::from_bytes(&b) else { break };
                    if e.entry.seq < a.len() {
                        continue;
                    }
                    if let Err(err) = a.append(e) {
                        say(&format!("entry refused from {}: {err}", node.fmt_short()));
                        break;
                    }
                    added += 1;
                }
                if a.is_struck() {
                    archives.remove(&station);
                    drop(archives);
                    self.struck.lock().unwrap().insert(station);
                    self.log.lock().unwrap().remove(&station);
                    self.clocks.lock().unwrap().remove(&station);
                    return Ok(added);
                }
                // A page that brings nothing new ends the asking: no carrier keeps a tab
                // looping on entries it already has.
                if got == 0 || added == before {
                    break;
                }
            }
            if self.archives.lock().unwrap().contains_key(&station) {
                break;
            }
        }
        if added > 0 {
            say(&format!("log {}: {added} entries", station.call_sign()));
        }
        Ok(added)
    }

    /// One request two hops away, and a second along another route if the first has not
    /// answered in three seconds: whichever answers first is taken.
    async fn ask_hedged(&self, ask: &Ask) -> Result<Response> {
        let go = |wait: u64| async move {
            if wait > 0 {
                sleep(Duration::from_millis(wait)).await;
            }
            self.ask_privately(ask).await
        };
        let mut tries: n0_future::FuturesUnordered<_> = [0u64, 3000].into_iter().map(|w| Box::pin(go(w))).collect();
        let mut last = Err(anyhow!("no route"));
        while let Some(r) = n0_future::StreamExt::next(&mut tries).await {
            if r.is_ok() {
                return r;
            }
            last = r;
        }
        last
    }

    /// The first page of a log along two routes at once: the first answer with entries in it.
    async fn first_page(&self, station: StationId) -> Result<Response> {
        let one = |exit: Option<EndpointId>| async move {
            match self.ask_route(&Ask::Log { station, from: 0 }, exit).await {
                Ok(Response::Entries(list)) if !list.is_empty() => Ok(Response::Entries(list)),
                _ => Err(anyhow!("an exit with nothing")),
            }
        };
        // Four routes at once through the visit's first hop, each to a different exit: a log the
        // tab has never seen waits on the fastest of them, not on the first one drawn.
        let nodes = self.route_nodes();
        let first = if nodes.len() >= 2 { self.first_hop_for(&nodes) } else { None };
        let exits = first.map(|f| self.exits_for(&nodes, &[f], 4, Some(station))).unwrap_or_default();
        type Try<'a> = std::pin::Pin<Box<dyn std::future::Future<Output = Result<Response>> + 'a>>;
        let mut tries: n0_future::FuturesUnordered<Try> = if exits.is_empty() {
            (0..2).map(|_| Box::pin(one(None)) as Try).collect()
        } else {
            exits.iter().map(|e| Box::pin(one(Some(*e))) as Try).collect()
        };
        // With the switch on, a deck of the station beside them: a listener's tab answers as
        // soon as a Lantern, and every page it gives is one a Lantern did not.
        let warm = self.crew.lock().unwrap().warm.get(&station).is_some_and(|t| raw_now().saturating_sub(*t) < 60_000);
        if self.crew_on() && warm {
            if let Some((deck, Some(note))) = self.keeper(&station, &station.0, 0) {
                tries.push(Box::pin(async move {
                    match self.ask_deck(&Ask::Log { station, from: 0 }, deck, &note).await {
                        Ok(Response::Entries(list)) if !list.is_empty() => Ok(Response::Entries(list)),
                        _ => Err(anyhow!("a deck with nothing")),
                    }
                }));
            }
        }
        let mut last = Err(anyhow!("no route"));
        while let Some(r) = n0_future::StreamExt::next(&mut tries).await {
            if r.is_ok() {
                return r;
            }
            last = r;
        }
        last
    }

    /// A pocket station's log from its hosts and members, sealed, asked for by its tag.
    async fn pocket_sync(&self, station: StationId, key: [u8; 32], hosts: Vec<EndpointId>) -> Result<usize> {
        let tag = pyrate_core::pocket::tag(&key);
        let mut asked = hosts;
        asked.extend(self.carriers(&station));
        asked.dedup();
        let mut added = 0;
        for node in asked.into_iter().take(6) {
            let from = self.archives.lock().unwrap().get(&station).map(|a| a.len()).unwrap_or(0);
            let Ok(Response::Entries(raw)) = self.ask(node, &Request::PocketLog { tag, from }).await else { continue };
            let mut archives = self.archives.lock().unwrap();
            let a = archives.entry(station).or_insert_with(|| Archive::new(station));
            for b in raw.iter().filter_map(|b| pyrate_core::pocket::open(&key, b)) {
                // A tab holds at most 32 MB of any one log.
                if a.bytes() + b.len() as u64 > TAB_LOG_MAX {
                    break;
                }
                let Ok(e) = SignedEntry::from_bytes(&b) else { break };
                if e.entry.station != station || e.entry.seq < a.len() {
                    continue;
                }
                if a.append(e).is_err() {
                    break;
                }
                added += 1;
            }
        }
        Ok(added)
    }

    async fn fetch(&self, station: &StationId, hash: &Hash) -> Result<Vec<u8>> {
        self.fetch_via(station, hash, true).await
    }

    /// A chunk, fetched once however many ask for it at the same time. With the switch on, the
    /// crew's deck that keeps it is asked first, three hops away, and an ordinary route at once
    /// if it has nothing; a station not heard from for a minute asks both together, so the first
    /// Listen never waits on a deck. `decks` false for a deck fetching for another: no deck ever
    /// waits on a second deck.
    async fn fetch_via(&self, station: &StationId, hash: &Hash, decks: bool) -> Result<Vec<u8>> {
        if let Some(b) = self.hold.lock().unwrap().get(hash) {
            return Ok(b);
        }
        if !self.crew.lock().unwrap().inflight.insert(*hash) {
            for _ in 0..120 {
                sleep(Duration::from_millis(100)).await;
                if let Some(b) = self.hold.lock().unwrap().get(hash) {
                    return Ok(b);
                }
                if !self.crew.lock().unwrap().inflight.contains(hash) {
                    break;
                }
            }
            return Err(anyhow!("the fetch beside this one failed"));
        }
        struct Done<'a>(&'a Mutex<Crew>, Hash);
        impl Drop for Done<'_> {
            fn drop(&mut self) {
                self.0.lock().unwrap().inflight.remove(&self.1);
            }
        }
        let _done = Done(&self.crew, *hash);
        let pocket = self.pockets.lock().unwrap().contains_key(station);
        // Not for a station just tuned: the first Listen waits on nothing but the quickest route.
        let cold = !self.crew.lock().unwrap().warm.get(station).is_some_and(|t| raw_now().saturating_sub(*t) < 60_000);
        let use_decks = decks && !pocket && self.crew_on() && !cold;
        type Try<'a> = std::pin::Pin<Box<dyn std::future::Future<Output = Result<(Vec<u8>, bool)>> + 'a>>;
        let deck: Try = Box::pin(async move { self.deck_fetch(station, hash).await.map(|b| (b, true)) });
        let plain: Try = Box::pin(async move { self.fetch_ordinary(station, hash).await.map(|b| (b, false)) });
        let r = if !use_decks {
            plain.await
        } else {
            // Warm, the deck goes first and an ordinary route follows when the deck fails or
            // has not answered in two seconds, so a deck that has gone costs at most that. Cold,
            // both go at once.
            let gave_up = Arc::new(std::sync::atomic::AtomicBool::new(cold));
            let g2 = gave_up.clone();
            let deck: Try = Box::pin(async move {
                let r = deck.await;
                if r.is_err() {
                    g2.store(true, std::sync::atomic::Ordering::Relaxed);
                }
                r
            });
            let plain: Try = Box::pin(async move {
                for _ in 0..20 {
                    if gave_up.load(std::sync::atomic::Ordering::Relaxed) {
                        break;
                    }
                    sleep(Duration::from_millis(100)).await;
                }
                plain.await
            });
            let mut both: n0_future::FuturesUnordered<Try> = [deck, plain].into_iter().collect();
            let mut last = Err(anyhow!("no route"));
            while let Some(r) = n0_future::StreamExt::next(&mut both).await {
                if r.is_ok() {
                    last = r;
                    break;
                }
                last = r;
            }
            last
        };
        let (b, from_deck) = r?;
        self.hold.lock().unwrap().put(*hash, b.clone());
        self.got(station, hash, b.len(), from_deck);
        Ok(b)
    }

    async fn fetch_ordinary(&self, station: &StationId, hash: &Hash) -> Result<Vec<u8>> {
        if let Some(b) = self.hold.lock().unwrap().get(hash) {
            return Ok(b);
        }
        // A pocket's sound comes from its members, who know each other already: a route would
        // hand a stranger at the exit the pocket's id.
        let pocket = self.pockets.lock().unwrap().contains_key(station);
        // Two hops first: two routes at once, a third if both fail. The exits see a sealed
        // name and never this tab; the first hop sees this tab and never the name.
        let name = pyrate_core::seal::name(hash);
        let one = || async move {
            match self.ask_privately(&Ask::Sealed { station: *station, name }).await {
                Ok(Response::Sealed(Some(sealed))) => pyrate_core::seal::unseal(hash, &sealed).ok_or_else(|| anyhow!("unopened")),
                _ => Err(anyhow!("no answer")),
            }
        };
        // Two routes at once, and a third if one fails or neither has answered in 2.5 s.
        let one = &one;
        let go = move |wait: u64| async move {
            if wait > 0 {
                sleep(Duration::from_millis(wait)).await;
            }
            one().await
        };
        let mut tries: n0_future::FuturesUnordered<_> = if pocket { Default::default() } else { [0u64, 0, 2500].into_iter().map(|w| Box::pin(go(w))).collect() };
        let mut started = if pocket { 4 } else { 3 };
        while let Some(r) = n0_future::StreamExt::next(&mut tries).await {
            if let Ok(b) = r {
                self.hold.lock().unwrap().put(*hash, b.clone());
                return Ok(b);
            }
            if started < 4 {
                tries.push(Box::pin(go(0)));
                started += 1;
            }
        }
        if !pocket && !self.direct_ok.load(std::sync::atomic::Ordering::Relaxed) {
            return Err(anyhow!("no two-hop route answered"));
        }
        // Carriers that failed lately go to the back; the rest are asked two at a time, so
        // one dead carrier costs a chunk no more than the other's answer takes.
        let now = self.now();
        let failed = self.failed.lock().unwrap().clone();
        let (fresh, stale): (Vec<EndpointId>, Vec<EndpointId>) = self
            .carriers(station)
            .into_iter()
            .partition(|n| !failed.get(n.as_bytes()).is_some_and(|t| now.saturating_sub(*t) < net::FAILED_MS));
        let order: Vec<EndpointId> = fresh.into_iter().chain(stale).take(8).collect();
        for pair in order.chunks(2) {
            let mut tries: n0_future::FuturesUnordered<_> = pair.iter().map(|n| Box::pin(self.fetch_from(*n, hash))).collect();
            while let Some(r) = n0_future::StreamExt::next(&mut tries).await {
                if let Ok(b) = r {
                    self.hold.lock().unwrap().put(*hash, b.clone());
                    return Ok(b);
                }
            }
        }
        Err(anyhow!("no carrier answered for that chunk"))
    }

    async fn fetch_from(&self, node: EndpointId, hash: &Hash) -> Result<Vec<u8>> {
        let name = pyrate_core::seal::name(hash);
        if let Ok(Response::Sealed(Some(s))) = self.ask(node, &Request::SealedChunk { name }).await {
            if let Some(b) = pyrate_core::seal::unseal(hash, &s) {
                return Ok(b);
            }
        }
        // A keeper's own node hands out its station's sound in the clear.
        if let Ok(Response::Chunk(Some(b))) = self.ask(node, &Request::Chunk { hash: *hash }).await {
            if blake3::hash(&b).as_bytes() == hash {
                return Ok(b);
            }
        }
        Err(anyhow!("not from {}", node.fmt_short()))
    }

    /// Once a minute: what a long-open tab has gathered and no longer needs goes. Cards
    /// gone quiet for six hours, logs beyond the eight last played (the tuned station and
    /// pockets always stay), and connections that have closed.
    fn trim(&self) {
        let now = raw_now();
        if now.saturating_sub(self.last_trim.load(std::sync::atomic::Ordering::Relaxed)) < 60_000 {
            return;
        }
        self.last_trim.store(now, std::sync::atomic::Ordering::Relaxed);
        let keep: HashSet<StationId> = self.pockets.lock().unwrap().keys().copied().chain(*self.tuned.lock().unwrap()).collect();
        let net_now = self.now();
        self.log.lock().unwrap().retain(|id, l| {
            keep.contains(id)
                || l.fresh(net_now)
                || l.announce.as_ref().is_some_and(|a| net_now.saturating_sub(a.at_ms) < 6 * 3_600_000)
        });
        let touched = self.touched.lock().unwrap().clone();
        let mut archives = self.archives.lock().unwrap();
        if archives.len() > 8 {
            let mut by: Vec<(u64, StationId)> = archives.keys().filter(|k| !keep.contains(k)).map(|k| (touched.get(k).copied().unwrap_or(0), *k)).collect();
            by.sort();
            let extra = archives.len().saturating_sub(8);
            for (_, k) in by.into_iter().take(extra) {
                archives.remove(&k);
            }
        }
        let live: HashSet<StationId> = archives.keys().copied().collect();
        drop(archives);
        self.clocks.lock().unwrap().retain(|k, _| live.contains(k));
        self.touched.lock().unwrap().retain(|k, _| live.contains(k));
        self.conns.lock().unwrap().retain(|_, c| c.close_reason().is_none());
        self.tokens_sent.lock().unwrap().retain(|k, _| live.contains(k) || keep.contains(k));
    }

    #[allow(dead_code)]
    async fn broadcast(&self, g: &Gossip) {
        // Through a door: only this tab's own crew note, which the door passes on.
        if self.door_now().is_some() && matches!(g, Gossip::Crew { .. }) {
            if let Ok(b) = postcard::to_stdvec(&net::DoorCtl::Gossip(postcard::to_stdvec(g).unwrap_or_default())) {
                let _ = door_ctl_js(&b);
            }
        }
        let tx = self.tx.lock().unwrap().clone();
        if let (Some(tx), Ok(bytes)) = (tx, postcard::to_stdvec(g)) {
            let _ = tx.broadcast(bytes.into()).await;
        }
    }

    fn accept_token(&self, station: StationId, hour: u64, token: [u8; 32], nonce: u64) {
        let now_hour = self.now() / 3_600_000;
        if hour + 1 < now_hour || hour > now_hour + 1 || !net::token_ok(&station, hour, &token, nonce) {
            return;
        }
        let mut log = self.log.lock().unwrap();
        if !log.contains_key(&station) {
            return;
        }
        let l = log.entry(station).or_default();
        l.heard.retain(|h, _| h + 2 >= now_hour);
        l.sketches.retain(|h, _| h + 2 >= now_hour);
        if l.heard.entry(hour).or_default().insert(token) {
            l.sketches.entry(hour).or_default().add(&token);
        }
    }

    /// Asks a peer for the cards it knows, once, and takes each as gossip would bring it.
    async fn cards_from(self: &Arc<Self>, node: EndpointId) {
        if !self.cards_asked.lock().unwrap().insert(node) {
            return;
        }
        let t = raw_now();
        let list = match self.ask(node, &Request::Cards).await {
            Ok(Response::Cards(list)) => list,
            other => return say(&format!("cards from {}: none after {} ms ({})", node.fmt_short(), raw_now() - t, other.err().map(|e| e.to_string()).unwrap_or_default())),
        };
        say(&format!("cards from {}: {} items in {} ms", node.fmt_short(), list.len(), raw_now() - t));
        let mut kinds = (0, 0, 0, 0, std::collections::BTreeMap::<String, usize>::new());
        let now = self.now();
        for b in list.into_iter().take(net::CARDS_ITEMS) {
            if b.len() > net::CARD_WIRE {
                continue;
            }
            // Cards, then the carriers' signed notes: each taken as gossip from that node, and
            // checked against its own signature or dropped. With them the tab can reach the
            // carriers through two hops at once, without waiting for the network to repeat them.
            let Ok(g) = postcard::from_bytes::<Gossip>(&b) else { continue };
            if !matches!(g, Gossip::Station(_) | Gossip::Carried { .. } | Gossip::Harbour { .. } | Gossip::Crew { .. } | Gossip::Deck { .. } | Gossip::Door { .. }) {
                continue;
            }
            // Every radio named here was named by `node`: never guard, middle and exit all from it.
            if let Gossip::Carried { node: c, .. } | Gossip::Harbour { node: c, .. } = &g {
                if let Ok(c) = EndpointId::from_bytes(c) {
                    let mut d = self.doors.lock().unwrap();
                    if d.intro.len() < 8_000 {
                        d.intro.entry(c).or_insert(src_of(&node));
                    }
                }
            }
            self.doors.lock().unwrap().now_from = src_of(&node);
            match &g { Gossip::Station(_) => kinds.0 += 1, Gossip::Carried { node, .. } => { kinds.1 += 1; *kinds.4.entry(hex(&node[..5])).or_default() += 1 } Gossip::Harbour { node, relay, .. } => { kinds.2 += 1; say(&format!("  {} is reached through {relay}", hex(&node[..5]))) } _ => kinds.2 += 1 }
            let Some(g) = g.from_network(now, node.as_bytes()) else { kinds.3 += 1; continue };
            if let Some(st) = self.on_gossip(g) {
                if *self.tuned.lock().unwrap() == Some(st) {
                    self.sync_soon(st);
                }
            }
        }
        self.doors.lock().unwrap().now_from = 0;
        say(&format!("  {} cards, {} carrier notes ({} refused), {} relay notes; carriers {:?}; route radios now {:?}", kinds.0, kinds.1, kinds.3, kinds.2, kinds.4, self.route_nodes().iter().map(|n| n.fmt_short().to_string()).collect::<Vec<_>>()));
    }

    /// Takes in a gossip message. Returns a station whose log has grown past ours.
    fn on_gossip(&self, g: Gossip) -> Option<StationId> {
        let now = self.now();
        match g {
            Gossip::Station(a) => {
                if a.at_ms > raw_now() + 5 * 60_000 || !a.verify() {
                    return None;
                }
                if let Some(p) = a.proof.as_ref().and_then(|b| SignedEntry::from_bytes(b).ok()) {
                    if let Body::Deputy { key, .. } = &p.entry.body {
                        if let Some(arch) = self.archives.lock().unwrap().get(&a.station) {
                            if arch.len() > p.entry.seq && !arch.deputies().contains(key) {
                                return None;
                            }
                        }
                    }
                }
                if self.struck.lock().unwrap().contains(&a.station) {
                    return None;
                }
                let mut log = self.log.lock().unwrap();
                let l = log.entry(a.station).or_default();
                let fresh = l.announce.as_ref().is_none_or(|old| a.at_ms > old.at_ms);
                if !fresh {
                    return None;
                }
                if raw_now().abs_diff(a.at_ms) < 300_000 + 60_000 {
                    self.drift.lock().unwrap().sample(a.station.0, a.at_ms, raw_now());
                }
                let (s, head) = (a.station, a.head);
                l.announce = Some(a);
                drop(log);
                let ours = self.archives.lock().unwrap().get(&s).map(|x| x.len()).unwrap_or(0);
                (head > ours).then_some(s)
            }
            Gossip::Carried { .. } => None,
            Gossip::Carrier { station, node, head } => {
                // A claim for a station with no card here is dropped: junk ids grow nothing.
                let pocket = self.pockets.lock().unwrap().contains_key(&station);
                let mut log = self.log.lock().unwrap();
                if !log.contains_key(&station) && !pocket {
                    return None;
                }
                let l = log.entry(station).or_default();
                let card = l.announce.as_ref().map(|a| a.head);
                let failed = self.failed.lock().unwrap().clone();
                let mut coin = [0u8; 8];
                let _ = getrandom::fill(&mut coin);
                net::note_carrier(
                    &mut l.carriers,
                    node,
                    head,
                    card,
                    now,
                    |n| self.harbour.iter().any(|h| h.as_bytes() == n),
                    |n| failed.get(n).is_some_and(|t| now.saturating_sub(*t) < net::FAILED_MS),
                    u64::from_le_bytes(coin),
                );
                drop(log);
                if let Ok(id) = EndpointId::from_bytes(&node) {
                    self.crew.lock().unwrap().first_seen.entry(id).or_insert(raw_now());
                }
                let ours = self.archives.lock().unwrap().get(&station).map(|x| x.len()).unwrap_or(0);
                (head > ours).then_some(station)
            }
            Gossip::Aboard { station, hour, tokens } => {
                for (token, nonce) in tokens.into_iter().take(10_000) {
                    self.accept_token(station, hour, token, nonce);
                }
                None
            }
            g @ Gossip::Door { .. } => {
                let note = g.door_checked(self.base_now())?;
                let raw = postcard::to_stdvec(&g).ok()?;
                let mut d = self.doors.lock().unwrap();
                let from = if d.now_from == 0 { 0x200 } else { d.now_from };
                let Ok(id) = EndpointId::from_bytes(&note.node) else { return None };
                d.intro.entry(id).or_insert(from);
                // A door naming itself vouches for nothing.
                d.add(note, raw, if from == src_of(&id) { 0 } else { from });
                None
            }
            g @ Gossip::Harbour { .. } => {
                // A carrier's own word on where it can be reached: into the tab's address book,
                // for carriers it knows and harbours only.
                let (node, relay) = g.harbour_checked(raw_now())?;
                let known = self.log.lock().unwrap().values().any(|l| l.carriers.contains_key(&node)) || self.harbour.iter().any(|h| *h.as_bytes() == node);
                if let (true, Ok(id), Ok(url)) = (known, EndpointId::from_bytes(&node), relay.parse::<iroh::RelayUrl>()) {
                    self.book.add_endpoint_info(iroh::EndpointAddr { id, addrs: [iroh::TransportAddr::Relay(url)].into_iter().collect() });
                    let mut c = self.crew.lock().unwrap();
                    if c.relays.len() < 4_000 {
                        c.relays.insert(id, relay);
                    }
                }
                None
            }
            g @ Gossip::Crew { .. } => {
                // A radio of the crew: a middle, or a deck's way in, reached through its relay.
                let (node, relay) = g.crew_checked(self.base_now())?;
                let id = EndpointId::from_bytes(&node).ok()?;
                if id == self.ep.id() {
                    return None;
                }
                {
                    let mut d = self.doors.lock().unwrap();
                    let from = d.now_from;
                    if from != 0 && d.intro.len() < 8_000 {
                        d.intro.entry(id).or_insert(from);
                    }
                    match net::door_of_relay(&relay).and_then(|b| EndpointId::from_bytes(&b).ok()) {
                        Some(via) => {
                            d.behind.insert(id, via);
                        }
                        None => {
                            d.behind.remove(&id);
                        }
                    }
                }
                if net::door_of_relay(&relay).is_none() {
                    if let Ok(url) = relay.parse::<iroh::RelayUrl>() {
                        self.book.add_endpoint_info(iroh::EndpointAddr { id, addrs: [iroh::TransportAddr::Relay(url)].into_iter().collect() });
                    }
                }
                // Kept by when the radio said it, not when the word arrived: a note passed on in a
                // Lantern's cards may be minutes old, and its radio gone since.
                let now = raw_now();
                let at_ms = match &g { Gossip::Crew { at_ms, .. } => *at_ms, _ => return None };
                let said = now.saturating_sub(self.base_now().saturating_sub(at_ms));
                let mut c = self.crew.lock().unwrap();
                c.first_seen.entry(id).or_insert(now);
                if c.radios.get(&id).is_none_or(|(_, t)| *t < said) {
                    c.radios.insert(id, (relay, said));
                }
                if c.radios.len() > 2_000 {
                    c.radios.retain(|_, (_, t)| now.saturating_sub(*t) < 15 * 60_000);
                }
                None
            }
            g @ Gossip::Deck { .. } => {
                // Another listener's deck, for a station whose card this tab holds.
                let (station, deck, d) = g.deck_checked(self.base_now())?;
                let now = self.now();
                let mut log = self.log.lock().unwrap();
                let l = log.get_mut(&station)?;
                if l.decks.len() >= net::MAX_DECKS && !l.decks.contains_key(&deck) {
                    l.decks.retain(|_, x| now.saturating_sub(x.at_ms) < net::DECK_FRESH_MS);
                    if l.decks.len() >= net::MAX_DECKS {
                        return None;
                    }
                }
                l.decks.insert(deck, d);
                None
            }
        }
    }

    /// Once an hour, for the station on: one token, worked for, so the station counts this
    /// tab once. The token is a keyed hash nobody can tie to the last hour's.
    async fn count_me(&self) {
        if !self.listening.load(std::sync::atomic::Ordering::Relaxed) {
            return;
        }
        let Some(station) = *self.tuned.lock().unwrap() else { return };
        let hour = self.now() / 3_600_000;
        if self.tokens_sent.lock().unwrap().get(&station) == Some(&hour) {
            return;
        }
        self.tokens_sent.lock().unwrap().insert(station, hour);
        let mut h = blake3::Hasher::new_keyed(&self.token_key);
        h.update(&station.0);
        h.update(&hour.to_le_bytes());
        let token = *h.finalize().as_bytes();
        // The work goes in slices, so the page never freezes for it.
        let mut nonce = 0u64;
        'work: loop {
            for _ in 0..8192 {
                if net::token_ok(&station, hour, &token, nonce) {
                    break 'work;
                }
                nonce += 1;
            }
            sleep(Duration::from_millis(1)).await;
        }
        self.accept_token(station, hour, token, nonce);
        // Two hops away, as a phone does: the first sees this tab and not the station, the exit
        // sees the station and not the tab, and counts it for everyone.
        let g = Gossip::Aboard { station, hour, tokens: vec![(token, nonce)] };
        // A pocket's listeners are counted among its members only: a token on the public Log
        // would name the station to everyone.
        let pocket = self.pockets.lock().unwrap().get(&station).map(|p| p.0);
        if let Some(key) = pocket {
            let tx = self.pocket_tx.lock().unwrap().get(&station).cloned();
            if let (Some(tx), Ok(bytes)) = (tx, postcard::to_stdvec(&g)) {
                let _ = tx.broadcast(pyrate_core::pocket::seal(&key, &bytes).into()).await;
            }
            return;
        }
        // With no two-hop route the token is not sent at all: it would name the station from
        // this tab. The hour is let go, and the next hour tries again.
        if self.token_privately(station, hour, token, nonce).await.is_err() {
            self.tokens_sent.lock().unwrap().remove(&station);
        }
    }

    /// The nodes a route can be drawn from: the harbour and every carrier heard lately.
    fn route_nodes(&self) -> Vec<EndpointId> {
        let mut nodes: Vec<EndpointId> = self.harbour.clone();
        let now = self.now();
        for l in self.log.lock().unwrap().values() {
            nodes.extend(l.carriers.iter().filter(|(_, (_, seen))| now.saturating_sub(*seen) < 10 * 60_000).filter_map(|(n, _)| EndpointId::from_bytes(n).ok()));
        }
        nodes.retain(|n| *n != self.ep.id());
        nodes.sort();
        nodes.dedup();
        // A radio that turned a hop away lately is left out, while two others remain.
        let now = raw_now();
        let away: HashSet<EndpointId> = self.norelay.lock().unwrap().iter().filter(|(_, t)| now.saturating_sub(**t) < 30 * 60_000).map(|(n, _)| *n).collect();
        let kept: Vec<EndpointId> = nodes.iter().filter(|n| !away.contains(*n)).copied().collect();
        if kept.len() >= 2 { kept } else { nodes }
    }

    /// Notes that a radio turned a hop away, so routes and stems pass over it for a while.
    fn turned_away(&self, n: EndpointId) {
        if !self.harbour.contains(&n) {
            self.norelay.lock().unwrap().insert(n, raw_now());
        }
    }

    /// One request two hops away. The first hop is drawn once a visit and sees this tab but
    /// not what it asks; the exit, drawn each time and never the first hop, sees what is asked
    /// and not who by. Fewer than two nodes known, and nothing is sent.
    async fn ask_privately(&self, ask: &Ask) -> Result<Response> {
        self.ask_route(ask, None).await
    }

    /// The visit's first hop, drawn once: from the radios this tab is already talking to where
    /// it can (they know its address already, and they answer at once), else from any it knows.
    fn first_hop_for(&self, nodes: &[EndpointId]) -> Option<EndpointId> {
        // A door this tab is through is its guard when it may be one: named by this copy, by an
        // earlier visit or by two sources, and open long enough (rule A). The first leg then runs
        // on no relay at all.
        if let Some(d) = self.door_now() {
            let ok = {
                let ds = self.doors.lock().unwrap();
                ds.trusted(d.as_bytes()) && ds.known.get(d.as_bytes()).is_some_and(|(n, _, _)| self.base_now().saturating_sub(n.since) >= DOOR_AGE_MS)
            };
            if ok {
                let mut g = self.first_hop.lock().unwrap();
                if *g != Some(d) {
                    *g = Some(d);
                    let mut c = self.crew.lock().unwrap();
                    c.guards.retain(|x| *x != d);
                    c.guards.push(d);
                    if c.guards.len() > 3 {
                        c.guards.remove(0);
                    }
                }
                return Some(d);
            }
            if self.door_only() {
                return None;
            }
        }
        let mut g = self.first_hop.lock().unwrap();
        if g.is_none_or(|f| !nodes.contains(&f) && !(self.crew_on() && self.crew.lock().unwrap().radios.contains_key(&f))) {
            // The quickest to answer of the radios this tab knows, drawn among those within half
            // as slow again: every request of the visit waits on the first hop, so a slow one
            // makes the whole radio slow. One not yet heard from counts as a second and a half.
            let near: HashSet<EndpointId> = self.neighbours.lock().unwrap().clone();
            // Only a seasoned radio (see `seasoned`): with the switch on, the crew's radios known
            // for half an hour join the draw, so long-lived tabs carry first hops too.
            let mut cands: Vec<EndpointId> = nodes.to_vec();
            if self.crew_on() {
                let now = raw_now();
                let crew: Vec<EndpointId> = self.crew.lock().unwrap().radios.iter().filter(|(_, (_, t))| now.saturating_sub(*t) < CREW_FRESH_MS).map(|(n, _)| *n).collect();
                cands.extend(crew.into_iter().filter(|n| !nodes.contains(n)));
            }
            let seasoned: Vec<EndpointId> = cands.into_iter().filter(|n| self.seasoned(n)).collect();
            let pool: Vec<(f64, EndpointId)> = seasoned.iter().map(|x| (self.answer_ms(x, near.contains(x)), *x)).collect();
            let best = pool.iter().map(|p| p.0).fold(f64::INFINITY, f64::min);
            let quick: Vec<EndpointId> = pool.iter().filter(|p| p.0 <= best * 1.5 + 50.0).map(|p| p.1).collect();
            // A guard kept from an earlier visit comes first, unless it has become slow: one not
            // yet heard from this visit counts as a second and a half, and stays first.
            let kept: Vec<EndpointId> = self.crew.lock().unwrap().kept.clone();
            let sticky: Vec<EndpointId> = pool.iter().filter(|p| kept.contains(&p.1) && p.0 <= (best * 3.0 + 300.0).max(2_000.0)).map(|p| p.1).collect();
            let quick = if sticky.is_empty() { quick } else { sticky };
            if quick.is_empty() {
                return None;
            }
            let f = quick[pick(quick.len())];
            *g = Some(f);
            // The guard set: this visit's first hops, never a middle.
            let mut c = self.crew.lock().unwrap();
            if !c.guards.contains(&f) {
                c.guards.push(f);
                if c.guards.len() > 3 {
                    c.guards.remove(0);
                }
            }
        }
        *g
    }

    /// A radio's recent answer time; one not heard from yet counts as a second and a half, or
    /// a second if it is a neighbour already.
    fn answer_ms(&self, n: &EndpointId, near: bool) -> f64 {
        self.answers.lock().unwrap().get(n).copied().unwrap_or(if near { 1000.0 } else { 1500.0 })
    }

    fn answered(&self, n: EndpointId, ms: f64) {
        let mut a = self.answers.lock().unwrap();
        let v = a.entry(n).or_insert(ms);
        *v = *v * 0.6 + ms * 0.4;
    }

    /// Exits for a request, as many as asked for and all different: radios that have not
    /// failed a route in the last three minutes first, then the rest, never `not`.
    fn exits(&self, nodes: &[EndpointId], not: &[EndpointId], n: usize) -> Vec<EndpointId> {
        self.exits_for(nodes, not, n, None)
    }

    /// Exits as above, with the radios that carry `station` drawn first: an exit that holds
    /// what is asked answers at once, where any other has to fetch it first.
    fn exits_for(&self, nodes: &[EndpointId], not: &[EndpointId], n: usize, station: Option<StationId>) -> Vec<EndpointId> {
        let now = self.now();
        let suspect = self.suspect.lock().unwrap().clone();
        let carrying: HashSet<[u8; 32]> = station.and_then(|st| self.log.lock().unwrap().get(&st).map(|l| l.carriers.keys().copied().collect())).unwrap_or_default();
        let bad = |x: &EndpointId| suspect.get(x).is_some_and(|t| now.saturating_sub(*t) < 3 * 60_000);
        let mut tiers: [Vec<EndpointId>; 3] = [
            nodes.iter().filter(|x| !not.contains(x) && !bad(x) && carrying.contains(x.as_bytes())).copied().collect(),
            nodes.iter().filter(|x| !not.contains(x) && !bad(x) && !carrying.contains(x.as_bytes())).copied().collect(),
            nodes.iter().filter(|x| !not.contains(x) && bad(x)).copied().collect(),
        ];
        // Within a tier the quicker radios come first, drawn at random among those close to the
        // quickest, so no one exit sees every request.
        let mut out = Vec::new();
        while out.len() < n {
            let Some(from) = tiers.iter_mut().find(|t| !t.is_empty()) else { break };
            let ms: Vec<f64> = from.iter().map(|x| self.answer_ms(x, false)).collect();
            let best = ms.iter().copied().fold(f64::INFINITY, f64::min);
            let quick: Vec<usize> = (0..from.len()).filter(|i| ms[*i] <= best * 1.5 + 50.0).collect();
            out.push(from.swap_remove(quick[pick(quick.len())]));
        }
        out
    }

    /// One request two hops away. The first hop, drawn once a visit, sees this tab but not what
    /// it asks; the exit, given or drawn each time and never the first hop, sees what is asked
    /// and not who by. A route that does not answer marks its exit as suspect for three minutes,
    /// since the first hop is a radio this tab is talking to; a first hop whose connection fails
    /// is redrawn. Fewer than two nodes known, and nothing is sent.
    async fn ask_route(&self, ask: &Ask, exit: Option<EndpointId>) -> Result<Response> {
        let nodes = self.route_nodes();
        if nodes.len() < 2 {
            say("route: fewer than two radios known");
            return Err(anyhow!("one node only"));
        }
        let first = self.first_hop_for(&nodes).ok_or_else(|| anyhow!("no first hop"))?;
        let exit = match exit.filter(|e| *e != first) {
            Some(e) => e,
            None => {
                // An exit apart from the first hop (another relay home, /16 and introducer) and
                // under the 25% cap where one exists; else the usual draw, counted.
                let apart: Vec<EndpointId> = nodes.iter().filter(|n| **n != first && self.apart(n, &first) && self.under_cap(n)).copied().collect();
                self.doors.lock().unwrap().routes += 1;
                match self.exits_for(&apart, &[first], 1, ask.station()).first() {
                    Some(e) => *e,
                    None => {
                        let e = *self.exits_for(&nodes, &[first], 1, ask.station()).first().ok_or_else(|| anyhow!("no exit"))?;
                        let capped = !nodes.iter().any(|n| *n != first && self.under_cap(n));
                        let mut d = self.doors.lock().unwrap();
                        d.routes_shared += 1;
                        if capped {
                            d.capped += 1;
                        }
                        e
                    }
                }
            }
        };
        self.drawn(exit);
        let r = self.via(first, exit, ask, nodes.len()).await;
        use std::sync::atomic::Ordering::Relaxed;
        match &r {
            Ok(_) => self.hop_misses.store(0, Relaxed),
            Err(RouteFail::FirstHop) => {
                // The first hop is gone: the next request draws another, and this one counts as
                // slow until it answers, so the draw passes over it (a door this tab cannot
                // reach at all was being drawn again and again).
                *self.first_hop.lock().unwrap() = None;
                self.answered(first, 8_000.0);
            }
            Err(RouteFail::NoAnswer) => {
                self.suspect.lock().unwrap().insert(exit, self.now());
                // Two routes in a row with no answer, through different exits: the first hop is
                // the likelier fault, and the next request draws another.
                if !self.neighbours.lock().unwrap().contains(&first) || self.hop_misses.fetch_add(1, Relaxed) >= 1 {
                    *self.first_hop.lock().unwrap() = None;
                    self.hop_misses.store(0, Relaxed);
                }
            }
            _ => {}
        }
        r.map_err(|e| anyhow!("{e:?}"))
    }

    /// One request along one route: `first` sees this tab, `exit` sees what is asked.
    async fn via(&self, first: EndpointId, exit: EndpointId, ask: &Ask, known: usize) -> std::result::Result<Response, RouteFail> {
        let plain = postcard::to_stdvec(ask).map_err(|_| RouteFail::Other)?;
        let (eph, ct, c) = pyrate_core::route::seal_to(exit.as_bytes(), &plain).ok_or(RouteFail::Other)?;
        let blob = postcard::to_stdvec(&Hop::Sealed { eph, ct }).map_err(|_| RouteFail::Other)?;
        let hop = postcard::to_stdvec(&Hop::Forward { next: *exit.as_bytes(), blob }).map_err(|_| RouteFail::Other)?;
        let t = raw_now();
        let what = match ask { Ask::Log { from, .. } => format!("log from {from}"), Ask::Sealed { .. } => "chunk".into(), Ask::Token { .. } => "token".into(), _ => "ask".into() };
        let r = timeout(Duration::from_secs(8), self.ask(first, &Request::Hop(hop))).await;
        // The route's time is the exit's too: an exit that is slow to fetch shows here.
        self.answered(exit, match &r { Ok(Ok(Response::Hop(raw))) if !raw.is_empty() => (raw_now() - t) as f64, _ => 8_000.0 });
        say(&format!("route {} via {} to {} ({} known): {} in {} ms", what, first.fmt_short(), exit.fmt_short(), known,
            match &r { Ok(Ok(Response::Hop(raw))) if !raw.is_empty() => "answered".to_string(), Ok(Ok(_)) => "empty".into(), Ok(Err(e)) => format!("first hop failed: {e}"), Err(_) => "timed out".into() }, raw_now() - t));
        let raw = match r {
            Ok(Ok(Response::Hop(raw))) if !raw.is_empty() => {
                self.doors.lock().unwrap().busy = 0;
                let mut ok = self.relayed.lock().unwrap();
                ok.insert(first);
                ok.insert(exit);
                raw
            }
            // A guard this tab keeps that turned a stream away (it was busy: a tab answers four at
            // a time) is not let go for it while the connection to it stands; thirty in a row, or
            // a connection that failed, and it is (sticky guards, crew addition A).
            Ok(Err(e)) => {
                let kept = self.crew.lock().unwrap().kept.contains(&first);
                let standing = self.conns.lock().unwrap().get(&first).is_some_and(|c| c.close_reason().is_none());
                let busy = e.to_string().contains("reset by peer") && kept && standing && {
                    let mut d = self.doors.lock().unwrap();
                    d.busy += 1;
                    d.busy < 30
                };
                return Err(if busy { RouteFail::Other } else { RouteFail::FirstHop });
            }
            // An empty answer: the first hop relays for nobody, or the exit it reached does not.
            // A first hop that has carried a route this visit is believed; one that has not is
            // the likelier to have said no, and it is the one left out.
            Ok(Ok(Response::Hop(_))) => {
                let proven = self.relayed.lock().unwrap().contains(&first);
                self.turned_away(if proven { exit } else { first });
                if !proven {
                    return Err(RouteFail::FirstHop);
                }
                return Err(RouteFail::NoAnswer);
            }
            _ => return Err(RouteFail::NoAnswer),
        };
        let open = pyrate_core::route::open_answer(&c, &raw).ok_or(RouteFail::Other)?;
        postcard::from_bytes::<Response>(&open).map_err(|_| RouteFail::Other)
    }

    /// Sends the hourly token to an exit through a first hop.
    async fn token_privately(&self, station: StationId, hour: u64, token: [u8; 32], nonce: u64) -> Result<()> {
        self.ask_privately(&Ask::Token { station, hour, token, nonce }).await?;
        say("counted aboard through two hops");
        Ok(())
    }

    /// The card this tab flies for one of its stations, signed by the key it keeps.
    fn card(&self, id: &StationId) -> Option<Announce> {
        let now = raw_now();
        // The station's frequency: the one its last card claimed, wherever that was signed, else
        // the one its key points at or the next free above it among the stations this tab knows.
        let freq = {
            let log = self.log.lock().unwrap();
            log.get(id).and_then(|l| l.announce.as_ref()).and_then(|a| a.freq).unwrap_or_else(|| {
                let taken: HashSet<u32> = log.iter().filter(|(k, _)| *k != id).filter_map(|(k, l)| Some(l.announce.as_ref()?.freq.unwrap_or_else(|| net::preferred_freq(k)))).collect();
                net::free_freq(id, &taken)
            })
        };
        let mine = self.mine.lock().unwrap();
        let m = mine.get(id)?;
        let pow = m.pow?;
        let archives = self.archives.lock().unwrap();
        let log = archives.get(id)?;
        let Some(Body::Colours { name, about, port, tip }) = log.colours().cloned() else { return None };
        if log.is_struck() {
            return None;
        }
        let proof = (m.key.id() != *id)
            .then(|| log.entries().iter().find(|e| matches!(&e.entry.body, Body::Deputy { key: k, .. } if *k == m.key.id().0)).and_then(|e| e.to_bytes().ok()))
            .flatten();
        if m.key.id() != *id && proof.is_none() {
            return None;
        }
        let live = log.entries().last().is_some_and(|e| matches!(e.entry.body(), Body::Live { .. }) && now.saturating_sub(e.entry.at_ms) < 25_000);
        let since = log.entries().first().map(|e| e.entry.at_ms).unwrap_or(now);
        let art = log.art();
        let (kinds, mature) = log.details().unwrap_or_default();
        Some(
            net::Card {
                station: *id, head: log.len(), name, about, port, live, at_ms: now, pow, since, proof,
                cover: art.and_then(|a| a.0).map(|a| a.hash), accent: art.map(|a| a.2), kinds, mature, tip, explicit: log.explicit(),
                tracks: Some(log.library().map(|l| l.len() as u32).unwrap_or(0)),
                named: log.named_since(),
                freq: Some(freq),
                link_only: log.link_only(),
            }
            .clipped()
            .sign(&m.key),
        )
    }

    /// The first hop of every stem this visit: anyone but the well-known harbours if it can,
    /// so no one place sees every browser broadcaster.
    fn stem_guard(&self) -> Option<EndpointId> {
        let now = self.now();
        let mut known: Vec<EndpointId> = self.log.lock().unwrap().values()
            .flat_map(|l| l.carriers.iter().filter(|(_, (_, seen))| now.saturating_sub(*seen) < 10 * 60_000).map(|(n, _)| *n).collect::<Vec<_>>())
            .filter_map(|n| EndpointId::from_bytes(&n).ok()).filter(|n| *n != self.ep.id()).collect();
        known.sort();
        known.dedup();
        let now_raw = raw_now();
        let away: HashSet<EndpointId> = self.norelay.lock().unwrap().iter().filter(|(_, t)| now_raw.saturating_sub(**t) < 30 * 60_000).map(|(n, _)| *n).collect();
        known.retain(|n| !away.contains(n));
        let mut g = self.stem_guard.lock().unwrap();
        if g.is_some_and(|x| !away.contains(&x) && (known.contains(&x) || self.harbour.contains(&x))) {
            return *g;
        }
        // Not one that has been slow or silent lately: a carrier note outlives the phone or test
        // node that sent it by ten minutes, and a guard that never answers holds up every stem.
        // One that has carried a route this visit first.
        let quick = |n: &EndpointId| self.answers.lock().unwrap().get(n).is_none_or(|ms| *ms < 5_000.0);
        let others: Vec<EndpointId> = known.iter().filter(|n| !self.harbour.contains(n) && quick(n)).copied().collect();
        let proven: Vec<EndpointId> = others.iter().filter(|n| self.relayed.lock().unwrap().contains(*n)).copied().collect();
        let pool = if !proven.is_empty() { proven } else { others };
        *g = if !pool.is_empty() { Some(pool[pick(pool.len())]) } else if !self.harbour.is_empty() { Some(self.harbour[pick(self.harbour.len())]) } else { known.first().copied() };
        *g
    }

    /// One stem for one of this tab's stations: its whole log, so whichever node ends the stem
    /// can check every entry, its fresh card, and the next of its chunks still to sail.
    async fn sail(&self, id: StationId) -> bool {
        let Some(announce) = self.card(&id) else { return false };
        // The tab's own Log shows the station at once.
        self.on_gossip(Gossip::Station(announce.clone()));
        // Only what the carriers lack goes, sixty-four entries at a time, as a phone sends it:
        // the whole log with every stem grew with every six seconds of a live show, until a
        // long broadcast no longer fitted in one.
        let landed = {
            let me = *self.ep.id().as_bytes();
            self.log.lock().unwrap().get(&id).map(|l| l.carriers.iter().filter(|(n, _)| **n != me).map(|(_, (h, _))| *h).max().unwrap_or(0)).unwrap_or(0)
        };
        let entries: Vec<Vec<u8>> = self.archives.lock().unwrap().get(&id).map(|a| a.entries().iter().skip(landed as usize).take(64).filter_map(|e| e.to_bytes().ok()).collect()).unwrap_or_default();
        // The keeper's writes this cargo carries: every one so far, since its entries were just read.
        let (chunks, batch, wrote): (Vec<(Hash, Vec<u8>)>, Vec<Hash>, u64) = {
            let mine = self.mine.lock().unwrap();
            let Some(m) = mine.get(&id) else { return false };
            let (mut out, mut hs, mut bytes) = (Vec::new(), Vec::new(), 0usize);
            for h in m.unsent.iter() {
                let Some(b) = m.chunks.get(h) else { continue };
                if out.len() >= STEM_CHUNKS || bytes + b.len() > STEM_BYTES {
                    break;
                }
                bytes += b.len();
                out.push((*h, b.clone()));
                hs.push(*h);
            }
            (out, hs, m.wrote)
        };
        // Two hops out first: the first hop forwards a sealed blob it cannot read to a second
        // node, which starts the stem. Neither learns both this tab and its station.
        let first = self.stem_guard().or_else(|| self.harbour.first().copied());
        let mut others: Vec<EndpointId> = self.route_nodes().into_iter().filter(|n| Some(*n) != first).collect();
        if let (Some(g), false) = (first, others.is_empty()) {
            // Up to three second nodes a turn, each a different one, so one that turns the cargo
            // away costs a moment and not the next turn. A guard that turns everything away,
            // or does not answer, is let go and another drawn.
            for _ in 0..3 {
                if others.is_empty() {
                    break;
                }
                let x = others.swap_remove(pick(others.len()));
                let ask = Ask::Stem { station: id, entries: entries.clone(), chunks: chunks.clone(), announce: Some(announce.clone()) };
                let Some((eph, ct, c)) = postcard::to_stdvec(&ask).ok().and_then(|p| pyrate_core::route::seal_to(x.as_bytes(), &p)) else { break };
                let Some(fwd) = postcard::to_stdvec(&Hop::Sealed { eph, ct }).ok().and_then(|blob| postcard::to_stdvec(&Hop::Forward { next: *x.as_bytes(), blob }).ok()) else { break };
                let wait = if self.relayed.lock().unwrap().contains(&g) { 30 } else { 10 };
                match timeout(Duration::from_secs(wait), self.ask(g, &Request::Hop(fwd))).await {
                    Ok(Ok(Response::Hop(raw))) if !raw.is_empty() => {
                        self.relayed.lock().unwrap().insert(g);
                        let took = pyrate_core::route::open_answer(&c, &raw).and_then(|p| postcard::from_bytes::<Response>(&p).ok());
                        if matches!(took, Some(Response::Sealed(Some(_)))) {
                            self.relayed.lock().unwrap().insert(x);
                            let mut mine = self.mine.lock().unwrap();
                            if let Some(m) = mine.get_mut(&id) {
                                m.sailed = m.sailed.max(wrote);
                                m.unsent.retain(|h| !batch.contains(h));
                                if m.unsent.is_empty() && !batch.is_empty() {
                                    m.passed = raw_now();
                                }
                            }
                            return true;
                        }
                    }
                    Ok(Ok(Response::Hop(_))) => {
                        if self.relayed.lock().unwrap().contains(&g) {
                            self.turned_away(x);
                        } else {
                            self.turned_away(g);
                            *self.stem_guard.lock().unwrap() = None;
                            break;
                        }
                    }
                    _ => {
                        // No answer at all: a guard gone quiet is left out for a while.
                        if !self.relayed.lock().unwrap().contains(&g) {
                            self.turned_away(g);
                        }
                        *self.stem_guard.lock().unwrap() = None;
                        break;
                    }
                }
            }
        }
        // A tab that never connects directly sends its station no other way: the cargo waits
        // for a second node rather than hand a first hop both this tab and its station.
        if !self.direct_ok.load(std::sync::atomic::Ordering::Relaxed) {
            say("stem: no two-hop route took the cargo; it goes again shortly");
            return false;
        }
        let hop = match postcard::to_stdvec(&Hop::Stem { station: id, entries, chunks, announce: Some(announce), hops: 0 }) {
            Ok(h) => h,
            Err(_) => return false,
        };
        let mut tried = Vec::new();
        let mut nodes: Vec<EndpointId> = self.stem_guard().into_iter().collect();
        nodes.extend(self.harbour.iter().copied());
        for n in nodes {
            if tried.contains(&n) || tried.len() >= 3 {
                continue;
            }
            tried.push(n);
            if let Ok(Ok(Response::Hop(b))) = timeout(Duration::from_secs(30), self.ask(n, &Request::Hop(hop.clone()))).await {
                if !b.is_empty() {
                    let mut mine = self.mine.lock().unwrap();
                    if let Some(m) = mine.get_mut(&id) {
                        m.sailed = m.sailed.max(wrote);
                        m.unsent.retain(|h| !batch.contains(h));
                        if m.unsent.is_empty() && !batch.is_empty() {
                            m.passed = raw_now();
                        }
                    }
                    if n != tried[0] {
                        *self.stem_guard.lock().unwrap() = Some(n);
                    }
                    return true;
                }
            }
        }
        say("stem: no node took the cargo; it goes again shortly");
        false
    }

    /// While the tab keeps a station: its card every twenty seconds, its chunks as fast as the
    /// stem takes them, and every chunk again each quarter hour while the tab stays open.
    fn sail_on(self: &Arc<Self>) {
        if self.sailing.swap(true, std::sync::atomic::Ordering::Relaxed) {
            return;
        }
        let me = self.clone();
        spawn(async move {
            // A card is due every eight to twelve minutes while nothing is sailing, so the
            // network does not learn to the second when this tab is open.
            let mut last_card: HashMap<StationId, u64> = HashMap::new();
            let mut gap: HashMap<StationId, u64> = HashMap::new();
            loop {
                let ids: Vec<StationId> = me.mine.lock().unwrap().keys().copied().collect();
                let mut busy = false;
                for id in ids {
                    let (pending, passed) = me.mine.lock().unwrap().get(&id).map(|m| (!m.unsent.is_empty() || m.wrote > m.sailed, m.passed)).unwrap_or((false, 0));
                    let now = raw_now();
                    if !pending && passed > 0 && now.saturating_sub(passed) > 15 * 60_000 {
                        if let Some(m) = me.mine.lock().unwrap().get_mut(&id) {
                            m.unsent = m.chunks.keys().copied().collect();
                            m.passed = now;
                        }
                    }
                    let due = *gap.entry(id).or_insert_with(|| 8 * 60_000 + (js_sys::Math::random() * 240_000.0) as u64);
                    if pending || now.saturating_sub(*last_card.get(&id).unwrap_or(&0)) > due {
                        if me.sail(id).await {
                            last_card.insert(id, now);
                            gap.insert(id, 8 * 60_000 + (js_sys::Math::random() * 240_000.0) as u64);
                        }
                        busy |= pending;
                    }
                }
                sleep(Duration::from_millis(if busy { 400 } else { 5_000 })).await;
            }
        });
    }

    fn sync_soon(self: &Arc<Self>, station: StationId) {
        if !self.syncing.lock().unwrap().insert(station) {
            return;
        }
        let me = self.clone();
        spawn(async move {
            let _ = me.sync(station).await;
            me.syncing.lock().unwrap().remove(&station);
        });
    }

    /// Writes one entry for a station this tab keeps, as its keeper does from the studio: signed
    /// by the deputy here (wrapped, so carriers can check it) or the station's own key, then sent
    /// along the stem at once. Returns the entry's hash.
    fn write_own(self: &Arc<Self>, st: StationId, body: Body) -> Result<Hash, JsValue> {
        let key = self.mine.lock().unwrap().get(&st).map(|m| pyrate_core::StationKey::from_seed(m.key.seed())).ok_or_else(|| js(anyhow!("not a station this browser keeps")))?;
        let h = {
            let mut archives = self.archives.lock().unwrap();
            let a = archives.get_mut(&st).ok_or_else(|| js(anyhow!("the station's log is not aboard yet")))?;
            let at = raw_now().max(a.entries().last().map(|e| e.entry.at_ms + 1).unwrap_or(0));
            let body = if key.id() == st { body } else { Body::Deputed { by: key.id().0, body: Box::new(body) } };
            a.write(&key, at, body).map_err(|e| js(anyhow!("{e}")))?.hash().map_err(|e| js(anyhow!("{e}")))?
        };
        self.clocks.lock().unwrap().remove(&st);
        if let Some(m) = self.mine.lock().unwrap().get_mut(&st) {
            m.wrote += 1;
        }
        self.sail_on();
        Ok(h)
    }

    fn describe(a: &Archive, track: &Hash) -> Option<(String, String, Vec<pyrate_core::Chunk>, u8)> {
        match a.track_entry(track)?.entry.body() {
            Body::Track { title, by, chunks, channels, .. } => Some((title.clone(), by.clone(), chunks.clone(), *channels)),
            _ => None,
        }
    }

    /// What a station plays at `at`: the chunk, where it starts, and what it belongs to.
    fn plan(&self, station: &StationId, at: u64) -> Value {
        if self.struck.lock().unwrap().contains(station) {
            return json!({ "kind": "struck" });
        }
        self.touched.lock().unwrap().insert(*station, raw_now());
        let archives = self.archives.lock().unwrap();
        let Some(a) = archives.get(station) else { return json!({ "kind": "searching" }) };
        if let Some(last) = a.entries().last() {
            if matches!(last.entry.body(), Body::Live { .. }) && self.now().saturating_sub(last.entry.at_ms) < 25_000 {
                // Only the end of the log is looked at: a station live for weeks has hundreds of
                // thousands of live entries, and the player wants the last twelve.
                let es = a.entries();
                let tail: Vec<Value> = es[es.len().saturating_sub(256)..]
                    .iter()
                    .filter_map(|e| match e.entry.body() {
                        Body::Live { chunk, channels, .. } => {
                            Some(json!({ "seq": e.entry.seq, "chunk": hex(&chunk.hash), "channels": channels, "ms": chunk.duration_ms() }))
                        }
                        _ => None,
                    })
                    .collect();
                let start = tail.len().saturating_sub(12);
                return json!({ "kind": "live", "tail": tail[start..] });
            }
        }
        let len = a.len() as u64;
        let mut clocks = self.clocks.lock().unwrap();
        if !matches!(clocks.get(station), Some((n, _)) if *n == len) {
            match Clock::new(a) {
                Ok(c) => {
                    clocks.insert(*station, (len, c));
                }
                Err(_) => {
                    clocks.remove(station);
                    return json!({ "kind": "dead air" });
                }
            }
        }
        let clock = &clocks.get(station).expect("just set").1;
        let Some(np) = clock.now(at) else {
            // Off the air until its next spell, or nothing yet to play.
            return match clock.next_on(at, at + 7 * 86_400_000).as_ref() {
                Some(b) => json!({ "kind": "off air", "back_at": b.0 }),
                None => json!({ "kind": "dead air" }),
            };
        };
        let Some((title, by, chunks, channels)) = Self::describe(a, &np.track) else { return json!({ "kind": "searching" }) };
        let Some(chunk) = chunks.get(np.chunk) else { return json!({ "kind": "dead air" }) };
        let art = a.track_art(&np.track).map(|r| hex(&r.hash));
        json!({
            "kind": "track", "track": hex(&np.track), "title": shown(&title), "by": shown(&by), "art": art,
            "index": np.chunk, "chunk": hex(&chunk.hash), "chunk_ms": chunk.duration_ms(),
            "chunk_start": at - np.chunk_offset_ms, "channels": channels,
            "position_ms": np.offset_ms, "duration_ms": np.duration_ms, "slot": np.slot,
            "next": chunks.get(np.chunk + 1).map(|c| hex(&c.hash)),
        })
    }

    fn stations(&self) -> Value {
        self.trim();
        let now = self.now();
        let banners: HashMap<StationId, String> = self
            .archives
            .lock()
            .unwrap()
            .iter()
            .filter_map(|(id, a)| Some((*id, hex(&a.art()?.1?.hash))))
            .collect();
        let pockets: HashSet<StationId> = self.pockets.lock().unwrap().keys().copied().collect();
        let log = self.log.lock().unwrap();
        let mut v: Vec<(u64, Value, Option<Announce>)> = log
            .iter()
            .filter(|(_, l)| l.fresh(now))
            .filter_map(|(id, l)| {
                let a = l.announce.as_ref()?;
                let aboard = l.aboard(now);
                let accent = a.accent.map(|c| format!("#{:02x}{:02x}{:02x}", c[0], c[1], c[2]));
                Some((aboard, json!({
                    "id": id.to_hex(), "call_sign": id.call_sign(), "name": shown(&a.name), "about": pyrate_core::chat::shown(&a.about), "mixed": pyrate_core::chat::mixed_script(&a.name),
                    // A card says live only while it is fresh: a keeper on the air sends one with every
                    // few chunks, and one that vanished mid-show leaves its last card behind.
                    "port": a.port.as_deref().map(shown), "live": a.live && now.saturating_sub(a.at_ms) < LIVE_CARD_MS, "aboard": aboard, "since": a.since, "listed": net::listed(a, raw_now()),
                    "tracks": a.tracks, "signed_ms": a.at_ms, "named": a.named, "freq": a.freq,
                    "kinds": a.kinds, "mature": a.mature, "explicit": a.explicit, "tip": a.tip,
                    "cover": a.cover.map(|h| hex(&h)), "banner": banners.get(id), "accent": accent,
                    "carriers": l.carriers.values().filter(|(_, s)| now.saturating_sub(*s) < 10 * 60_000).count(),
                    "pocket": pockets.contains(id),
                }), a.proof.is_some().then(|| a.clone())))
            })
            .collect();
        drop(log);
        // A card signed by a deputy is provisional until this tab's log of the station is
        // current and still names that deputy: shown as the log says, where it says anything,
        // with no tip address or cover from the card, and marked.
        {
            let archives = self.archives.lock().unwrap();
            for (_, j, deputy) in v.iter_mut() {
                let Some(a) = deputy else { continue };
                let log = archives.get(&a.station);
                if net::deputy_current(a, log) {
                    continue;
                }
                j["provisional"] = json!(true);
                j["tip"] = Value::Null;
                j["cover"] = Value::Null;
                let Some(log) = log else { continue };
                if let Some(Body::Colours { name, about, port, .. }) = log.colours() {
                    j["name"] = json!(shown(name));
                    j["about"] = json!(pyrate_core::chat::shown(about));
                    j["mixed"] = json!(pyrate_core::chat::mixed_script(name));
                    j["port"] = json!(port.as_deref().map(shown));
                }
                if let Some((kinds, mature)) = log.details() {
                    j["kinds"] = json!(kinds);
                    j["mature"] = json!(mature || j["mature"] == json!(true));
                }
                if let Some((cover, _, accent)) = log.art() {
                    j["cover"] = json!(cover.map(|c| hex(&c.hash)));
                    j["accent"] = json!(format!("#{:02x}{:02x}{:02x}", accent[0], accent[1], accent[2]));
                }
                j["explicit"] = json!(log.explicit() || j["explicit"] == json!(true));
            }
        }
        v.sort_by(|a, b| b.0.cmp(&a.0).then(a.1["name"].as_str().cmp(&b.1["name"].as_str())));
        json!(v.into_iter().map(|x| x.1).collect::<Vec<_>>())
    }
}

#[wasm_bindgen]
extern "C" {
    /// The page's keeper of stock between visits (IndexedDB, computers only): a kept chunk by
    /// its sealed name, or null. Missing on pages that keep none.
    #[wasm_bindgen(catch, js_name = pyrateStockGet)]
    fn stock_get(name: &str) -> Result<js_sys::Promise, JsValue>;
    /// The direct link to the guard (app.js): an offer for `peer`, its answer taken, an offer
    /// from `peer` answered, and one request over the link. Each fails at once where there is none.
    #[wasm_bindgen(catch, js_name = pyrateRtcOffer)]
    fn rtc_offer(peer: &str) -> Result<js_sys::Promise, JsValue>;
    #[wasm_bindgen(catch, js_name = pyrateRtcAnswer)]
    fn rtc_answer(peer: &str, sdp: &str) -> Result<js_sys::Promise, JsValue>;
    #[wasm_bindgen(catch, js_name = pyrateRtcAccept)]
    fn rtc_accept(peer: &str, sdp: &str) -> Result<js_sys::Promise, JsValue>;
    #[wasm_bindgen(catch, js_name = pyrateRtcAsk)]
    fn rtc_ask(peer: &str, bytes: &[u8]) -> Result<js_sys::Promise, JsValue>;
    /// The door's data channel (app.js): one request and its answer, and a control frame out.
    #[wasm_bindgen(catch, js_name = pyrateDoorAsk)]
    fn door_ask_js(bytes: &[u8]) -> Result<js_sys::Promise, JsValue>;
    #[wasm_bindgen(catch, js_name = pyrateDoorCtl)]
    fn door_ctl_js(bytes: &[u8]) -> Result<(), JsValue>;
}

impl Ship {
    fn crew_on(&self) -> bool {
        self.crew_on.load(std::sync::atomic::Ordering::Relaxed)
    }

    /// Takes `n` bytes from this minute's budget for passing things on, if they fit. A phone
    /// passes on as much as it listens to; a computer six times that.
    fn spend(&self, n: usize) -> bool {
        let now = raw_now();
        let factor = if self.mobile.load(std::sync::atomic::Ordering::Relaxed) { 1 } else { 6 };
        let mut c = self.crew.lock().unwrap();
        if c.minute.0 != now / 60_000 {
            c.minute = (now / 60_000, 0);
        }
        c.own.retain(|(t, _)| now.saturating_sub(*t) < 60_000);
        let own: u64 = c.own.iter().map(|x| x.1 as u64).sum();
        if c.minute.1 + n as u64 > factor * own.max(BUDGET_FLOOR) {
            c.refused += 1;
            return false;
        }
        c.minute.1 += n as u64;
        let share = c.minute.1 as f64 / (factor * own.max(BUDGET_FLOOR)) as f64;
        c.peak = c.peak.max(share);
        let day = now / 86_400_000;
        if c.today.0 != day {
            c.today = (day, 0);
        }
        c.today.1 += n as u64;
        true
    }

    /// A hop that reached this tab. With the switch on: a forward is passed on, a relay or a
    /// way in is opened and passed on, and a deck's ask is answered if it came from the deck's
    /// way in. Never to this tab itself, never back to the radio that asked, eight seconds at
    /// most, and within the minute's budget. With the switch off, nothing.
    async fn on_hop(self: &Arc<Self>, from: EndpointId, bytes: Vec<u8>) -> Vec<u8> {
        if !self.crew_on() || !self.spend(bytes.len()) {
            return vec![];
        }
        let Ok(hop) = postcard::from_bytes::<Hop>(&bytes) else { return vec![] };
        let out = match hop {
            Hop::Forward { next, blob } => match EndpointId::from_bytes(&next) {
                Ok(next) if matches!(postcard::from_bytes::<Hop>(&blob), Ok(Hop::Sealed { .. })) => self.pass(from, next, blob).await,
                _ => vec![],
            },
            Hop::Sealed { eph, ct } => self.on_sealed(from, eph, ct).await,
            Hop::Stem { .. } => vec![],
            // A requester that keeps this tab as its guard offers a direct link. Over it this
            // tab will take forwards from that requester and nothing else (see `rtc_serve`).
            Hop::Rtc { sdp } if sdp.len() <= 16 * 1024 => {
                // A radio that may learn this tab's address is never a way in to its decks.
                self.crew.lock().unwrap().rtc_clients.insert(from);
                match rtc_accept(&from.to_string(), &sdp) {
                    Ok(p) => match wasm_bindgen_futures::JsFuture::from(p).await {
                        Ok(v) => v.as_string().unwrap_or_default().into_bytes(),
                        Err(_) => vec![],
                    },
                    Err(_) => vec![],
                }
            }
            Hop::Rtc { .. } => vec![],
        };
        if out.is_empty() || !self.spend(out.len()) {
            return vec![];
        }
        out
    }

    async fn pass(&self, from: EndpointId, next: EndpointId, blob: Vec<u8>) -> Vec<u8> {
        if next == self.ep.id() || next == from {
            return vec![];
        }
        // A radio that could not be reached a moment ago is not tried again at once: tabs close
        // without a word.
        let now = raw_now();
        if self.crew.lock().unwrap().unreached.get(&next).is_some_and(|t| now.saturating_sub(*t) < 60_000) {
            return vec![];
        }
        match timeout(Duration::from_secs(8), self.ask(next, &Request::Hop(blob))).await {
            Ok(Ok(Response::Hop(b))) => b,
            Ok(Ok(_)) => vec![],
            _ => {
                let mut c = self.crew.lock().unwrap();
                c.unreached.retain(|_, t| now.saturating_sub(*t) < 60_000);
                c.unreached.insert(next, now);
                vec![]
            }
        }
    }

    async fn on_sealed(self: &Arc<Self>, from: EndpointId, eph: [u8; 32], ct: Vec<u8>) -> Vec<u8> {
        use pyrate_core::route::{open_lead, open_sealed, seal_answer};
        let me = *self.ep.id().as_bytes();
        if let Some((plain, c)) = open_sealed(&self.secret, &me, &eph, &ct) {
            let (next, blob) = match postcard::from_bytes::<Ask>(&plain) {
                Ok(Ask::Relay { next, blob }) => (next, blob),
                Ok(Ask::Lead { lead, blob }) => {
                    let Some(l) = open_lead(&self.secret, &me, &lead) else { return vec![] };
                    let (Ok(id), Ok(url)) = (EndpointId::from_bytes(&l.to), l.relay.parse::<iroh::RelayUrl>()) else { return vec![] };
                    if !net::relay_public(&l.relay) {
                        return vec![];
                    }
                    self.book.add_endpoint_info(iroh::EndpointAddr { id, addrs: [iroh::TransportAddr::Relay(url)].into_iter().collect() });
                    (l.to, blob)
                }
                // A tab is never an exit under its own key: what it holds is served only by its
                // decks, whose keys tie nothing to this tab.
                _ => return vec![],
            };
            let Ok(next) = EndpointId::from_bytes(&next) else { return vec![] };
            if !matches!(postcard::from_bytes::<Hop>(&blob), Ok(Hop::Sealed { .. })) {
                return vec![];
            }
            let raw = self.pass(from, next, blob).await;
            return if raw.is_empty() { raw } else { seal_answer(&c, &raw) };
        }
        let decks: Vec<(StationId, [u8; 32], [u8; 32], Option<EndpointId>)> = self.crew.lock().unwrap().decks.iter().map(|d| (d.station, d.seed, d.id, d.intro)).collect();
        for (station, seed, id, intro) in decks {
            let Some((plain, c)) = open_sealed(&seed, &id, &eph, &ct) else { continue };
            if !pyrate_core::route::deck_answers(self.crew_on(), &from, intro.as_ref()) {
                return vec![];
            }
            let Ok(ask) = postcard::from_bytes::<Ask>(&plain) else { return vec![] };
            let resp = self.deck_answer(station, ask).await;
            return seal_answer(&c, &postcard::to_stdvec(&resp).unwrap_or_default());
        }
        vec![]
    }

    /// A deck's answer: pages of its station's log, and the chunks it has held for ten minutes
    /// or kept from an earlier visit. A chunk of what is on now or next that it has not yet got,
    /// it fetches as it would for itself (never through a deck) and passes on.
    async fn deck_answer(self: &Arc<Self>, station: StationId, ask: Ask) -> Response {
        match ask {
            Ask::Log { station: st, from } if st == station => {
                let mut list = self.archives.lock().unwrap().get(&st).map(|a| a.page(from)).unwrap_or_default();
                let mut sum = 0;
                let keep = list.iter().take_while(|b| {
                    sum += b.len();
                    sum <= 256 * 1024 || sum == b.len()
                }).count();
                list.truncate(keep);
                if !list.is_empty() {
                    self.crew.lock().unwrap().served += 1;
                }
                Response::Entries(list)
            }
            Ask::Sealed { station: st, name } if st == station => {
                let now = raw_now();
                let held = self.crew.lock().unwrap().decks.iter().find(|d| d.station == st).and_then(|d| d.names.get(&name).filter(|(_, t)| now.saturating_sub(*t) < 10 * 60_000).map(|x| x.0));
                let found = match held.and_then(|h| self.hold.lock().unwrap().get(&h).map(|b| (h, b))) {
                    Some(x) => Some(x),
                    None => {
                        let kept = self.crew.lock().unwrap().stock.get(&name).filter(|(s, _)| *s == st).map(|x| x.1);
                        match kept {
                            Some(h) => match self.stock_read(&name, &h).await {
                                Some(b) => {
                                    self.crew.lock().unwrap().served_stock += 1;
                                    Some((h, b))
                                }
                                None => None,
                            },
                            None => {
                                let soon = self.upcoming(&st).into_iter().find(|h| pyrate_core::seal::name(h) == name);
                                match soon {
                                    Some(h) => self.fetch_via(&st, &h, false).await.ok().map(|b| (h, b)),
                                    None => None,
                                }
                            }
                        }
                    }
                };
                match found {
                    Some((h, b)) => {
                        self.crew.lock().unwrap().served += 1;
                        Response::Sealed(Some(pyrate_core::seal::seal(&h, &b)))
                    }
                    None => Response::Sealed(None),
                }
            }
            Ask::Log { .. } => Response::Entries(vec![]),
            _ => Response::Sealed(None),
        }
    }

    /// A kept chunk from the page's store, checked against its address.
    async fn stock_read(&self, name: &Hash, h: &Hash) -> Option<Vec<u8>> {
        let p = stock_get(&hex(name)).ok()?;
        let v = wasm_bindgen_futures::JsFuture::from(p).await.ok()?;
        let b = js_sys::Uint8Array::new(&v).to_vec();
        pyrate_core::seal::unseal(h, &b)
    }

    /// The chunks of a station from six seconds ago to a minute and a half ahead, by its clock:
    /// what its listeners are fetching now (a hidden tab fetches 75 seconds ahead).
    fn upcoming(&self, st: &StationId) -> Vec<Hash> {
        let now = self.now();
        let mut out = Vec::new();
        for k in 0..17u64 {
            let p = self.plan(st, (now + k * 6_000).saturating_sub(6_000));
            for key in ["chunk", "next"] {
                if let Some(h) = p[key].as_str().and_then(|x| unhex32(x).ok()) {
                    out.push(h);
                }
            }
            if let Some(t) = p["tail"].as_array() {
                out.extend(t.iter().filter_map(|e| e["chunk"].as_str().and_then(|x| unhex32(x).ok())));
            }
        }
        out.sort();
        out.dedup();
        out
    }

    /// Whether a radio may be this tab's first hop. A first hop and a middle that work together
    /// learn who hears what, and radios are cheap to make, a tab cheapest of all: so a first hop
    /// is a door, a radio remembered from an earlier visit, a node this tab has known for ten
    /// minutes, or a radio known only as crew for half an hour. A crowd that arrives today holds
    /// no one's first hop for its first ten minutes, and the middle is never a first hop.
    fn seasoned(&self, n: &EndpointId) -> bool {
        if self.harbour.contains(n) {
            return true;
        }
        let now = raw_now();
        let c = self.crew.lock().unwrap();
        let wait = if c.relays.contains_key(n) || !c.radios.contains_key(n) { NEWCOMER_MS } else { NEWCOMER_TAB_MS };
        c.first_seen.get(n).is_some_and(|t| now.saturating_sub(*t) >= wait)
    }

    /// A middle: a radio of the crew heard from lately, drawn at random, never this tab, never
    /// one of `not`, never one of this visit's first hops.
    fn middle(&self, not: &[EndpointId]) -> Option<EndpointId> {
        let now = raw_now();
        let me = self.ep.id();
        let away: HashSet<EndpointId> = self.norelay.lock().unwrap().iter().filter(|(_, t)| now.saturating_sub(**t) < 30 * 60_000).map(|(n, _)| *n).collect();
        let first = *self.first_hop.lock().unwrap();
        let c = self.crew.lock().unwrap();
        let pool: Vec<EndpointId> = c
            .radios
            .iter()
            .filter(|(n, (_, at))| now.saturating_sub(*at) < CREW_FRESH_MS && **n != me && !not.contains(n) && !c.guards.contains(n) && Some(**n) != first && !away.contains(*n))
            .filter(|(n, _)| !c.suspect.get(n.as_bytes()).is_some_and(|t| now.saturating_sub(*t) < SUSPECT_MS))
            .map(|(n, _)| *n)
            .collect();
        drop(c);
        // Apart from the first hop and the exit where it can be, and under the 25% cap.
        let apart: Vec<EndpointId> = pool.iter().filter(|n| first.is_none_or(|f| self.apart(n, &f)) && not.iter().all(|x| self.apart(n, x)) && self.under_cap(n)).copied().collect();
        let pool = if apart.is_empty() { pool } else { apart };
        let m = (!pool.is_empty()).then(|| pool[pick(pool.len())]);
        if let Some(m) = m {
            self.drawn(m);
        }
        m
    }

    /// This station's decks that this tab may ask, and its own: the keeper of `key` among all of
    /// them, and its note if it is another's.
    fn keeper(&self, station: &StationId, key: &Hash, rank: usize) -> Option<([u8; 32], Option<net::DeckNote>)> {
        let now = self.now();
        let raw = raw_now();
        let c = self.crew.lock().unwrap();
        let mine: Vec<[u8; 32]> = c.decks.iter().filter(|d| d.station == *station).map(|d| d.id).collect();
        let theirs: Vec<([u8; 32], net::DeckNote)> = self
            .log
            .lock()
            .unwrap()
            .get(station)
            .map(|l| l.decks.iter().filter(|(d, n)| now.saturating_sub(n.at_ms) < net::DECK_FRESH_MS && !mine.contains(d) && !c.suspect.get(*d).is_some_and(|t| raw.saturating_sub(*t) < SUSPECT_MS)).map(|(d, n)| (*d, n.clone())).collect())
            .unwrap_or_default();
        let all: Vec<[u8; 32]> = theirs.iter().map(|x| x.0).chain(mine.iter().copied()).collect();
        let k = *pyrate_core::route::keepers(&all, key, rank + 1).get(rank)?;
        Some((k, theirs.into_iter().find(|x| x.0 == k).map(|x| x.1)))
    }

    /// A request to one of a station's decks in three hops: this tab, its first hop, a middle,
    /// the deck's way in, the deck. Never when the first hop is the deck's way in.
    async fn ask_deck(&self, ask: &Ask, deck: [u8; 32], note: &net::DeckNote) -> Result<Response> {
        let nodes = self.route_nodes();
        let first = self.first_hop_for(&nodes).ok_or_else(|| anyhow!("no first hop"))?;
        let intro = EndpointId::from_bytes(&note.intro)?;
        if first == intro {
            return Err(anyhow!("the first hop leads to the deck"));
        }
        let middle = self.middle(&[first, intro]).ok_or_else(|| anyhow!("no middle"))?;
        let (hop, ciphers) = three_hops(middle.as_bytes(), &deck, &postcard::to_stdvec(ask)?, Some((&note.intro, &note.lead))).ok_or_else(|| anyhow!("seal"))?;
        let r = timeout(Duration::from_secs(8), self.ask(first, &Request::Hop(hop))).await;
        let opened = match r {
            Ok(Ok(Response::Hop(raw))) if !raw.is_empty() => {
                let mut b = Some(raw);
                for c in &ciphers {
                    b = b.filter(|x| !x.is_empty()).and_then(|x| pyrate_core::route::open_answer(c, &x));
                }
                b.and_then(|x| postcard::from_bytes::<Response>(&x).ok())
            }
            _ => None,
        };
        match opened {
            Some(r) => Ok(r),
            None => {
                // The deck, or the middle on the way to it: both are passed over for a while.
                let mut c = self.crew.lock().unwrap();
                c.suspect.insert(deck, raw_now());
                c.suspect.insert(*middle.as_bytes(), raw_now());
                Err(anyhow!("the deck gave nothing"))
            }
        }
    }

    /// A chunk from the crew's deck that keeps it, when there is one and it is not this tab's.
    async fn deck_fetch(&self, station: &StationId, hash: &Hash) -> Result<Vec<u8>> {
        let name = pyrate_core::seal::name(hash);
        // What became of each try, for the page's counts: no deck known, its own deck keeps
        // it, no route, no answer, an answer without the chunk, the chunk.
        let mark = |i: usize| self.crew.lock().unwrap().tries[i] += 1;
        let (deck, note) = match self.keeper(station, &name, 0) {
            None => {
                mark(0);
                return Err(anyhow!("no deck to ask"));
            }
            Some((_, None)) => {
                mark(1);
                return Err(anyhow!("this tab keeps it"));
            }
            Some((d, Some(n))) => (d, n),
        };
        let r = self.ask_deck(&Ask::Sealed { station: *station, name }, deck, &note).await;
        match r {
            Err(e) => {
                mark(if e.to_string() == "the deck gave nothing" { 3 } else { 2 });
                Err(e)
            }
            Ok(Response::Sealed(Some(s))) => {
                mark(5);
                pyrate_core::seal::unseal(hash, &s).ok_or_else(|| anyhow!("unopened"))
            }
            Ok(_) => {
                mark(4);
                Err(anyhow!("the deck has it not"))
            }
        }
    }

    /// The radio this deck is reached through: of the crew, heard from lately, not this tab,
    /// not its first hop or any of its guards, a radio other than a door where it can.
    fn choose_intro(&self, not: &[EndpointId]) -> Option<EndpointId> {
        let now = raw_now();
        let me = self.ep.id();
        let first = *self.first_hop.lock().unwrap();
        let away: HashSet<EndpointId> = self.norelay.lock().unwrap().iter().filter(|(_, t)| now.saturating_sub(**t) < 30 * 60_000).map(|(n, _)| *n).collect();
        let c = self.crew.lock().unwrap();
        let pool: Vec<EndpointId> = c
            .radios
            .iter()
            .filter(|(n, (_, at))| now.saturating_sub(*at) < CREW_FRESH_MS && **n != me && Some(**n) != first && !c.guards.contains(n) && !not.contains(n) && !away.contains(*n) && !c.rtc_clients.contains(*n))
            .map(|(n, _)| *n)
            .collect();
        let others: Vec<EndpointId> = pool.iter().filter(|n| !self.harbour.contains(n)).copied().collect();
        let from = if others.is_empty() { pool } else { others };
        (!from.is_empty()).then(|| from[pick(from.len())])
    }

    /// Ballast for a computer: one or two stations it does not play, drawn by lot each hour from
    /// those on the air with the fewest carriers, stations kept from an earlier visit first. A
    /// draw by lot, as a phone's ballast is, so what a tab keeps says nothing of what it hears.
    fn pick_ballast(&self) -> Vec<StationId> {
        if self.mobile.load(std::sync::atomic::Ordering::Relaxed) {
            return vec![];
        }
        let hour = raw_now() / 3_600_000;
        let tuned = *self.tuned.lock().unwrap();
        let pockets: HashSet<StationId> = self.pockets.lock().unwrap().keys().copied().collect();
        let struck = self.struck.lock().unwrap().clone();
        let (kept, played): (HashSet<StationId>, HashSet<StationId>) = {
            let c = self.crew.lock().unwrap();
            (c.stock.values().map(|x| x.0).collect(), c.played.clone())
        };
        let now = self.now();
        let mut cands: Vec<(bool, usize, [u8; 32], StationId)> = self
            .log
            .lock()
            .unwrap()
            .iter()
            .filter(|(id, l)| Some(**id) != tuned && !played.contains(id) && !pockets.contains(id) && !struck.contains(id) && l.announce.as_ref().is_some_and(|a| now.saturating_sub(a.at_ms) < 15 * 60_000))
            .map(|(id, l)| {
                let mut h = blake3::Hasher::new_keyed(&self.token_key);
                h.update(b"pyrate/tab-ballast/v1");
                h.update(&id.0);
                h.update(&hour.to_le_bytes());
                (!kept.contains(id), l.carriers.len(), *h.finalize().as_bytes(), *id)
            })
            .collect();
        cands.sort();
        cands.into_iter().take(2).map(|x| x.3).collect()
    }

    /// Every five seconds: the crew note, the decks and the ballast. With the switch off, every
    /// deck closes at once and nothing is said.
    async fn crew_tick(self: &Arc<Self>) {
        if !self.crew_on() {
            let mut c = self.crew.lock().unwrap();
            c.decks.clear();
            c.stock_out.clear();
            return;
        }
        let now = raw_now();
        // Half a minute of the visit before the tab offers to carry anything: its first Listen
        // has the tab to itself, and nobody routes through a tab that may close at once.
        let born = {
            let mut c = self.crew.lock().unwrap();
            if c.born == 0 {
                c.born = now;
            }
            c.born
        };
        if now.saturating_sub(born) < 30_000 {
            return;
        }
        let net_now = self.base_now();
        // Through a door with no relay answering, the tab is reached by forwarding to its door.
        let relay = match self.door_now() {
            Some(d) if self.door_only() => Some(format!("door:{}", hex(d.as_bytes()))),
            _ => self.ep.addr().relay_urls().next().map(|u| u.to_string()),
        };
        // The door is asked for its cards again each minute while the relays are out: there is
        // no gossip of the tab's own then, only what the door passes on.
        if let Some(d) = self.door_now().filter(|_| self.door_only()) {
            let due = {
                let mut ds = self.doors.lock().unwrap();
                let due = ds.cards_minute != now / 60_000;
                ds.cards_minute = now / 60_000;
                due
            };
            if due {
                self.cards_asked.lock().unwrap().remove(&d);
                let s = self.clone();
                spawn(async move { s.cards_from(d).await });
            }
        }
        let Some(relay) = relay else { return };
        if now.saturating_sub(self.crew.lock().unwrap().said_crew) > 120_000 {
            self.crew.lock().unwrap().said_crew = now;
            self.broadcast(&Gossip::crew(&self.secret, &relay, net_now)).await;
        }
        // A direct link to the guard, tried once a visit beside the relay: only a guard this tab
        // keeps from an earlier visit, a radio known long enough to be one (rule A).
        let first = *self.first_hop.lock().unwrap();
        if let Some(f) = first {
            let go = {
                let mut c = self.crew.lock().unwrap();
                c.kept.contains(&f) && c.rtc_tried.insert(f)
            };
            if go {
                let me = self.clone();
                spawn(async move {
                    let peer = f.to_string();
                    let Ok(p) = rtc_offer(&peer) else { return };
                    let Some(offer) = wasm_bindgen_futures::JsFuture::from(p).await.ok().and_then(|v| v.as_string()) else { return };
                    let Ok(hop) = postcard::to_stdvec(&Hop::Rtc { sdp: offer }) else { return };
                    let answer = match timeout(Duration::from_secs(10), me.ask_relay(f, &Request::Hop(hop))).await {
                        Ok(Ok(Response::Hop(b))) => String::from_utf8(b).unwrap_or_default(),
                        _ => String::new(),
                    };
                    if let Ok(p) = rtc_answer(&peer, &answer) {
                        let _ = wasm_bindgen_futures::JsFuture::from(p).await;
                    }
                });
            }
        }
        // The deck of what it plays, while it plays it: never a pocket's, never a station this
        // tab keeps itself (its own sound goes out along the stem, never from its own tab).
        let tuned = *self.tuned.lock().unwrap();
        let listening = self.listening.load(std::sync::atomic::Ordering::Relaxed);
        let play = tuned.filter(|st| {
            listening && !self.pockets.lock().unwrap().contains_key(st) && !self.mine.lock().unwrap().contains_key(st) && self.archives.lock().unwrap().get(st).is_some_and(|a| a.len() > 0)
        });
        let hour = now / 3_600_000;
        let ballast = {
            let due = self.crew.lock().unwrap().ballast_hour != hour || !self.crew.lock().unwrap().decks.iter().any(|d| d.ballast);
            if due {
                let b = self.pick_ballast();
                self.crew.lock().unwrap().ballast_hour = hour;
                Some(b)
            } else {
                None
            }
        };
        if let Some(b) = ballast.as_ref().filter(|_| !self.door_only()) {
            for st in b {
                self.sync_soon(*st);
            }
        }
        // Decks and ways in are reached through relays only: a tab that only a door reaches opens
        // none, since its door, which knows its address, would see its way in's asks arrive.
        let door_only = self.door_only();
        let want: Vec<(StationId, bool)> = if door_only {
            vec![]
        } else {
            let c = self.crew.lock().unwrap();
            let mut w: Vec<(StationId, bool)> = play.iter().map(|s| (*s, false)).collect();
            let b = ballast.clone().unwrap_or_else(|| c.decks.iter().filter(|d| d.ballast).map(|d| d.station).collect());
            w.extend(b.into_iter().filter(|s| Some(*s) != play).map(|s| (s, true)));
            w
        };
        {
            let mut c = self.crew.lock().unwrap();
            c.decks.retain(|d| want.contains(&(d.station, d.ballast)));
            for (st, b) in &want {
                if !c.decks.iter().any(|d| d.station == *st) {
                    let mut seed = [0u8; 32];
                    let _ = getrandom::fill(&mut seed);
                    let id = pyrate_core::StationKey::from_seed(seed).id().0;
                    c.decks.push(Deck { station: *st, seed, id, intro: None, lead: vec![], said: 0, ballast: *b, names: HashMap::new() });
                }
            }
        }
        // Each deck's way in, and its note every two minutes. A way in that has gone, or that has
        // become this tab's first hop, is replaced.
        let first = *self.first_hop.lock().unwrap();
        let me = *self.ep.id().as_bytes();
        let n = self.crew.lock().unwrap().decks.len();
        for i in 0..n {
            let (st, intro, said) = {
                let c = self.crew.lock().unwrap();
                let Some(d) = c.decks.get(i) else { break };
                (d.station, d.intro, d.said)
            };
            let fresh = intro.is_some_and(|x| Some(x) != first && !self.crew.lock().unwrap().rtc_clients.contains(&x) && self.crew.lock().unwrap().radios.get(&x).is_some_and(|(_, t)| now.saturating_sub(*t) < CREW_FRESH_MS) && !self.norelay.lock().unwrap().get(&x).is_some_and(|t| now.saturating_sub(*t) < 30 * 60_000));
            let intro = if fresh { intro } else { self.choose_intro(&[]) };
            let Some(intro) = intro else { continue };
            let new = !fresh;
            if !new && now.saturating_sub(said) < 120_000 {
                continue;
            }
            let lead = if new { pyrate_core::route::make_lead(intro.as_bytes(), &pyrate_core::route::Lead { to: me, relay: relay.clone() }) } else { self.crew.lock().unwrap().decks.get(i).map(|d| d.lead.clone()) };
            let Some(lead) = lead else { continue };
            let head = self.archives.lock().unwrap().get(&st).map(|a| a.len()).unwrap_or(0);
            let seed = {
                let mut c = self.crew.lock().unwrap();
                let Some(d) = c.decks.get_mut(i) else { break };
                d.intro = Some(intro);
                d.lead = lead.clone();
                d.said = now;
                d.seed
            };
            self.broadcast(&Gossip::deck(&seed, st, head, *intro.as_bytes(), lead, net_now)).await;
        }
        // Ballast comes aboard as it plays, as if listened to in silence: from a minute into
        // the visit, one chunk at a time, so it never stands in the way of what the visitor hears.
        if self.crew.lock().unwrap().ballast_busy || now.saturating_sub(born) < 60_000 {
            return;
        }
        let bal: Vec<StationId> = self.crew.lock().unwrap().decks.iter().filter(|d| d.ballast).map(|d| d.station).collect();
        for st in bal {
            let next = self.upcoming(&st).into_iter().find(|h| self.hold.lock().unwrap().get(h).is_none() && !self.crew.lock().unwrap().inflight.contains(h));
            let Some(h) = next else { continue };
            self.crew.lock().unwrap().ballast_busy = true;
            let me = self.clone();
            spawn(async move {
                let got = me.fetch_via(&st, &h, true).await;
                let mut c = me.crew.lock().unwrap();
                c.ballast_busy = false;
                if let Ok(b) = got {
                    c.stock_out.push((st, h, pyrate_core::seal::seal(&h, &b)));
                    if c.stock_out.len() > 64 {
                        c.stock_out.remove(0);
                    }
                }
            });
            return;
        }
    }

    /// Notes what this tab fetched: its own listening rate, the station's warmth, and the deck's
    /// names for what it now holds.
    fn got(&self, station: &StationId, hash: &Hash, len: usize, from_deck: bool) {
        let now = raw_now();
        // Only what the listener hears counts as its own listening, and in where it came from:
        // ballast and fetches for others are the carrying, not the listening.
        let heard = *self.tuned.lock().unwrap() == Some(*station);
        let mut c = self.crew.lock().unwrap();
        c.warm.insert(*station, now);
        if heard {
            c.played.insert(*station);
            c.own.push_back((now, len));
            if from_deck {
                c.from_decks += 1;
                c.bytes_decks += len as u64;
            } else {
                c.from_others += 1;
                c.bytes_others += len as u64;
            }
            while c.own.front().is_some_and(|x| now.saturating_sub(x.0) >= 60_000) {
                c.own.pop_front();
            }
        }
        let name = pyrate_core::seal::name(hash);
        for d in c.decks.iter_mut().filter(|d| d.station == *station) {
            d.names.retain(|_, (_, t)| now.saturating_sub(*t) < 10 * 60_000);
            d.names.insert(name, (*hash, now));
        }
    }
}

#[derive(Debug, Clone)]
struct Proto(Arc<Mutex<Option<Arc<Ship>>>>);

/// The most a tab holds of any one station's log. Real logs are a few megabytes; past this a
/// station is not followed further here.
const TAB_LOG_MAX: u64 = 32 << 20;

/// Requests a tab is answering at once, from everyone.
static SERVING: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// A count held for as long as a request is being answered.
struct Slot(&'static std::sync::atomic::AtomicUsize, Option<Arc<std::sync::atomic::AtomicUsize>>);

impl Slot {
    fn take(all: &'static std::sync::atomic::AtomicUsize, max_all: usize, mine: &Arc<std::sync::atomic::AtomicUsize>, max_mine: usize) -> Option<Slot> {
        use std::sync::atomic::Ordering::SeqCst;
        if mine.fetch_add(1, SeqCst) >= max_mine {
            mine.fetch_sub(1, SeqCst);
            return None;
        }
        if all.fetch_add(1, SeqCst) >= max_all {
            all.fetch_sub(1, SeqCst);
            mine.fetch_sub(1, SeqCst);
            return None;
        }
        Some(Slot(all, Some(mine.clone())))
    }
}

impl Drop for Slot {
    fn drop(&mut self) {
        self.0.fetch_sub(1, std::sync::atomic::Ordering::SeqCst);
        if let Some(m) = &self.1 {
            m.fetch_sub(1, std::sync::atomic::Ordering::SeqCst);
        }
    }
}

/// The most a tab reads of a request. Everything it answers is asked in under a kilobyte.
const REQUEST_MAX: usize = 64 * 1024;

impl ProtocolHandler for Proto {
    /// A tab answers little, and answers it within limits: four requests at a time from one
    /// peer and sixteen from everyone, 64 KB and ten seconds to arrive, ten seconds for the
    /// answer to go. A peer that floods a tab with streams, or asks and never reads, holds
    /// nothing for long and cannot slow the page.
    async fn accept(&self, conn: Connection) -> std::result::Result<(), AcceptError> {
        let Some(ship) = self.0.lock().unwrap().clone() else { return Ok(()) };
        let mine = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let from = conn.remote_id();
        while let Ok((mut send, mut recv)) = conn.accept_bi().await {
            let Some(slot) = Slot::take(&SERVING, 16, &mine, 4) else {
                let _ = send.reset(0u32.into());
                let _ = recv.stop(0u32.into());
                continue;
            };
            let ship = ship.clone();
            spawn(async move {
                let _slot = slot;
                let Ok(Ok(bytes)) = timeout(Duration::from_secs(10), recv.read_to_end(REQUEST_MAX)).await else { return };
                let Ok(req) = postcard::from_bytes::<Request>(&bytes) else { return };
                // A hop is the crew's: passed on, or answered by a deck, within the budget.
                let resp = match req {
                    Request::Hop(b) => Response::Hop(ship.on_hop(from, b).await),
                    other => ship.serve(other),
                };
                if let Ok(out) = postcard::to_stdvec(&resp) {
                    match timeout(Duration::from_secs(10), send.write_all(&out)).await {
                        Ok(Ok(())) => {
                            let _ = send.finish();
                        }
                        _ => {
                            let _ = send.reset(0u32.into());
                        }
                    }
                }
            });
        }
        Ok(())
    }
}

impl std::fmt::Debug for Ship {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("Ship")
    }
}

/// The tab's node, as the page sees it.
#[wasm_bindgen]
pub struct Radio {
    ship: Arc<Ship>,
    _router: Router,
    /// A recording being measured, a block at a time: the meter, where sound first and last
    /// rose above dead air, the frames seen, and the channels.
    meter: Mutex<Option<(ebur128::EbuR128, Option<usize>, usize, usize, usize)>>,
}

#[wasm_bindgen]
impl Radio {
    /// Comes aboard. `harbour` is the first peers' node ids, by commas or lines; `token_key`
    /// is 64 hex characters the page keeps, so a reload is not counted twice.
    ///
    /// A harbour entry may name its relay, as `<id>@<relay url>`, so it is found without a
    /// lookup. `relays`, when not empty, replaces the usual relays: for a private network.
    pub async fn start(harbour: String, token_key: String, relays: String) -> Result<Radio, JsValue> {
        let book = iroh::address_lookup::MemoryLookup::new();
        let book2 = book.clone();
        let mut ids = Vec::new();
        let mut unplaced = HashSet::new();
        for item in harbour.split(|c: char| c == ',' || c.is_whitespace()).filter(|s| !s.is_empty()) {
            let (id, relay) = item.split_once('@').map(|(a, b)| (a, Some(b))).unwrap_or((item, None));
            let Ok(id) = id.parse::<EndpointId>() else { continue };
            match relay.and_then(|r| r.parse::<iroh::RelayUrl>().ok()) {
                Some(url) => book.add_endpoint_info(iroh::EndpointAddr { id, addrs: [iroh::TransportAddr::Relay(url)].into_iter().collect() }),
                None => {
                    unplaced.insert(id);
                }
            }
            ids.push(id);
        }
        let harbour = ids;
        let token_key = unhex32(&token_key).map_err(js)?;
        let custom: Vec<iroh::RelayUrl> = relays.split(',').filter_map(|r| r.trim().parse().ok()).collect();
        if custom.iter().any(|u| !net::relay_public(u.as_str())) {
            net::LOCAL_RELAYS_OK.store(true, std::sync::atomic::Ordering::Relaxed);
        }
        let relays = if custom.is_empty() {
            let m = iroh::defaults::prod::default_relay_map();
            for r in CREW_RELAYS {
                if let Ok(url) = r.parse::<iroh::RelayUrl>() {
                    m.insert(url.clone(), Arc::new(iroh::RelayConfig::from(url)));
                }
            }
            m
        } else {
            iroh::RelayMap::from_iter(custom)
        };
        // A fresh node key every visit: nothing ties one visit to the next.
        let mut seed = [0u8; 32];
        getrandom::fill(&mut seed).map_err(|e| JsValue::from_str(&e.to_string()))?;
        // The tab publishes its address nowhere: it reaches out through relays, and peers answer
        // on the same connection or learn of it through gossip. It looks peers up first in its
        // own book (harbours and carriers' signed notes). number0's server is asked only about
        // the harbours.
        // Only a harbour named without its relay is looked up at all.
        let doors: Arc<HashSet<EndpointId>> = Arc::new(unplaced);
        let ep = Endpoint::builder(presets::Minimal)
            .secret_key(SecretKey::from_bytes(&seed))
            .relay_mode(iroh::RelayMode::Custom(relays))
            .address_lookup(book.clone())
            .address_lookup(DoorsOnly(doors))
            .bind()
            .await
            .map_err(|e| JsValue::from_str(&format!("bind: {e}")))?;
        let gossip = GossipNet::builder().max_message_size(128 * 1024).spawn(ep.clone());
        let proto = Proto(Arc::new(Mutex::new(None)));
        let router = Router::builder(ep.clone()).accept(ALPN, proto.clone()).accept(GOSSIP_ALPN, gossip.clone()).spawn();
        let ship = Arc::new(Ship {
            ep,
            gossip: gossip.clone(),
            book: book2,
            flock: Mutex::new(None),
            flock_off: std::sync::atomic::AtomicI64::new(0),
            flock_station: Mutex::new(None),
            pockets: Mutex::new(HashMap::new()),
            pocket_tx: Mutex::new(HashMap::new()),
            rooms: Mutex::new(HashMap::new()),
            harbour: harbour.clone(),
            tx: Mutex::new(None),
            log: Mutex::new(HashMap::new()),
            archives: Mutex::new(HashMap::new()),
            hold: Mutex::new(Hold::default()),
            conns: Mutex::new(HashMap::new()),
            neighbours: Mutex::new(HashSet::new()),
            token_key,
            tuned: Mutex::new(None),
            tokens_sent: Mutex::new(HashMap::new()),
            syncing: Mutex::new(HashSet::new()),
            drift: Mutex::new(pyrate_core::drift::Drift::new()),
            failed: Mutex::new(HashMap::new()),
            listening: std::sync::atomic::AtomicBool::new(false),
            first_hop: Mutex::new(None),
            suspect: Mutex::new(HashMap::new()),
            direct_ok: std::sync::atomic::AtomicBool::new(false),
            clocks: Mutex::new(HashMap::new()),
            touched: Mutex::new(HashMap::new()),
            struck: Mutex::new(HashSet::new()),
            last_trim: std::sync::atomic::AtomicU64::new(0),
            mine: Mutex::new(HashMap::new()),
            stem_guard: Mutex::new(None),
            sailing: std::sync::atomic::AtomicBool::new(false),
            cards_asked: Mutex::new(HashSet::new()),
            hop_misses: std::sync::atomic::AtomicU32::new(0),
            connecting: Mutex::new(HashSet::new()),
            answers: Mutex::new(HashMap::new()),
            norelay: Mutex::new(HashMap::new()),
            relayed: Mutex::new(HashSet::new()),
            secret: seed,
            crew_on: std::sync::atomic::AtomicBool::new(true),
            mobile: std::sync::atomic::AtomicBool::new(false),
            crew: Mutex::new(Crew::default()),
            doors: Mutex::new(Doors::default()),
        });
        *proto.0.lock().unwrap() = Some(ship.clone());
        // The harbours this copy was built with are named by the copy itself.
        {
            let mut d = ship.doors.lock().unwrap();
            for h in &ship.harbour {
                d.intro.insert(*h, SRC_BUILT_IN);
            }
        }

        // The crew's tick: its note, its decks and its ballast, every five seconds.
        {
            let s = ship.clone();
            spawn(async move {
                loop {
                    sleep(Duration::from_secs(5)).await;
                    s.crew_tick().await;
                }
            });
        }
        // The harbours are asked for the cards they know at once, so the dial fills in one round
        // trip instead of waiting for gossip.
        for h in ship.harbour.iter().take(3) {
            let (s, h) = (ship.clone(), *h);
            spawn(async move { s.cards_from(h).await });
        }
        let s2 = ship.clone();
        spawn(async move {
            say(&format!("node {} up, joining the Log through {} harbour peers", s2.ep.id().fmt_short(), s2.harbour.len()));
            let sub = match gossip.subscribe(TopicId::from_bytes(net::log_topic()), s2.harbour.clone()).await {
                Ok(s) => s,
                Err(e) => return say(&format!("gossip: {e}")),
            };
            let (tx, mut rx) = sub.split();
            *s2.tx.lock().unwrap() = Some(tx.clone());
            let s3 = s2.clone();
            spawn(async move {
                loop {
                    sleep(Duration::from_secs(45)).await;
                    let mut peers = s3.harbour.clone();
                    let carriers: Vec<[u8; 32]> = s3.log.lock().unwrap().values().flat_map(|l| l.carriers.keys().copied()).collect();
                    peers.extend(carriers.iter().filter_map(|n| EndpointId::from_bytes(n).ok()));
                    peers.retain(|p| *p != s3.ep.id());
                    peers.sort();
                    peers.dedup();
                    peers.truncate(16);
                    let _ = tx.join_peers(peers).await;
                    s3.count_me().await;
                }
            });
            while let Some(ev) = rx.next().await {
                let msg = match ev {
                    Ok(Event::Received(m)) => m,
                    Ok(Event::NeighborUp(n)) => {
                        s2.neighbours.lock().unwrap().insert(n);
                        if s2.log.lock().unwrap().len() < 8 && s2.cards_asked.lock().unwrap().len() < 6 {
                            let s4 = s2.clone();
                            spawn(async move { s4.cards_from(n).await });
                        }
                        continue;
                    }
                    Ok(Event::NeighborDown(n)) => {
                        s2.neighbours.lock().unwrap().remove(&n);
                        continue;
                    }
                    _ => continue,
                };
                let Ok(g) = postcard::from_bytes::<Gossip>(&msg.content) else { continue };
                let Some(g) = g.from_network(s2.now(), msg.delivered_from.as_bytes()) else { continue };
                if let Some(st) = s2.on_gossip(g) {
                    if *s2.tuned.lock().unwrap() == Some(st) {
                        s2.sync_soon(st);
                    }
                }
            }
        });
        Ok(Radio { ship, _router: router, meter: Mutex::new(None) })
    }

    pub fn id(&self) -> String {
        self.ship.ep.id().to_string()
    }

    /// Milliseconds on the network's clock.
    pub fn now(&self) -> f64 {
        self.ship.now() as f64
    }

    pub fn neighbours(&self) -> u32 {
        self.ship.neighbours.lock().unwrap().len() as u32
    }

    /// Every station heard of lately, most aboard first, as JSON.
    pub fn stations(&self) -> String {
        self.ship.stations().to_string()
    }

    /// Puts a station on: its log is fetched and kept current, and this tab is counted aboard.
    pub fn tune(&self, id: &str) -> Result<(), JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        *self.ship.tuned.lock().unwrap() = Some(st);
        self.ship.sync_soon(st);
        let s = self.ship.clone();
        spawn(async move { s.count_me().await });
        Ok(())
    }

    /// A station the visitor may tune next (the ones either side on the dial): its log comes
    /// aboard now, through two hops, so tuning it needs only its first chunk. Tells nobody the
    /// tab listens there: nothing is counted.
    pub fn warm(&self, id: &str) -> Result<(), JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        if self.ship.pockets.lock().unwrap().contains_key(&st) || self.ship.archives.lock().unwrap().contains_key(&st) {
            return Ok(());
        }
        self.ship.sync_soon(st);
        Ok(())
    }

    /// Whether the visitor is listening. A tab is counted aboard only while it plays: looking
    /// at a station on the dial tells nobody anything.
    pub fn listening(&self, on: bool) {
        self.ship.listening.store(on, std::sync::atomic::Ordering::Relaxed);
        if on {
            let s = self.ship.clone();
            spawn(async move { s.count_me().await });
        }
    }

    pub fn untune(&self) {
        *self.ship.tuned.lock().unwrap() = None;
    }

    // ---- Broadcasting from the tab ----
    //
    // A station raised here is a key made here. The master's 24 words go to the visitor once,
    // to write down; the tab signs with a deputy whose seed the page keeps in this browser.
    // Everything the station airs goes out along the stem, as from a phone: the tab never shows
    // the network its own station first, and it serves no one.

    /// Raises a station. Returns its id, call sign, the master's 24 words and the deputy's seed.
    /// `pass`, if not empty, is a passphrase on top of the words: see `StationKey::from_words`.
    pub fn raise(&self, name: &str, about: &str, kinds: &str, mature: bool, explicit: bool, pass: &str) -> Result<String, JsValue> {
        let name = name.trim();
        if name.is_empty() || name.chars().count() > 40 {
            return Err(js(anyhow!("a station needs a name of forty letters or fewer")));
        }
        let (master, phrase) = pyrate_core::StationKey::generate_with(pass).map_err(|e| js(anyhow!("{e}")))?;
        let deputy = pyrate_core::StationKey::generate().map_err(|e| js(anyhow!("{e}")))?;
        let id = master.id();
        let now = raw_now();
        let mut a = Archive::new(id);
        let kinds: Vec<String> = kinds.split(',').map(|k| k.trim().to_lowercase()).filter(|k| !k.is_empty()).take(5).collect();
        let w = |a: &mut Archive, at: u64, b: Body| a.write(&master, at, b).map(|_| ()).map_err(|e| js(anyhow!("{e}")));
        w(&mut a, now, Body::Colours { name: name.into(), about: about.trim().chars().take(140).collect(), port: None, tip: None })?;
        // A plain label: what the deputy is written into a public log, so it says nothing of
        // where the station was raised.
        w(&mut a, now + 1, Body::Deputy { key: deputy.id().0, label: "deputy".into() })?;
        if !kinds.is_empty() || mature {
            w(&mut a, now + 2, Body::Details { kinds, mature })?;
        }
        if explicit {
            w(&mut a, now + 3, Body::Rating { explicit: true })?;
        }
        // Every new station starts off the dial, heard by its link (Dylan); its keeper lists it
        // once it is made, and it joins the dial a day after it first went on the air.
        w(&mut a, now + 4, Body::Listing { link_only: true })?;
        self.ship.archives.lock().unwrap().insert(id, a);
        let seed = hex(&deputy.seed());
        self.ship.mine.lock().unwrap().insert(id, Mine { key: deputy, pow: None, chunks: HashMap::new(), unsent: VecDeque::new(), passed: 0, wrote: 0, sailed: 0 });
        Ok(json!({ "id": id.to_hex(), "call_sign": id.call_sign(), "words": phrase, "deputy": seed }).to_string())
    }

    /// Takes back a station this browser keeps, from its deputy's seed. Resolves once its log is
    /// aboard from the network, to whether this deputy still speaks for it.
    pub fn adopt(&self, id: &str, deputy: &str) -> Result<js_sys::Promise, JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let key = pyrate_core::StationKey::from_seed(unhex32(deputy).map_err(js)?);
        let s = self.ship.clone();
        Ok(wasm_bindgen_futures::future_to_promise(async move {
            let _ = timeout(Duration::from_secs(40), s.sync(st)).await;
            let ok = s.archives.lock().unwrap().get(&st).is_some_and(|a| a.deputies().contains(&key.id().0) && !a.is_struck());
            if ok {
                s.mine.lock().unwrap().entry(st).or_insert(Mine { key, pow: None, chunks: HashMap::new(), unsent: VecDeque::new(), passed: 0, wrote: 0, sailed: 0 });
            }
            Ok(JsValue::from_bool(ok))
        }))
    }

    /// Takes a station back from its 24 words on a new browser: its log comes aboard, then the
    /// master appoints a fresh deputy here. Resolves to the id and the new deputy's seed.
    pub fn restore(&self, words: &str, pass: &str) -> Result<js_sys::Promise, JsValue> {
        let master = pyrate_core::StationKey::from_words(words, pass).map_err(|e| js(anyhow!("those are not a station's 24 words: {e}")))?;
        let s = self.ship.clone();
        Ok(wasm_bindgen_futures::future_to_promise(async move {
            let id = master.id();
            // Exits are drawn afresh each try: keep asking for forty seconds, so one that has
            // not yet heard of the station does not end the search.
            let until = raw_now() + 40_000;
            while raw_now() < until {
                let _ = timeout(Duration::from_secs(15), s.sync(id)).await;
                if s.archives.lock().unwrap().get(&id).is_some_and(|a| a.len() > 0) {
                    break;
                }
                sleep(Duration::from_secs(3)).await;
            }
            let deputy = pyrate_core::StationKey::generate().map_err(|e| js(anyhow!("{e}")))?;
            {
                let mut archives = s.archives.lock().unwrap();
                let Some(a) = archives.get_mut(&id).filter(|a| a.len() > 0) else {
                    return Err(js(anyhow!("the station's log could not be found yet; try again in a minute")));
                };
                let at = raw_now().max(a.entries().last().map(|e| e.entry.at_ms + 1).unwrap_or(0));
                a.write(&master, at, Body::Deputy { key: deputy.id().0, label: "deputy".into() }).map_err(|e| js(anyhow!("{e}")))?;
            }
            let seed = hex(&deputy.seed());
            s.mine.lock().unwrap().insert(id, Mine { key: deputy, pow: None, chunks: HashMap::new(), unsent: VecDeque::new(), passed: 0, wrote: 1, sailed: 0 });
            Ok(JsValue::from_str(&json!({ "id": id.to_hex(), "call_sign": id.call_sign(), "deputy": seed }).to_string()))
        }))
    }

    /// The station's proof of work, a slice at a time so the page stays awake: tries `count`
    /// numbers from `start` and returns the one that works, or -1.
    pub fn pow_step(&self, id: &str, start: f64, count: u32) -> Result<f64, JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let start = start as u64;
        // The first nonce good enough to exist goes on the card at once, so the station plays by
        // its link within a second; the search goes on, and each better one replaces it, until
        // one earns the station its place in the list. Only then is the work done.
        for n in start..start + count as u64 {
            let bits = net::pow_bits(&st, n);
            if bits >= net::POW_BITS {
                let better = {
                    let mut mine = self.ship.mine.lock().unwrap();
                    match mine.get_mut(&st) {
                        Some(m) if m.pow.is_none_or(|p| net::pow_bits(&st, p) < bits) => {
                            m.pow = Some(n);
                            // The card that earns the listing sails at once, not with the next
                            // card minutes later.
                            if bits >= net::LIST_BITS {
                                m.wrote += 1;
                            }
                            true
                        }
                        _ => false,
                    }
                };
                if better {
                    self.ship.sail_on();
                }
                if bits >= net::LIST_BITS {
                    return Ok(n as f64);
                }
            }
        }
        Ok(-1.0)
    }

    /// A proof of work found before, as the page kept it. Checked before it is taken.
    /// Whether carriers may be asked directly when two hops cannot be had.
    pub fn set_direct_ok(&self, on: bool) {
        self.ship.direct_ok.store(on, std::sync::atomic::Ordering::Relaxed);
    }

    /// "Carry the radio while you listen", and whether this is a phone. Off closes every deck at
    /// once and passes nothing on from then.
    pub fn set_crew(&self, on: bool, mobile: bool) {
        self.ship.crew_on.store(on, std::sync::atomic::Ordering::Relaxed);
        self.ship.mobile.store(mobile, std::sync::atomic::Ordering::Relaxed);
        if !on {
            let mut c = self.ship.crew.lock().unwrap();
            c.decks.clear();
            c.stock_out.clear();
        }
    }

    /// A request that came over a direct link from `peer`, a requester that keeps this tab as
    /// its guard: a forward is passed on as one that came over the relay would be, within the
    /// same budget; anything else is refused, so the link is only ever the guard's leg.
    /// Doors this copy was built with, remembered from an earlier visit, or handed over by
    /// whoever served the page: signed notes in hex, by commas. `src` is 1 (built in), 2
    /// (remembered) or 4 (served). Returns how many were taken.
    pub fn doors_add(&self, list: &str, src: u32) -> u32 {
        let now = self.ship.base_now();
        let mut d = self.ship.doors.lock().unwrap();
        let mut n = 0;
        for h in list.split(|c: char| c == ',' || c.is_whitespace()).filter(|h| !h.is_empty() && h.len() <= 2048) {
            let Ok(raw) = (0..h.len() / 2).map(|i| u8::from_str_radix(h.get(2 * i..2 * i + 2).unwrap_or("x"), 16)).collect::<Result<Vec<u8>, _>>() else { continue };
            let Ok(g) = postcard::from_bytes::<Gossip>(&raw) else { continue };
            let Some(note) = g.door_checked(now) else { continue };
            d.add(note, raw, if matches!(src, SRC_BUILT_IN | SRC_REMEMBERED) { src } else { SRC_SERVED });
            n += 1;
        }
        n
    }

    /// The doors the link that opened the page carried, as JSON [{addr, fp}]: hints only.
    pub fn doors_hint(&self, list: &str) {
        let v: Vec<Value> = serde_json::from_str(list).unwrap_or_default();
        let mut d = self.ship.doors.lock().unwrap();
        for x in v.iter().take(3) {
            if let (Some(a), Some(f)) = (x["addr"].as_str(), x["fp"].as_str().and_then(|f| unhex32(f).ok())) {
                d.hints.push((a.to_string(), f));
            }
        }
    }

    /// The doors this tab knows, as JSON, best first: those it may draw as a guard, then the
    /// longest open. Each with its address, fingerprint, note (hex) and whether it is trusted.
    pub fn doors(&self, n: u32) -> String {
        let now = self.ship.base_now();
        let d = self.ship.doors.lock().unwrap();
        let mut v: Vec<(bool, u64, Value)> = d
            .known
            .iter()
            .filter(|(_, (note, _, _))| now.saturating_sub(note.at_ms) < net::DOOR_FRESH_MS)
            .map(|(k, (note, raw, _))| (d.trusted(k), note.since, json!({ "id": hex(k), "addr": note.addr.to_string(), "fp": hex(&note.fp), "since": note.since, "app": note.app, "link": note.link, "note": hex(raw), "trusted": d.trusted(k), "aged": now.saturating_sub(note.since) >= DOOR_AGE_MS })))
            .collect();
        v.sort_by(|a, b| b.0.cmp(&a.0).then(a.1.cmp(&b.1)));
        json!(v.into_iter().take(n as usize).map(|x| x.2).collect::<Vec<_>>()).to_string()
    }

    /// The door's channel is open: `note` is what the door sent first, `fp` the fingerprint this
    /// tab dialled (hex), `src` how the tab came to dial it (1 built in, 2 remembered, 3 a link).
    /// The note must be the door's own and name that fingerprint. Returns the tab's hello.
    pub fn door_up(&self, note: &[u8], fp: &str, src: u32) -> Result<Vec<u8>, JsValue> {
        let ctl: net::DoorCtl = postcard::from_bytes(note).map_err(|_| JsValue::from_str("not a door"))?;
        let net::DoorCtl::Note(raw) = ctl else { return Err(JsValue::from_str("not a door")) };
        let g: Gossip = postcard::from_bytes(&raw).map_err(|_| JsValue::from_str("not a door"))?;
        let d = g.door_checked(self.ship.base_now()).ok_or_else(|| JsValue::from_str("the door's note does not hold"))?;
        if hex(&d.fp) != fp.to_ascii_lowercase() {
            return Err(JsValue::from_str("the door is not the one dialled"));
        }
        let id = EndpointId::from_bytes(&d.node).map_err(|_| JsValue::from_str("id"))?;
        {
            let mut ds = self.ship.doors.lock().unwrap();
            ds.add(d.clone(), raw.clone(), src.clamp(SRC_BUILT_IN, SRC_LINK));
            ds.open = Some((id, raw_now()));
            ds.intro.entry(id).or_insert(src_of(&id));
        }
        self.ship.cards_asked.lock().unwrap().remove(&id);
        let s = self.ship.clone();
        spawn(async move { s.cards_from(id).await });
        let at_ms = self.ship.base_now();
        let me = *self.ship.ep.id().as_bytes();
        let key = pyrate_core::StationKey::from_seed(self.ship.secret);
        let sig = key.sign(&net::door_hello_message(&d.node, &me, at_ms)).to_vec();
        say(&format!("through the door {} at {}", id.fmt_short(), d.addr));
        postcard::to_stdvec(&net::DoorCtl::Hello { node: me, at_ms, sig }).map_err(|e| JsValue::from_str(&e.to_string()))
    }

    /// The door's channel closed.
    pub fn door_down(&self) {
        let d = self.ship.doors.lock().unwrap().open.take();
        if let Some((d, _)) = d {
            let mut f = self.ship.first_hop.lock().unwrap();
            if *f == Some(d) {
                *f = None;
            }
        }
    }

    /// A control frame from the door: gossip it passes on.
    pub fn door_ctl(&self, bytes: &[u8]) {
        let Ok(net::DoorCtl::Gossip(raw)) = postcard::from_bytes::<net::DoorCtl>(bytes) else { return };
        let Some(d) = self.ship.door_now() else { return };
        let Ok(g) = postcard::from_bytes::<Gossip>(&raw) else { return };
        let Some(g) = g.from_network(self.ship.now(), d.as_bytes()) else { return };
        self.ship.doors.lock().unwrap().now_from = src_of(&d);
        let st = self.ship.on_gossip(g);
        self.ship.doors.lock().unwrap().now_from = 0;
        if let Some(st) = st {
            if *self.ship.tuned.lock().unwrap() == Some(st) {
                self.ship.sync_soon(st);
            }
        }
    }

    /// A request from the door, for this tab: a hop another radio forwarded to it, which it
    /// answers as it would one over a relay (a middle's pass, or nothing).
    pub fn door_serve(&self, bytes: &[u8]) -> js_sys::Promise {
        let s = self.ship.clone();
        let bytes = bytes.to_vec();
        wasm_bindgen_futures::future_to_promise(async move {
            let from = s.door_now().ok_or_else(|| JsValue::from_str("no door"))?;
            let out = match postcard::from_bytes::<Request>(&bytes) {
                Ok(Request::Hop(b)) if s.crew_on() => {
                    s.doors.lock().unwrap().served += 1;
                    s.on_hop(from, b).await
                }
                _ => vec![],
            };
            let r = postcard::to_stdvec(&Response::Hop(out)).unwrap_or_default();
            Ok(js_sys::Uint8Array::from(&r[..]).into())
        })
    }

    /// Doors a shared link of `station` may carry, as JSON [{addr, fp}]: at most two, only doors
    /// this tab trusts whose owners let links name them, never one that carries the station, and
    /// drawn by the same rule for every station (oldest open first), so a link's doors say
    /// nothing about what is shared.
    pub fn doors_for_link(&self, station: &str) -> String {
        let st = unhex32(station).ok();
        let carriers: HashSet<[u8; 32]> = st.and_then(|st| self.ship.log.lock().unwrap().get(&StationId(st)).map(|l| l.carriers.keys().copied().collect())).unwrap_or_default();
        let now = self.ship.base_now();
        let d = self.ship.doors.lock().unwrap();
        let mut v: Vec<&net::DoorNote> = d.known.iter().filter(|(k, (n, _, _))| d.trusted(k) && n.link && !carriers.contains(*k) && now.saturating_sub(n.at_ms) < net::DOOR_FRESH_MS).map(|(_, (n, _, _))| n).collect();
        v.sort_by_key(|n| (n.since, n.node));
        json!(v.into_iter().take(2).map(|n| json!({ "addr": n.addr.to_string(), "fp": hex(&n.fp) })).collect::<Vec<_>>()).to_string()
    }

    /// What the doors have done this visit, as JSON: counts only.
    pub fn door_stats(&self) -> String {
        let only = self.ship.door_only();
        let first = *self.ship.first_hop.lock().unwrap();
        let d = self.ship.doors.lock().unwrap();
        json!({ "open": d.open.map(|(x, _)| x.to_string()), "door_only": only, "asks": d.asks, "bytes": d.bytes, "served": d.served,
            "known": d.known.len(), "trusted": d.known.keys().filter(|k| d.trusted(k)).count(), "behind": d.behind.len(),
            "routes": d.routes, "routes_shared": d.routes_shared, "capped": d.capped, "relay_ok_ago": if d.relay_ok == 0 { -1.0 } else { raw_now().saturating_sub(d.relay_ok) as f64 },
            "first_hop": first.map(|f| f.to_string()) }).to_string()
    }

    pub fn rtc_serve(&self, peer: &str, bytes: &[u8]) -> js_sys::Promise {
        let s = self.ship.clone();
        let (peer, bytes) = (peer.to_string(), bytes.to_vec());
        wasm_bindgen_futures::future_to_promise(async move {
            let from: EndpointId = peer.parse().map_err(|_| JsValue::from_str("peer"))?;
            let out = match postcard::from_bytes::<Request>(&bytes) {
                Ok(Request::Hop(b)) if s.crew_on() && matches!(postcard::from_bytes::<Hop>(&b), Ok(Hop::Forward { .. })) => {
                    s.crew.lock().unwrap().rtc_served += 1;
                    s.on_hop(from, b).await
                }
                _ => {
                    s.crew.lock().unwrap().rtc_refused += 1;
                    vec![]
                }
            };
            let r = postcard::to_stdvec(&Response::Hop(out)).unwrap_or_default();
            Ok(js_sys::Uint8Array::from(&r[..]).into())
        })
    }

    /// What this tab has carried, as JSON: for the page's line and for the crowd test. Counts
    /// only; never who.
    pub fn crew_stats(&self) -> String {
        let c = self.ship.crew.lock().unwrap();
        let day = raw_now() / 86_400_000;
        json!({
            "on": self.ship.crew_on.load(std::sync::atomic::Ordering::Relaxed),
            "passed_today": if c.today.0 == day { c.today.1 } else { 0 },
            "from_decks": c.from_decks, "from_others": c.from_others,
            "bytes_decks": c.bytes_decks, "bytes_others": c.bytes_others,
            "served": c.served, "served_stock": c.served_stock, "refused": c.refused, "peak_share": c.peak, "tries": c.tries, "rtc_bytes": c.rtc_bytes, "relay_first_bytes": c.relay_first_bytes, "rtc_refused": c.rtc_refused, "rtc_served": c.rtc_served,
            "first_hop": self.ship.first_hop.lock().unwrap().map(|f| f.to_string()), "kept": c.kept.iter().map(|k| k.to_string()).collect::<Vec<_>>(),
            "decks": c.decks.iter().filter(|d| d.intro.is_some()).map(|d| json!({ "station": d.station.to_hex(), "ballast": d.ballast })).collect::<Vec<_>>(),
            "crew": c.radios.len(),
            "known_decks": self.ship.tuned.lock().unwrap().and_then(|st| self.ship.log.lock().unwrap().get(&st).map(|l| l.decks.len())).unwrap_or(0),
        })
        .to_string()
    }

    /// Ballast chunks fetched since the last call, for the page to keep (computers only): each
    /// as the station's id, the chunk's sealed name and its sealed bytes, postcard-encoded.
    pub fn stock_take(&self) -> Vec<u8> {
        let mut out: Vec<(StationId, Hash, Vec<u8>)> = std::mem::take(&mut self.ship.crew.lock().unwrap().stock_out);
        // Never what the listener plays, even a station that was ballast until a moment ago.
        let tuned = *self.ship.tuned.lock().unwrap();
        let played = self.ship.crew.lock().unwrap().played.clone();
        out.retain(|x| Some(x.0) != tuned && !played.contains(&x.0));
        let named: Vec<(StationId, Hash, Hash, Vec<u8>)> = out.into_iter().map(|(st, h, b)| (st, pyrate_core::seal::name(&h), h, b)).collect();
        postcard::to_stdvec(&named).unwrap_or_default()
    }

    /// What the page kept from earlier visits, by station: sealed names and addresses, so a
    /// returning tab serves its stock at once. The bytes stay with the page until asked for.
    pub fn stock_index(&self, list: &[u8]) -> u32 {
        let Ok(items) = postcard::from_bytes::<Vec<(StationId, Hash, Hash)>>(list) else { return 0 };
        let mut c = self.ship.crew.lock().unwrap();
        let n = items.len();
        for (st, name, h) in items.into_iter().take(200_000) {
            c.stock.insert(name, (st, h));
        }
        n as u32
    }

    /// The stations this tab keeps as ballast now, as JSON ids: the page keeps their logs.
    pub fn ballast(&self) -> String {
        let c = self.ship.crew.lock().unwrap();
        json!(c.decks.iter().filter(|d| d.ballast).map(|d| d.station.to_hex()).collect::<Vec<_>>()).to_string()
    }

    /// Up to twenty nodes that answered quickly, as id@relay: the page keeps them and tries them
    /// beside the doors next time. Nodes only (their relay from their own signed note): a tab's
    /// id lasts one visit.
    pub fn quick_peers(&self) -> String {
        let answers = self.ship.answers.lock().unwrap().clone();
        let c = self.ship.crew.lock().unwrap();
        let mut v: Vec<(f64, String)> = c.relays.iter().filter_map(|(id, r)| answers.get(id).filter(|ms| **ms < 3_000.0).map(|ms| (*ms, format!("{id}@{r}")))).collect();
        v.sort_by(|a, b| a.0.total_cmp(&b.0));
        json!(v.into_iter().take(20).map(|x| x.1).collect::<Vec<_>>()).to_string()
    }

    /// This visit's guards (its first hops), at most three, as id@relay where the relay is known:
    /// the page keeps them so the next visit draws its first hop from them again.
    pub fn guards(&self) -> String {
        let c = self.ship.crew.lock().unwrap();
        let v: Vec<String> = c.guards.iter().rev().take(3).map(|g| c.relays.get(g).map_or(g.to_string(), |r| format!("{g}@{r}"))).collect();
        json!(v).to_string()
    }

    /// The guards kept from earlier visits, as the page kept them.
    pub fn set_guards(&self, list: &str) {
        let v: Vec<String> = serde_json::from_str(list).unwrap_or_default();
        let ids: Vec<EndpointId> = v.iter().filter_map(|s| s.split('@').next()?.parse().ok()).take(3).collect();
        self.ship.crew.lock().unwrap().kept = ids;
    }

    /// How many radios have said in the last ten minutes that they carry a station, decks
    /// included. From the public notes; nothing of who.
    pub fn carried_by(&self, id: &str) -> Result<u32, JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let now = self.ship.now();
        let log = self.ship.log.lock().unwrap();
        Ok(log.get(&st).map(|l| l.carriers.values().filter(|(_, seen)| now.saturating_sub(*seen) < 10 * 60_000).count() + l.decks.values().filter(|d| now.saturating_sub(d.at_ms) < net::DECK_FRESH_MS).count()).unwrap_or(0) as u32)
    }

    pub fn set_pow(&self, id: &str, n: f64) -> Result<bool, JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        // Kept work counts only once it earns a listing; less, and the search runs again.
        if net::pow_bits(&st, n as u64) < net::LIST_BITS {
            return Ok(false);
        }
        if let Some(m) = self.ship.mine.lock().unwrap().get_mut(&st) {
            m.pow = Some(n as u64);
        }
        self.ship.sail_on();
        Ok(true)
    }

    /// Measures a recording a block at a time, so an hour of it never sits in memory twice:
    /// `level_begin`, then `level_feed` with interleaved 48 kHz samples, then `level_end`.
    /// The rule is the app's: -16 LUFS, no more than 18 dB of gain, no peak past -1 dBFS, and
    /// dead air under -50 dBFS trimmed from the head and tail.
    pub fn level_begin(&self, channels: u32) -> Result<(), JsValue> {
        let ch = channels.clamp(1, 2) as usize;
        let m = ebur128::EbuR128::new(ch as u32, 48_000, ebur128::Mode::I | ebur128::Mode::SAMPLE_PEAK).map_err(|e| js(anyhow!("{e:?}")))?;
        *self.meter.lock().unwrap() = Some((m, None, 0, 0, ch));
        Ok(())
    }

    pub fn level_feed(&self, pcm: &[f32]) -> Result<(), JsValue> {
        let mut g = self.meter.lock().unwrap();
        let (m, first, last, at, ch) = g.as_mut().ok_or_else(|| js(anyhow!("no recording is being measured")))?;
        let _ = m.add_frames_f32(pcm);
        for (i, f) in pcm.chunks_exact(*ch).enumerate() {
            if f.iter().any(|s| s.abs() > 0.003_16) {
                first.get_or_insert(*at + i);
                *last = *at + i + 1;
            }
        }
        *at += pcm.len() / *ch;
        Ok(())
    }

    /// The gain, and the first and last frame to keep, as JSON.
    pub fn level_end(&self) -> Result<String, JsValue> {
        let (m, first, last, frames, ch) = self.meter.lock().unwrap().take().ok_or_else(|| js(anyhow!("no recording is being measured")))?;
        let Some(first) = first else { return Err(js(anyhow!("the recording is silent"))) };
        let lufs = m.loudness_global().unwrap_or(f64::NEG_INFINITY);
        let peak = (0..ch as u32).filter_map(|c| m.sample_peak(c).ok()).fold(0.0f64, f64::max);
        let mut gain_db = if lufs.is_finite() { (-16.0 - lufs).min(18.0) } else { 0.0 };
        if peak > 0.0 {
            gain_db = gain_db.min(-1.0 - 20.0 * peak.log10());
        }
        // A breath of tail is kept so endings are not clipped.
        Ok(json!({ "gain": 10f64.powf(gain_db / 20.0), "start": first, "end": (last + 14_400).min(frames) }).to_string())
    }

    /// Puts a recording on one of this tab's stations: `frames` are its 20 ms Opus packets, each
    /// after its length as a big-endian u16, in order. They are cut into six-second chunks,
    /// named by their fingerprints and signed into the log; then they sail. Returns the track.
    pub fn add_track(&self, id: &str, title: &str, by: &str, source: &str, channels: u8, bitrate: u32, frames: &[u8]) -> Result<String, JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let key = self.ship.mine.lock().unwrap().get(&st).map(|m| pyrate_core::StationKey::from_seed(m.key.seed())).ok_or_else(|| js(anyhow!("not a station this browser keeps")))?;
        let (mut chunks, mut bytes) = (Vec::new(), Vec::new());
        let (mut cur, mut n, mut at) = (Vec::with_capacity(64 * 1024), 0u16, 0usize);
        while at + 2 <= frames.len() {
            let len = u16::from_be_bytes([frames[at], frames[at + 1]]) as usize;
            if len == 0 || at + 2 + len > frames.len() {
                return Err(js(anyhow!("a broken frame in the recording")));
            }
            cur.extend_from_slice(&frames[at..at + 2 + len]);
            n += 1;
            at += 2 + len;
            if n == pyrate_core::audio::FRAMES_PER_CHUNK {
                let c = pyrate_core::Chunk::of(&cur, n);
                chunks.push(c);
                bytes.push(std::mem::take(&mut cur));
                n = 0;
            }
        }
        if n > 0 {
            chunks.push(pyrate_core::Chunk::of(&cur, n));
            bytes.push(cur);
        }
        if chunks.is_empty() {
            return Err(js(anyhow!("the recording is empty")));
        }
        let track = {
            let mut archives = self.ship.archives.lock().unwrap();
            let a = archives.get_mut(&st).ok_or_else(|| js(anyhow!("the station's log is not aboard yet")))?;
            let at = raw_now().max(a.entries().last().map(|e| e.entry.at_ms + 1).unwrap_or(0));
            let body = Body::Track {
                title: title.trim().chars().take(120).collect(),
                by: by.trim().chars().take(120).collect(),
                source: source.trim().chars().take(280).collect(),
                channels: channels.clamp(1, 2),
                bitrate,
                chunks: chunks.clone(),
            };
            // A deputy wraps what it writes, so carriers can check the deputy's signature.
            let body = if key.id() == st { body } else { Body::Deputed { by: key.id().0, body: Box::new(body) } };
            a.write(&key, at, body).map_err(|e| js(anyhow!("{e}")))?.hash().map_err(|e| js(anyhow!("{e}")))?
        };
        self.ship.clocks.lock().unwrap().remove(&st);
        {
            let mut mine = self.ship.mine.lock().unwrap();
            let m = mine.get_mut(&st).unwrap();
            for (c, b) in chunks.iter().zip(bytes) {
                m.unsent.push_back(c.hash);
                // The tab can play its own recordings at once, from its hold.
                self.ship.hold.lock().unwrap().put(c.hash, b.clone());
                m.chunks.insert(c.hash, b);
            }
        }
        self.ship.sail_on();
        Ok(hex(&track))
    }

    /// Live from the tab's microphone: one six-second chunk of 20 ms Opus packets (framed as for
    /// `add_track`), signed into the log as it is, and sent along the stem at once.
    pub fn live_chunk(&self, id: &str, frames: &[u8], channels: u8, bitrate: u32) -> Result<(), JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let key = self.ship.mine.lock().unwrap().get(&st).map(|m| pyrate_core::StationKey::from_seed(m.key.seed())).ok_or_else(|| js(anyhow!("not a station this browser keeps")))?;
        let (mut n, mut at) = (0u16, 0usize);
        while at + 2 <= frames.len() {
            let len = u16::from_be_bytes([frames[at], frames[at + 1]]) as usize;
            if len == 0 || at + 2 + len > frames.len() {
                return Err(js(anyhow!("a broken frame")));
            }
            at += 2 + len;
            n += 1;
        }
        if n == 0 || n > pyrate_core::audio::FRAMES_PER_CHUNK {
            return Err(js(anyhow!("not a chunk")));
        }
        let c = pyrate_core::Chunk::of(frames, n);
        {
            let mut archives = self.ship.archives.lock().unwrap();
            let a = archives.get_mut(&st).ok_or_else(|| js(anyhow!("the station's log is not aboard yet")))?;
            let at = raw_now().max(a.entries().last().map(|e| e.entry.at_ms + 1).unwrap_or(0));
            let body = Body::Live { chunk: c.clone(), channels: channels.clamp(1, 2), bitrate };
            let body = if key.id() == st { body } else { Body::Deputed { by: key.id().0, body: Box::new(body) } };
            a.write(&key, at, body).map_err(|e| js(anyhow!("{e}")))?;
        }
        self.ship.clocks.lock().unwrap().remove(&st);
        self.ship.hold.lock().unwrap().put(c.hash, frames.to_vec());
        if let Some(m) = self.ship.mine.lock().unwrap().get_mut(&st) {
            m.chunks.insert(c.hash, frames.to_vec());
            // The air comes first: a live chunk goes ahead of any recording still sailing.
            m.unsent.push_front(c.hash);
        }
        self.ship.sail_on();
        Ok(())
    }

    /// The end of a broadcast from this tab: listeners go back to the schedule at once.
    pub fn live_end(&self, id: &str) -> Result<(), JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let key = self.ship.mine.lock().unwrap().get(&st).map(|m| pyrate_core::StationKey::from_seed(m.key.seed())).ok_or_else(|| js(anyhow!("not a station this browser keeps")))?;
        {
            let mut archives = self.ship.archives.lock().unwrap();
            let a = archives.get_mut(&st).ok_or_else(|| js(anyhow!("the station's log is not aboard yet")))?;
            if !matches!(a.entries().last().map(|e| e.entry.body()), Some(Body::Live { .. })) {
                return Ok(());
            }
            let at = raw_now().max(a.entries().last().map(|e| e.entry.at_ms + 1).unwrap_or(0));
            let body = if key.id() == st { Body::LiveEnd } else { Body::Deputed { by: key.id().0, body: Box::new(Body::LiveEnd) } };
            a.write(&key, at, body).map_err(|e| js(anyhow!("{e}")))?;
        }
        self.ship.clocks.lock().unwrap().remove(&st);
        self.ship.sail_on();
        Ok(())
    }

    // ---- The keeper's studio: what a station says of itself, its art, its schedule, its
    // notices and its library, changed from the tab as the app changes them, entry for entry.

    /// One of this tab's stations as its keeper edits it: colours, details, art, programme,
    /// notices and library, as JSON.
    pub fn station_info(&self, id: &str) -> Result<String, JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let archives = self.ship.archives.lock().unwrap();
        let a = archives.get(&st).ok_or_else(|| js(anyhow!("the station's log is not aboard yet")))?;
        let (name, about, port, tip) = match a.colours() {
            Some(Body::Colours { name, about, port, tip }) => (name.clone(), about.clone(), port.clone(), tip.clone()),
            _ => Default::default(),
        };
        let (kinds, mature) = a.details().unwrap_or_default();
        let art = a.art();
        let library: Vec<Value> = a.library().map_err(|e| js(anyhow!("{e}")))?.into_iter().map(|(h, e)| {
            let (title, by) = pyrate_core::page::describe_track(a, &h);
            json!({ "track": hex(&h), "title": shown(&title), "by": shown(&by), "added_ms": e.entry.at_ms })
        }).collect();
        let notices: Vec<Value> = a.notices(self.ship.now()).into_iter().map(|(h, at, text)| json!({ "id": hex(&h), "at_ms": at, "text": shown(&text) })).collect();
        Ok(json!({
            "name": shown(&name), "about": shown(&about), "port": port.as_deref().map(shown), "tip": tip,
            "kinds": kinds, "mature": mature, "explicit": a.explicit(),
            "cover": art.and_then(|x| x.0).map(|r| hex(&r.hash)), "banner": art.and_then(|x| x.1).map(|r| hex(&r.hash)),
            "programme": a.programme().as_ref().map(pyrate_core::page::programme_json),
            "library": library, "notices": notices,
        }).to_string())
    }

    /// The station's name, a line about it, its home port and its tip address. An empty port or
    /// tip takes it down.
    pub fn colours_set(&self, id: &str, name: &str, about: &str, port: &str, tip: &str) -> Result<(), JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let name = name.trim();
        if name.is_empty() || name.chars().count() > 40 {
            return Err(js(anyhow!("a station needs a name of forty letters or fewer")));
        }
        let opt = |s: &str, n: usize| Some(s.trim().chars().take(n).collect::<String>()).filter(|s| !s.is_empty());
        let tip = opt(tip, 200);
        if tip.as_deref().is_some_and(|t| t.len() > 200) {
            return Err(js(anyhow!("that address is too long to be a tip address")));
        }
        self.ship.write_own(st, Body::Colours { name: name.into(), about: about.trim().chars().take(140).collect(), port: opt(port, 120), tip })?;
        Ok(())
    }

    /// The station's kinds, up to five, whether it calls itself mature, and whether explicit.
    /// The rating is written only when it changes, as the app does.
    pub fn details_set(&self, id: &str, kinds: &str, mature: bool, explicit: bool) -> Result<(), JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let kinds: Vec<String> = kinds.split(',').map(|k| k.trim().to_lowercase().chars().take(32).collect::<String>()).filter(|k| !k.is_empty()).take(5).collect();
        self.ship.write_own(st, Body::Details { kinds, mature })?;
        if self.ship.archives.lock().unwrap().get(&st).map(|a| a.explicit()) != Some(explicit) {
            self.ship.write_own(st, Body::Rating { explicit })?;
        }
        Ok(())
    }

    /// Whether the station keeps itself off the public dial, heard by its link and by those who
    /// keep it. Otherwise it joins the dial a day after it first went on the air.
    pub fn listing_set(&self, id: &str, link_only: bool) -> Result<(), JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        if self.ship.archives.lock().unwrap().get(&st).map(|a| a.link_only()) != Some(link_only) {
            self.ship.write_own(st, Body::Listing { link_only })?;
        }
        Ok(())
    }

    /// New art for the station: `kind` is "cover" or "banner", `raw` any picture the page has
    /// already turned upright and cropped. It is drawn again here by the app's own code, so what
    /// travels is the same plain JPEG of the same size the app makes, with nothing else in it;
    /// a cover sets the colour the station's pages are drawn in. Returns the picture's hash.
    pub fn art_set(&self, id: &str, kind: &str, raw: &[u8]) -> Result<String, JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let banner = kind == "banner";
        let p = pyrate_core::art::prepare(raw, if banner { pyrate_core::art::Kind::Banner } else { pyrate_core::art::Kind::Cover }).map_err(|e| js(anyhow!("{e}")))?;
        let hash = *blake3::hash(&p.jpeg).as_bytes();
        let (mut cover, mut ban, mut accent) = self.ship.archives.lock().unwrap().get(&st).and_then(|a| a.art()).unwrap_or((None, None, [0xED, 0xE4, 0xCE]));
        let r = Some(pyrate_core::ArtRef { hash, w: p.w, h: p.h });
        if banner {
            ban = r;
        } else {
            cover = r;
            accent = p.accent;
        }
        {
            let mut mine = self.ship.mine.lock().unwrap();
            let m = mine.get_mut(&st).ok_or_else(|| js(anyhow!("not a station this browser keeps")))?;
            // The picture sails like a chunk, and the tab shows it at once from its hold.
            self.ship.hold.lock().unwrap().put(hash, p.jpeg.clone());
            m.chunks.insert(hash, p.jpeg);
            m.unsent.push_back(hash);
        }
        self.ship.write_own(st, Body::Art { cover, banner: ban, accent })?;
        Ok(hex(&hash))
    }

    /// Takes the cover or the banner down. With the cover goes the station's colour, back to bone.
    pub fn art_clear(&self, id: &str, kind: &str) -> Result<(), JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let Some((mut cover, mut banner, mut accent)) = self.ship.archives.lock().unwrap().get(&st).and_then(|a| a.art()) else { return Ok(()) };
        if kind == "banner" {
            banner = None;
        } else {
            cover = None;
            accent = [0xED, 0xE4, 0xCE];
        }
        self.ship.write_own(st, Body::Art { cover, banner, accent })?;
        Ok(())
    }

    /// The station's schedule, as the JSON the app writes and `page` reads back: its mode, its
    /// hours, its slots and its time-zone table.
    pub fn programme_set(&self, id: &str, programme: &str) -> Result<(), JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let v: Value = serde_json::from_str(programme).map_err(|e| js(anyhow!("{e}")))?;
        let p = pyrate_core::page::programme_from(&v).map_err(|e| js(anyhow!("{e}")))?;
        self.ship.write_own(st, Body::Programme(p))?;
        Ok(())
    }

    /// A word to listeners on the station's page, until `until_ms`, or until taken down if zero.
    /// Returns the notice's id.
    pub fn notice_post(&self, id: &str, text: &str, until_ms: f64) -> Result<String, JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let text: String = text.trim().chars().take(600).collect();
        if text.is_empty() {
            return Err(js(anyhow!("a notice needs words")));
        }
        Ok(hex(&self.ship.write_own(st, Body::Notice { text, until_ms: until_ms.max(0.0) as u64 })?))
    }

    pub fn notice_remove(&self, id: &str, notice: &str) -> Result<(), JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        self.ship.write_own(st, Body::Unnotice { notice: unhex32(notice).map_err(js)? })?;
        Ok(())
    }

    /// Takes a recording out of the library. Carriers may keep its chunks until they drop them.
    pub fn withdraw(&self, id: &str, track: &str) -> Result<(), JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        self.ship.write_own(st, Body::Withdraw { track: unhex32(track).map_err(js)? })?;
        Ok(())
    }

    /// The stations this tab keeps, with what is still to sail and whether the network has them.
    pub fn mine(&self) -> String {
        let now = self.ship.now();
        let mine = self.ship.mine.lock().unwrap();
        let archives = self.ship.archives.lock().unwrap();
        let log = self.ship.log.lock().unwrap();
        let me = *self.ship.ep.id().as_bytes();
        let v: Vec<Value> = mine.iter().map(|(id, m)| {
            let a = archives.get(id);
            let name = a.and_then(|a| match a.colours() { Some(Body::Colours { name, .. }) => Some(name.clone()), _ => None }).unwrap_or_default();
            let len = a.map(|a| a.len()).unwrap_or(0);
            let tracks = a.and_then(|a| a.library().ok()).map(|l| l.len()).unwrap_or(0);
            let landed = log.get(id).map(|l| l.carriers.iter().filter(|(n, (_, seen))| **n != me && now.saturating_sub(*seen) < 10 * 60_000).map(|(_, (h, _))| *h).max().unwrap_or(0)).unwrap_or(0);
            let carriers = log.get(id).map(|l| l.carriers.iter().filter(|(n, (_, seen))| **n != me && now.saturating_sub(*seen) < 10 * 60_000).count()).unwrap_or(0);
            json!({ "id": id.to_hex(), "call_sign": id.call_sign(), "name": shown(&name), "entries": len, "tracks": tracks, "landed": landed, "carriers": carriers,
                    "unsent": m.unsent.len(), "chunks": m.chunks.len(), "pow": m.pow.is_some(), "listable": m.pow.is_some_and(|p| net::pow_bits(id, p) >= net::LIST_BITS),
                    "link_only": a.is_some_and(|a| a.link_only()), "dial_at": a.and_then(|a| a.entries().first()).map(|e| e.entry.at_ms + net::list_age_ms()) })
        }).collect();
        json!(v).to_string()
    }

    /// Brings a station's log up to date. Resolves to how many entries came in.
    pub fn sync(&self, id: &str) -> Result<js_sys::Promise, JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let s = self.ship.clone();
        Ok(wasm_bindgen_futures::future_to_promise(async move {
            s.sync(st).await.map(|n| JsValue::from(n as u32)).map_err(js)
        }))
    }

    /// For `?debug` only: each log this tab holds, with its entries and bytes.
    pub fn log_sizes(&self) -> String {
        let a = self.ship.archives.lock().unwrap();
        json!(a.iter().map(|(k, v)| json!([k.call_sign(), v.len(), v.bytes()])).collect::<Vec<_>>()).to_string()
    }

    /// For `?debug` only: the first page of a station's log along every route this tab knows,
    /// all at once, as JSON of [first, exit, ms or -1].
    pub fn route_check(&self, id: &str, chunk: &str) -> Result<js_sys::Promise, JsValue> {
        let station = StationId(unhex32(id).map_err(js)?);
        let chunk: Option<Hash> = unhex32(chunk).ok();
        let s = self.ship.clone();
        Ok(wasm_bindgen_futures::future_to_promise(async move {
            let nodes = s.route_nodes();
            let pairs: Vec<(EndpointId, EndpointId)> = nodes.iter().flat_map(|a| nodes.iter().filter(move |b| *b != a).map(move |b| (*a, *b))).collect();
            let runs = pairs.iter().map(|(a, b)| {
                let s = s.clone();
                let (a, b) = (*a, *b);
                async move {
                    let t = raw_now();
                    let ok = match chunk {
                        Some(h) => matches!(s.via(a, b, &Ask::Sealed { station, name: pyrate_core::seal::name(&h) }, 0).await, Ok(Response::Sealed(Some(_)))),
                        None => matches!(s.via(a, b, &Ask::Log { station, from: 0 }, 0).await, Ok(Response::Entries(l)) if !l.is_empty()),
                    };
                    json!([a.fmt_short().to_string(), b.fmt_short().to_string(), if ok { (raw_now() - t) as i64 } else { -1 }])
                }
            });
            let mut all: n0_future::FuturesUnordered<_> = runs.map(Box::pin).collect();
            let mut out = Vec::new();
            while let Some(r) = n0_future::StreamExt::next(&mut all).await {
                out.push(r);
            }
            Ok(JsValue::from_str(&json!(out).to_string()))
        }))
    }

    /// The live chunks after `seq`, up to the end of the broadcast: the last words of a show
    /// that has ended, for a listener still playing it.
    pub fn live_after(&self, id: &str, seq: f64) -> Result<String, JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let archives = self.ship.archives.lock().unwrap();
        let Some(a) = archives.get(&st) else { return Ok("[]".into()) };
        let es = a.entries();
        let out: Vec<Value> = es[es.len().saturating_sub(256)..]
            .iter()
            .filter(|e| e.entry.seq as f64 > seq)
            .filter_map(|e| match e.entry.body() {
                Body::Live { chunk, channels, .. } => Some(json!({ "seq": e.entry.seq, "chunk": hex(&chunk.hash), "channels": channels, "ms": chunk.duration_ms() })),
                _ => None,
            })
            .collect();
        Ok(json!(out).to_string())
    }

    /// A station's log as it stands, for the page to keep between visits: every entry signed,
    /// so a kept copy is checked again, entry by entry, when it comes back.
    pub fn log_export(&self, id: &str) -> Result<Vec<u8>, JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let raw: Vec<Vec<u8>> = self.ship.archives.lock().unwrap().get(&st).map(|a| a.entries().iter().filter_map(|e| e.to_bytes().ok()).collect()).unwrap_or_default();
        postcard::to_stdvec(&raw).map_err(|e| js(anyhow!("{e}")))
    }

    /// A kept copy of a station's log back into the tab, before the network is asked: only the
    /// entries past what the tab holds, each checked against the station's key. The network
    /// then sends only what is newer. Returns how many entries were taken.
    pub fn log_import(&self, id: &str, bytes: &[u8]) -> Result<u32, JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let raw: Vec<Vec<u8>> = postcard::from_bytes(bytes).map_err(|e| js(anyhow!("{e}")))?;
        let (n, _) = self.ship.take_entries(st, raw);
        self.ship.clocks.lock().unwrap().remove(&st);
        Ok(n as u32)
    }

    /// Whether this tab holds a station's log yet.
    pub fn has_log(&self, id: &str) -> bool {
        unhex32(id).is_ok_and(|b| self.ship.archives.lock().unwrap().contains_key(&StationId(b)))
    }

    /// What a station plays at `at` (network milliseconds), as JSON.
    pub fn plan(&self, id: &str, at: f64) -> Result<String, JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        Ok(self.ship.plan(&st, at as u64).to_string())
    }

    /// A chunk or a picture by its fingerprint, checked against it. Resolves to its bytes.
    pub fn fetch(&self, id: &str, hash: &str) -> Result<js_sys::Promise, JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let h = unhex32(hash).map_err(js)?;
        let s = self.ship.clone();
        Ok(wasm_bindgen_futures::future_to_promise(async move {
            let b = s.fetch(&st, &h).await.map_err(js)?;
            Ok(js_sys::Uint8Array::from(&b[..]).into())
        }))
    }

    /// A QR code for a link, as JSON: its width in modules and a string of 1s and 0s.
    pub fn qr(&self, text: &str) -> Result<String, JsValue> {
        let code = qrcode::QrCode::new(text.as_bytes()).map_err(|e| js(anyhow!("{e}")))?;
        let bits: String = code.to_colors().iter().map(|c| if *c == qrcode::Color::Dark { '1' } else { '0' }).collect();
        Ok(json!({ "size": code.width(), "bits": bits }).to_string())
    }

    /// A station's page as JSON: on now, up next, the week's schedule and its notices,
    /// worked out in this tab from the station's own log. Times are network milliseconds.
    pub fn page(&self, id: &str, days: u32) -> Result<String, JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let archives = self.ship.archives.lock().unwrap();
        let Some(a) = archives.get(&st) else { return Ok("null".into()) };
        let v = pyrate_core::page::page_of(a, self.ship.now(), days.min(28) as u64).map_err(|e| js(anyhow!("{e}")))?;
        Ok(v.to_string())
    }

    /// Joins a station's chatter. Resolves when the tab is in the room.
    pub fn chat_join(&self, id: &str) -> Result<js_sys::Promise, JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let s = self.ship.clone();
        Ok(wasm_bindgen_futures::future_to_promise(async move {
            s.chat_join(st).await.map_err(js)?;
            Ok(JsValue::TRUE)
        }))
    }

    pub fn chat_leave(&self, id: &str) {
        if let Ok(b) = unhex32(id) {
            self.ship.rooms.lock().unwrap().remove(&StationId(b));
        }
    }

    /// The room as JSON: whether the tab is in it, how many it is linked to, and the lines.
    pub fn chat_read(&self, id: &str) -> Result<String, JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let me = self.ship.voice(&st).id().0;
        let rooms = self.ship.rooms.lock().unwrap();
        let Some(r) = rooms.get(&st) else { return Ok(json!({ "joined": false, "lines": [] }).to_string()) };
        let archives = self.ship.archives.lock().unwrap();
        let a = archives.get(&st);
        let lines: Vec<Value> = r.lines.iter().map(|l| {
            let keeper = l.line.from == st.0 || a.is_some_and(|a| a.deputies().contains(&l.line.from));
            let (kind, text, track, title) = match &l.line.say {
                pyrate_core::chat::Say::Text(t) => ("text", pyrate_core::chat::shown(t), None, None),
                pyrate_core::chat::Say::Cheer => ("cheer", String::new(), None, None),
                pyrate_core::chat::Say::Request { track, note } => ("request", pyrate_core::chat::shown(note), Some(hex(track)), a.map(|a| pyrate_core::page::describe_track(a, track).0).filter(|t| !t.is_empty())),
                pyrate_core::chat::Say::Hail { .. } => ("hail", String::new(), None, None),
            };
            json!({ "id": hex(&pyrate_core::chat::id(l)), "voice": StationId(l.line.from).call_sign(), "name": pyrate_core::chat::shown_name(&l.line.name), "at_ms": l.line.at_ms,
                    "kind": kind, "text": text, "track": track, "title": title.map(shown), "keeper": keeper, "mine": l.line.from == me })
        }).collect();
        Ok(json!({ "joined": true, "neighbours": r.neighbours, "voice": StationId(me).call_sign(), "lines": lines }).to_string())
    }

    /// Hails the keeper: a short voice note sealed so only the station's keys open it.
    pub fn chat_hail(&self, id: &str, audio: &[u8], mime: &str, name: &str) -> Result<js_sys::Promise, JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let mut to = vec![st.0];
        if let Some(a) = self.ship.archives.lock().unwrap().get(&st) {
            to.extend(a.deputies());
        }
        let say = pyrate_core::chat::hail(&to, audio, mime).ok_or_else(|| JsValue::from_str("a hail is twenty seconds at most"))?;
        let l = pyrate_core::chat::speak(&self.ship.voice(&st), &st, name, self.ship.now(), say);
        let bytes = self.ship.room_bytes(&st, postcard::to_allocvec(&l).map_err(|e| js(anyhow!("{e}")))?);
        let tx = self.ship.rooms.lock().unwrap().get(&st).map(|r| r.tx.clone()).ok_or_else(|| JsValue::from_str("join the chatter first"))?;
        Ok(wasm_bindgen_futures::future_to_promise(async move {
            tx.broadcast(bytes.into()).await.map_err(|e| js(anyhow!("{e}")))?;
            Ok(JsValue::TRUE)
        }))
    }

    /// Says something in a station's chatter: kind is text, cheer or request.
    pub fn chat_send(&self, id: &str, kind: &str, text: &str, track: &str, name: &str) -> Result<js_sys::Promise, JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let say = match kind {
            "cheer" => pyrate_core::chat::Say::Cheer,
            "request" => pyrate_core::chat::Say::Request { track: unhex32(track).map_err(js)?, note: text.into() },
            _ if text.trim().is_empty() => return Err(JsValue::from_str("nothing to say")),
            _ => pyrate_core::chat::Say::Text(text.into()),
        };
        let l = pyrate_core::chat::speak(&self.ship.voice(&st), &st, name, self.ship.now(), say);
        let bytes = self.ship.room_bytes(&st, postcard::to_allocvec(&l).map_err(|e| js(anyhow!("{e}")))?);
        let tx = self.ship.rooms.lock().unwrap().get(&st).map(|r| r.tx.clone()).ok_or_else(|| JsValue::from_str("join the chatter first"))?;
        self.ship.hear(st, l);
        Ok(wasm_bindgen_futures::future_to_promise(async move {
            tx.broadcast(bytes.into()).await.map_err(|e| js(anyhow!("{e}")))?;
            Ok(JsValue::TRUE)
        }))
    }

    /// Follows a flock's host from its link (#flock=<id>@<relay>~<code>): this tab's clock
    /// is set to the host's over pings, and it plays what the host plays.
    pub fn flock_join(&self, link: &str) -> Result<(), JsValue> {
        let tail = link.split("flock=").nth(1).ok_or_else(|| JsValue::from_str("not a flock link"))?;
        let (who, code_hex) = tail.split_once('~').ok_or_else(|| JsValue::from_str("not a flock link"))?;
        let (id, relay) = who.split_once('@').unwrap_or((who, ""));
        let host: EndpointId = id.parse().map_err(|_| JsValue::from_str("not a flock link"))?;
        let mut code = [0u8; 8];
        pyrate_core::unhex_into(code_hex, &mut code).ok_or_else(|| JsValue::from_str("bad code"))?;
        if let Some(url) = relay_from_link(relay) {
            self.ship.book.add_endpoint_info(iroh::EndpointAddr { id: host, addrs: [iroh::TransportAddr::Relay(url)].into_iter().collect() });
        }
        *self.ship.flock.lock().unwrap() = Some((host, code));
        let s = self.ship.clone();
        spawn(async move {
            while *s.flock.lock().unwrap() == Some((host, code)) {
                let mut best: Option<(u64, i64, Option<StationId>)> = None;
                for _ in 0..8 {
                    let t0 = s.base_now();
                    let Ok(Response::Flock { now_ms: h, station }) = s.ask(host, &Request::Flock { code }).await else { continue };
                    let t1 = s.base_now();
                    if h == 0 {
                        break;
                    }
                    let rtt = t1.saturating_sub(t0);
                    // A host is trusted with the room's timing, not with the date: five
                    // minutes either way at most, as the network's own clock allows.
                    let off = (h as i64 + rtt as i64 / 2 - t1 as i64).clamp(-300_000, 300_000);
                    if best.as_ref().is_none_or(|b| rtt < b.0) {
                        best = Some((rtt, off, station));
                    }
                }
                if let Some((_, off, station)) = best {
                    let old = s.flock_off.load(std::sync::atomic::Ordering::Relaxed);
                    s.flock_off.store(if old == 0 { off } else { old + (off - old) / 4 }, std::sync::atomic::Ordering::Relaxed);
                    *s.flock_station.lock().unwrap() = station;
                }
                sleep(Duration::from_secs(20)).await;
            }
        });
        Ok(())
    }

    /// Leaves the flock: the tab goes back to the network's own clock and its own station.
    pub fn flock_leave(&self) {
        *self.ship.flock.lock().unwrap() = None;
        self.ship.flock_off.store(0, std::sync::atomic::Ordering::Relaxed);
        *self.ship.flock_station.lock().unwrap() = None;
    }

    /// Joins a pocket station from its invitation (#pocket=...). Resolves to the station's id.
    pub fn pocket_join(&self, link: &str) -> Result<js_sys::Promise, JsValue> {
        let (st, key, host) = pyrate_core::pocket::read_invitation(link).ok_or_else(|| JsValue::from_str("not an invitation"))?;
        let st = StationId(st);
        let (id, relay) = host.split_once('@').unwrap_or((host.as_str(), ""));
        let hosts: Vec<EndpointId> = id.parse().ok().into_iter().collect();
        if let (Some(h), Some(url)) = (hosts.first(), relay_from_link(relay)) {
            self.ship.book.add_endpoint_info(iroh::EndpointAddr { id: *h, addrs: [iroh::TransportAddr::Relay(url)].into_iter().collect() });
        }
        self.ship.pockets.lock().unwrap().insert(st, (key, hosts.clone()));
        let s = self.ship.clone();
        Ok(wasm_bindgen_futures::future_to_promise(async move {
            let sub = s.gossip.subscribe(TopicId::from_bytes(pyrate_core::pocket::topic(&key)), hosts.clone()).await.map_err(|e| js(anyhow!("{e}")))?;
            let (tx, mut rx) = sub.split();
            s.pocket_tx.lock().unwrap().insert(st, tx);
            let s2 = s.clone();
            spawn(async move {
                while let Some(ev) = rx.next().await {
                    let Ok(Event::Received(m)) = ev else { continue };
                    let Some(plain) = pyrate_core::pocket::open(&key, &m.content) else { continue };
                    let Ok(g) = postcard::from_bytes::<Gossip>(&plain) else { continue };
                    let Some(g) = g.from_network(s2.now(), m.delivered_from.as_bytes()) else { continue };
                    let ok = match &g {
                        Gossip::Station(a) => a.station == st,
                        Gossip::Carrier { station, .. } | Gossip::Carried { station, .. } => *station == st,
                        Gossip::Aboard { station, .. } => *station == st,
                        Gossip::Harbour { .. } => true,
                        // No decks and no crew inside a pocket: its sound stays among its members.
                        Gossip::Crew { .. } | Gossip::Deck { .. } | Gossip::Door { .. } => false,
                    };
                    if ok {
                        s2.on_gossip(g);
                    }
                }
            });
            let _ = s.pocket_sync(st, key, hosts).await;
            Ok(JsValue::from_str(&st.to_hex()))
        }))
    }

    /// The flock host's station, as hex, or empty.
    pub fn flock_station(&self) -> String {
        self.ship.flock_station.lock().unwrap().map(|s| s.to_hex()).unwrap_or_default()
    }

    /// The station's whole log as JSON lines of what aired: for the station page.
    pub fn library(&self, id: &str) -> Result<String, JsValue> {
        let st = StationId(unhex32(id).map_err(js)?);
        let archives = self.ship.archives.lock().unwrap();
        let Some(a) = archives.get(&st) else { return Ok("[]".into()) };
        let v: Vec<Value> = a
            .library()
            .map_err(|e| js(anyhow!("{e}")))?
            .into_iter()
            .filter_map(|(h, e)| match e.entry.body() {
                Body::Track { title, by, .. } => Some(json!({ "track": hex(&h), "title": shown(title), "by": shown(by), "at": e.entry.at_ms })),
                _ => None,
            })
            .collect();
        Ok(json!(v).to_string())
    }
}

/// A stranger's text as shown: no bidi tricks, no hidden marks, one line.
pub(crate) fn shown<S: AsRef<str>>(s: S) -> String {
    pyrate_core::chat::shown(s.as_ref()).replace('\n', " ")
}
