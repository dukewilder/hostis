# Builds hostis.black/pyrateradio/ into landing/out: the landing page, the
# browser radio at /listen/, and the app. Fonts and the sheet are the HOSTIS site's own
# (brand/), so the radio reads as one more HOSTIS page.
import re, os, shutil, sys, hashlib, subprocess
R = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# The page names the app it offers, so it is built only with one: build.py <apk> <version>.
# A draft for looking at, with placeholders in place of the app, takes --draft instead.
if len(sys.argv) < 3 and "--draft" not in sys.argv:
    sys.exit("build.py <apk> <version>, or --draft for a local look with no app")
apk = sys.argv[1] if len(sys.argv) > 2 else None
version = sys.argv[2] if len(sys.argv) > 2 else "draft"
out = f"{R}/landing/out"
sys.path.insert(0, f"{R}/brand")
import fonts
if os.path.exists(out): shutil.rmtree(out)
os.makedirs(out)
page = open(f"{R}/landing/index.html", encoding="utf-8").read().replace("/*FONTS*/", fonts.faces()).replace("/*HOSTIS*/", fonts.sheet())
if apk:
    data = open(apk, "rb").read()
    sha, size = hashlib.sha256(data).hexdigest(), f"{len(data)/1e6:.0f}"
    shutil.copy(apk, f"{out}/pyrate-radio-{version}.apk")
    # The app by BitTorrent too: a torrent with this site as a web seed, and its magnet link.
    magnet = subprocess.run([sys.executable, f"{R}/tools/torrent.py", f"{out}/pyrate-radio-{version}.apk", f"{out}/pyrate-radio-{version}.apk.torrent",
                             f"https://hostis.black/pyrateradio/pyrate-radio-{version}.apk"], capture_output=True, text=True, check=True).stdout.strip()
    
else:
    sha, size, magnet = "(build pending)", "?", "#"
import json
op = json.load(open(f"{R}/browser/www/open.json"))
page = page.replace("{{OPEN_PLAYERS}}", json.dumps(op["players"])).replace("{{HARBOUR_IDS}}", json.dumps([h["id"] for h in json.load(open(f"{R}/browser/harbour.json", encoding="utf-8"))]))
page = page.replace("{{VERSION}}", version).replace("{{SHA}}", sha).replace("{{SIZE}}", size).replace("{{MAGNET}}", magnet.replace("&", "&amp;"))
# The computers' builds, when tools/fetch_desktop.sh has brought them: each with its checksum
# and a torrent that seeds from this site.
desk = ""
D = f"{R}/landing/desktop"
appver = re.search(r"^version:\s*([0-9.]+)", open(f"{R}/app/pubspec.yaml").read(), re.M).group(1)
kinds = [("windows", "pyrate-radio-windows.zip", "Windows", "10 and 11 · zip"), ("macos", "pyrate-radio-macos.zip", "Mac", "Apple and Intel · zip"), ("linux", "pyrate-radio-linux-x64.tar.gz", "Linux", "x86-64 · tar.gz")]
if os.path.isdir(D) and all(os.path.exists(f"{D}/{k[1]}") for k in kinds):
    links, sums = [], []
    for key, f, label, how in kinds:
        name = f.replace("pyrate-radio-", f"pyrate-radio-{appver}-")
        shutil.copy(f"{D}/{f}", f"{out}/{name}")
        sha_d = hashlib.sha256(open(f"{out}/{name}", "rb").read()).hexdigest()
        subprocess.run([sys.executable, f"{R}/tools/torrent.py", f"{out}/{name}", f"{out}/{name}.torrent", f"https://hostis.black/pyrateradio/{name}"], capture_output=True, text=True, check=True)
        links.append(f'<a href="{name}"><b>{label}</b><small>{how}</small></a>')
        sums.append(f"{label.lower()} {sha_d} · <a href=\"{name}.torrent\">torrent</a>")
    desk = ('<h3 class="small">On a computer</h3>\n<div class="desk">' + "".join(links) + '</div>\n<p class="desk-sums">' + "<br>".join(sums) + "</p>\n"
            '<p class="note">Version ' + appver + ', built from the public source by GitHub\'s machines. On a Mac, open it the first time with a right-click and Open: it is signed by nobody. Computers take new versions from this page.</p>')
page = page.replace("{{DESKTOP}}", desk)
open(f"{out}/index.html", "w", encoding="utf-8").write(page)
# The keeper's handbook: the same head and footer, a body of its own.
head = page[:page.index("<body>")]
head = head.replace('"https://hostis.black/pyrateradio/"', '"https://hostis.black/pyrateradio/handbook/"')
head = re.sub(r"<title>.*?</title>", "<title>The Keeper's Handbook · Pyrate Radio · HOSTIS</title>", head)
head = head.replace('content="Radio that plays all day and all night, that anyone can raise, that every listener carries, and that answers to no server, no store and no account."', 'content="What Pyrate Radio does to keep a station keeper unknown, what only the keeper can do, and how the network stands."')
flag = page[page.index('<nav class="flagbar"'):page.index("</nav>", page.index('<nav class="flagbar"')) + 6]
foot = page[page.index("<footer>"):page.index("</footer>") + 9]
book = open(f"{R}/landing/handbook.body.html", encoding="utf-8").read()
os.makedirs(f"{out}/handbook", exist_ok=True)
open(f"{out}/handbook/index.html", "w", encoding="utf-8").write(head.replace('href="favicon.png"', 'href="../favicon.png"').replace('href="apple-touch-icon.png"', 'href="../apple-touch-icon.png"') + '<body>\n<a class="skip-link" href="#main">Skip to content</a>\n' + flag + "\n" + book.replace('href="./', 'href="../') + foot + "\n</body>\n</html>\n")
shutil.copytree(f"{R}/browser/www/dist", f"{out}/listen")
# The HOSTIS skull, the same icon as every sibling page.
for f in ["favicon.png", "apple-touch-icon.png"]:
    shutil.copy(f"{R}/../{f}", out)
print("site at", out, "·", sha[:16])
