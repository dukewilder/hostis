# Pyrate Radio · The audit

Started 10 November 2026 from the code on `radio` at `736a0d1`. Two tracks: the product (does every feature work, and work well) and the walls (what a listener, a node runner or a broadcaster could be made to give away). Every finding lands here when it is found, and moves to Fixed in the same commit as its fix.

Each entry gives the threat, whether the wall held, and the fix.

## Open

### Track B: privacy, anonymity and decentralisation

### Track A: the clock, the programme, sound and pictures

Reported by a reader of the code; each is checked against the code before it is fixed or set down. The reader's full notes, with each failure worked through, are in `audit-notes/clock.md`.

### Track A and B: the browser, the Lantern's web listener and the landing

Reported by a reader of the code; each is checked against the code before it is fixed or set down.

### Track A and B: the phone app, its Android shell and the FFI

Reported by a reader of the code; each is checked against the code before it is fixed or set down.

## Fixed

**B1. The stem names its origin.** `hop.rs` starts every stem at `hops: 0` and each relay adds one, so the guard that receives `hops: 0` knows its peer is the broadcaster. Does not hold. Fixed: every node, broadcaster and relay alike, now sends the count as zero and nothing reads it. A stem ends by the fluff draw alone (four hops on average), and a node that sees the same cargo come round again spreads it. Older nodes still count up from zero, which tells a new node only that its sender was a relay. Checked by the voyage test (18 of 18). (ae5aa7b)

**B2. Pocket stations surface on the public Log.** Three ways: a listener's hourly token for a pocket station is gossiped on the public Log by whoever counts it (phones through their exit, tabs directly), naming the station; a pocket station that goes ON AIR sends its live entries down the public stem, where a stranger takes them aboard, announces itself as a carrier and serves the log by id; and a keeper's phone syncing its own pocket asks an exit for it by id. Does not hold. Fixed: a pocket's hourly tokens now travel sealed on its own topic and are counted among its members; a pocket station never goes down the public stem; a keeper's phone asks its members for its own pocket by tag; and a member fetches a pocket's sound from the circle rather than through an exit, which would have learnt the id. The browser's half is C18. The pocket test now runs phones as they ship and checks that an outsider never hears of the station while a member listens and the keeper goes live; on the old code that check fails. (b85e7bd)

**C2. The web listener publishes pocket (private) stations.** (high) Fixed: the gangway refuses pocket stations in every route and leaves them out of log.json. (b85e7bd)

**B3. Pocket chatter is open.** A pocket's room sits on a topic drawn from the station's id and its lines travel in the clear, so anyone who learns the id can read the room. Does not hold. Fixed: a pocket's room now sits on a topic drawn from its key, met through its hosts and members, and every line (hails included) is sealed with the key in the app, on a Lantern and in the browser. The last lines go to members who ask by the pocket's tag, sealed, through a new request at the end of the enum; a request by the station's id gets nothing. Older apps in a pocket keep their own room until they update. Checked by the pocket test: the keeper hears a member and a browser tab, and an outsider joining by the id hears nothing. (ce61d80)

**C18. Pocket station id leaks to the public network.** (high) Fixed: a tab's hourly token for a pocket goes sealed on the pocket's own topic and never on the public Log; the pocket's room is sealed as in B3; and Clip it stays hidden for a pocket. Checked with the browser in the pocket test: an outsider never hears of the station while the tab listens and talks. (ce61d80)

**C30. Invitation key sits in the address bar for the whole join and forever on failure.** (medium) Fixed: the page reads an invitation and clears the address bar before anything else runs, joins from memory, and never writes a pocket's id into the address bar or the history. A flock link leaves the address bar as soon as it is read. (ce61d80)

**B4. Ballast is announced and served away from the charger.** A phone keeps announcing its ballast stations and serving sealed chunks to strangers on mobile data, which spends the owner's data, and its ballast set (fixed by its steady seed) ties each day's fresh id to the last and each network it uses to the next. Holds only in part. Fixed: a phone announces its ballast only while it is on Wi-Fi and charging, and on mobile data it serves strangers no sealed chunks at all. What remains: a phone that charges on Wi-Fi in more than one place can still be tied across those places by its ballast set, and a keeper who cares can set the ballast aside. (a5f12b1)

**B6. Stems and ballast ignore the listener's own switches.** A stem can end on a phone for a station its owner marooned, and ballast and stems take aboard explicit stations on a phone whose owner keeps them hidden. Does not hold for the owner's choice. Fixed: a node declines the stem and the ballast for any station its owner marooned, and a phone declines explicit stations while its owner hides them, and mature ones while they hide those. The station's word is read from its card, its log or the stem's own cargo. A declined stem is handed on, as a Lantern that carries its own already does. Checked by a new voyage test step (20 of 20). (a5f12b1)

**B10. A malformed id can stop a node.** `StationId::from_hex`, `unhex` and the browser's `unhex32` slice strings by byte, so 64 bytes holding a multi-byte character panic. The FFI and the browser are reached by pasted links. Fixed: every hex parser (ids, keys, hashes, flock codes, release signatures) now goes through one strict parser in the core that reads bytes, takes only hex digits and cannot panic. A test feeds it 64 bytes holding a two-byte character and a leading plus. (7bd378e)

**P6. One non-ASCII "hex" string aborts the app: no catch_unwind and byte-slicing parsers.** (medium) Fixed: the same strict parser closes the panics, and every door of the FFI (the C calls and the JNI calls) now catches a panic and answers with an error instead of aborting the app. (7bd378e)

**P1. Second `initNative` call aborts the process.** (high) Fixed: the Android context is set once a process on the Rust side, whoever asks first, so the playback service starting after the app (or before it) no longer trips ndk-context's assertion. Confirmed in ndk-context 0.1.1, which asserts on a second call; checked by building the FFI for Android. (7bd378e)

**A13. `unhex` accepts a leading `+`.** (low) Fixed: the strict parser takes no sign. (7bd378e)

**B7. Old plain chunks answer to a sealed request.** A chunk kept from before sealing lies on disk under its plain hash, and a `SealedChunk` request naming that hash is served the plain bytes. Does not hold for those files. Fixed: a sealed request that finds a plain file under its name seals it in place, removes the plain copy and answers nothing. A unit test plants an old plain chunk and asks for it by its hash. (0b3d89c)

**B11. A struck station's art stays on disk.** Strike drops a station's recordings but not its pictures. Fixed: a strike drops the station's pictures with its recordings. (0b3d89c)

**B12. A Lantern's chatter memory never empties.** Each room keeps every line id it has seen for the life of the process. Fixed: each room, on a node and in a tab, forgets a line's id once a line that old would be refused anyway (twenty minutes), so memory holds only the last few minutes. Unit tested. (0b3d89c)

**B15. Small faults.** The flock's round trip can underflow if the network clock steps between pings. Fixed: the round trip is taken with a saturating subtraction. (0b3d89c)

**C1. /player/ serves any file on disk via an absolute path.** (high) Fixed: the mirror builds the file's path from plain segments only (no empty, dotted, backslashed or colon segments) and serves it only if, links followed, it still lies inside the player folder. It also sends nosniff, no-referrer and frame-ancestors 'self', and knows the svg, ico, woff2 and txt types. A unit test tries absolute, doubled-slash, dotted and linked paths, and a live Lantern answers 404 to /player//etc/passwd. (ac1a5e3)

**A1. One hostile station can move every listener's clock by up to five minutes.** (high) Fixed: the network clock now lives in the core (drift.rs), shared by phones, Lanterns and tabs: each station gets one vote (its latest gap), nothing moves until five stations agree, the median is applied only past 2.5 seconds and eases off below one, and anything past five minutes is not trusted. Unit tests show a hundred cards from one station moving nothing. (417040b)

**C14. One station can set every tab's clock wrong.** (high) Fixed: the tab uses the same core drift as the app (see A1). (417040b)

**A10. Clock correction jumps from 0 to 2 s instead of easing in.** (low) Fixed: the correction turns on past 2.5 seconds and off below one (see A1). (417040b)

**A2. `t - cursor` underflow in `walk` when a run's computed start is after `t` (panic in debug, garbage in release).** (high) Fixed: every walk now refuses a start after the moment asked about, a tape whose start the clocks have only just reached begins a day or a week earlier, and a programme read from a log is made sane (offsets clamped to fourteen hours and sorted, minutes taken within the day, lengths within the week, days within seven). Regression tests: Berlin's spring change and a weekly tape at minute 65,535. (bbfe09d)

**A22. Spring-forward gap and `utc_ms` are inconsistent between east and west zones.** (low) Fixed: a local minute that was skipped begins when the clocks changed, and one that came twice begins the first time, by the same rule east and west of UTC. Tested at Berlin's spring change. (bbfe09d)

**A3. Rota walk has no step cap: a track of a few milliseconds hangs the lookup.** (high) Fixed: a recording under a second is not played (an Article ruling), the rota's walk has the same step cap as the programme's, and the watch bill has a budget of steps across all its lookups. A regression test signs a twenty-millisecond track and finds the clock quick and silent. (bbfe09d)

**A7. `at_ms + show_len` overflows for a signed Show with a huge `at_ms`.** (medium) Fixed: show ends are added with saturation. Tested with a show dated at u64::MAX. (bbfe09d)

**A16. Spans and tables read from the log are not validated, so `now` and `listings` can disagree and costs are unbounded.** (low) Fixed: the clock builds one index of tracks by hash and normalises the programme once, in Clock::new (see A2). (bbfe09d)

**C3. count_guest spawns one OS thread per request, with no cap.** (high) Fixed: one worker counts every web guest from a queue of 64, and a guest past a full queue goes uncounted; a tab is counted once it has listened thirty seconds, then hourly, so reconnects are not a crowd. (261c896)

**C4. Episode generation holds the whole recording in memory.** (high) Fixed: an episode is made a chunk at a time straight to disk, so memory stays flat however long the show, and recordings over six hours are refused. On the way a fault surfaced in the LAME wrapper: it writes into a vector's spare room and gives LAME no size when there is none, so the worst case is now reserved before every call. (261c896)

**C5. Concurrent first requests for one episode race on the same temp file.** (medium) Fixed: two requests for one episode wait on one maker, and each maker writes its own temporary file; at most two episodes are made at once. (261c896)

**C6. Cached episodes ignore withdrawal and ignore which station owns the track.** (medium) Fixed: an episode is served only if the recording is in the named station's library now, and the cache is named by station and recording. (261c896)

**C7. Streaming tower busy-loops on bad entries.** (medium) Fixed: a tower sleeps after any step that sends nothing and comes down after a minute of them; an off-air wait does not count. (261c896)

**C8. No connection, rate or time limits on the HTTP listener; `--web-all` lets anyone spawn encoders.** (medium) Fixed: the gangway streams to at most 512 listeners and 32 stations at once, and refuses a station it does not hold before starting a tower. What remains: no header-read timeout of its own; the tunnel in front of it is the first line for slow clients. (261c896)

**C9. Feed XML: unescaped Host-derived attributes and control characters.** (medium) Fixed: feed text drops the control characters XML forbids, and the base address takes only a plain host name and http or https, escaped. (261c896)

**C10. Episode Range handling reads the whole file per request and mis-answers unsatisfiable ranges.** (low) Fixed: episodes are read from disk as they go out, with suffix ranges and 416 for a range past the end. (261c896)

**C11. Per-request cost amplification on unauthenticated routes.** (medium) Fixed: a picture is looked for only among the stations the page may show. What remains: /now and /log.json still work out their answers on every request, cheap for a Lantern's own few stations. (261c896)

**C15. Unsigned Carrier gossip: fake carriers jump the queue, grow memory and eclipse peers.** (high) Fixed: a carrier's claimed head never counts past the station's own card, a listing keeps the 64 freshest carriers, a carrier or token for a station with no card here is dropped (pockets excepted), and a node that failed to answer in the last ten minutes is asked last. The same in the app, on Lanterns and in tabs; cards now go out before carrier claims so nothing honest is dropped. Unit tested; voyage (20 of 20) and pocket (8 of 8) pass. (51ff651)

**B13. One company's DNS sits under the network.** Nodes publish their id and relay to number0's pkarr server and look carriers up there, and every lookup also goes out as a plain DNS query that the line's provider can read. If that server goes, nodes can find each other only through gossip neighbours; while it stands, it and the line see who dials whom. Holds only in part. Fixed: node ids are no longer looked up in plain DNS at all (the endpoint is built from the minimal preset, the network's own book and number0's pkarr resolver over HTTPS). Every carrier now gossips a harbour note: its relay, signed with its own node key, which other nodes and tabs put in their address book for carriers and harbours they know, so nodes find each other inside the network without number0. Dark nodes send none. Tabs publish their address nowhere (C27). What remains: non-dark phones and Lanterns still publish their relay to number0's pkarr server, so that 0.8.0 nodes can find them; a later release can stop once the fleet carries notes. Unit tested; voyage (20 of 20) and pocket (8 of 8) pass. (ee94550)

**C27. presets::N0 may contact number0's discovery services and default relays.** (medium) Fixed: a tab publishes its address nowhere and looks peers up in its own book first (see B13). (ee94550)

**B5. Private fetches have no guard.** Each private fetch draws a fresh first hop, so over a day of listening a hostile pair of nodes (first hop and exit) will eventually both be drawn and can tie a listener to a station. Holds only in part. Fixed: a private fetch now goes through a guard kept as long as it answers (a file beside the stem's guard), passing over the well-known Lanterns, with a fresh exit each time; a guard that fails is dropped and another drawn. Voyage test 20 of 20. This container's test network has a single Lantern to route through, so every private fetch here takes one hop and the guard is not exercised; it needs a network of several carriers. (5a20daf)

**B14. A broadcaster asks carriers for its own station directly.** When the private route fails, a phone syncing its own station asks carriers for the log by id from its own address, which tells them who keeps it. Does not hold. Fixed: a phone asks carriers for its own station directly only once that station is already on the air directly from it. (5a20daf)

**P2. STRIKE COLOURS can never complete: the node drops the 24 words and signs with the deputy key.** (high) Fixed: strike now takes the master from the 24 words through the same path as restore, and still strikes with the key itself on a Lantern that keeps it. The app shows the result beside the act, and the words field learns nothing (no suggestions, autocorrect or keyboard learning) and is cleared after. Two new voyage steps: wrong words strike nothing, the right ones end the station (22 of 22). (ff7121e)

**P3. Auto Backup is left on: deputy keys, pocket secrets and prefs go to the user's Google account.** (high) Fixed: the app turns off backup and device transfer entirely (allowBackup false, no full-backup content, and extraction rules excluding every domain), so the deputy key, pocket invitations and the owner's chart never leave the phone that way. (bddbcf2)

**P4. The 24 words can be lost three ways.** (high) Fixed: the words are shown before anything that can fail, in a dialog that neither the back gesture nor a stray tap can close, and that closes only once the keeper ticks that all 24 are on paper; a later error is shown after. The node returns the words even if a pocket's topic fails to open (the station stays private, as it is marked so before the topic opens). (bddbcf2)

**P5. Exported MediaBrowser service hands the station list and control to any app, private pocket stations included.** (high) Fixed: the media browser answers only this app, the system, Bluetooth and the car, lists no pocket stations, and tunes only to a well-formed id. (bddbcf2)

**P13. Listening history is written to logcat.** (medium) Fixed: the released app writes nothing to the phone's log: the Dart prints are gone and the node's log line is empty on Android outside debug builds. (bddbcf2)

**P29. The 24 words and PINs are typed and shown with the keyboard's learning and no screen protection.** (medium) Fixed: the 24 words and PIN fields learn nothing (no suggestions, autocorrect or keyboard learning), are cleared once read, and the screen is marked secure (no screenshot, recents thumbnail or recording) while the words, strike and appoint dialogs are up. (bddbcf2)

**P37. `kBuildCode` duplicates the pubspec build number.** (low) Fixed: the app reads its version code from the installed package through the shell, so it can never disagree with the build; the constant is gone. (d6e1097)

**B8. The hold opens for anyone with the public Log.** Chunks and logs are sealed under keys drawn from public facts (a station's id, a chunk's hash), and filed under names drawn from the same. Someone who seizes a disk and also runs a node can test it for every station on the Log, and a deleted file on flash may still be read. Holds against a casual look only. Fixed: every file the node keeps is now sealed again and named under a hold key of the device's own (node/src/hold.rs): chunks (inside, still sealed under their own addresses, so a carrier still cannot read what it carries), logs, station keys, and the small files that name stations (the chart of kept and marooned, the settings, pocket invitations, proof-of-work and aboard counts). On a phone the hold key is wrapped by the Android Keystore, so a copy of storage taken off the chip is noise; a Lantern keeps it in hold.key, or wherever PYRATE_HOLD_KEY points. Files from before are carried over the first time each is read. Unit tests: someone holding a station's id, log and chunk address, and the old naming, finds nothing on the disk to test or open, another device's key opens nothing, and an old hold comes across and leaves no old file behind. Voyage (22 of 22), pocket (8 of 8) and art pass; the APK builds. (359c9ae) The scuttle followed: SCUTTLE under Colours destroys the hardware key that wraps the hold key, calls off every bell and the morning alarm, clears the app's own preferences and closes the app, so everything the radio kept on the phone is noise at once; the next start clears the noise and begins fresh. A Lantern has `lantern --scuttle`, which overwrites and removes its hold key. (9c08bc3)

**P12. Station ids, bells and the alarm station sit in plaintext SharedPreferences and prefs.json.** (medium) Fixed: the node's chart, settings, pocket invitations and counts are sealed under the hold key (see B8). What remains: the Android side's own small store (the last station, bells and the wake station in SharedPreferences) is still in the clear. (359c9ae)

**C17. Aboard token broadcasts what the tab is tuned to, whether or not it plays.** (medium) Fixed: a tab is counted aboard only while it plays (the page says when listening starts and stops), and its hourly token goes to an exit through a first hop drawn once a visit, as a phone's does: the first hop sees the tab and not the station, the exit the station and not the tab. With a single node to hand it falls back to the harbour, which would hear it anyway. The seal for private requests now lives in the core, shared by phones and tabs. Checked in Chromium against two Lanterns: nothing is counted while browsing, and the token goes through two hops once listening; voyage 22 of 22. (99cbb2f)

**C19. Peers can probe a tab for what it has just played.** (medium) Fixed: a tab now answers nobody about what it holds: requests for logs, sealed chunks and plain chunks get nothing. It takes from the network and gives back its count and its chatter. (99cbb2f)

**B9. The PIN falls to a fast hash.** The Colours PIN is stored as a salted BLAKE3 hash, so a seized disk gives up a four-digit PIN at once, and with it any lock-screen PIN that matches. Holds only against a casual look. Fixed: the PIN is kept under Argon2id (32 MiB, three passes), so each guess against a copy of the file costs real time, and a PIN from before is moved to it the first time it is entered right. The app checks and sets it off the screen's thread, and asking only whether one is set costs nothing. Unit tested. (1245195)

**P15. After END BROADCAST the "ON AIR" notification, foreground state and both locks stay.** (medium) Fixed: ending a broadcast now leaves the foreground (and its locks) when nothing is tuned, or puts the station back on the notification when something is; ON AIR shows only while live. (650c233)

**P16. Every tune stacks a new audio-focus request.** (medium) Fixed: the service keeps one request for the speaker for its whole life and asks with it again, so no stale listener answers later focus changes. (650c233)

**P11. The "plain" disguise leaks the station name and the app name.** (medium) Fixed: in the plain disguise the playback notification is private with a public face that says only Radio, the app's station title no longer overrides it, ON AIR is not shown, and bells and the Lantern notification say only Radio. What remains: the system still names the app in the notification header, which no app can change. (650c233)

**P19. Links join pockets, flocks and stations without asking.** (medium) Fixed: A link from outside waits on the dial for a yes: LISTEN or JOIN, or NO. Nothing is played or joined before it. A bell's own tap carries a private key held in the app's preferences and still tunes at once; a forged tap from another app asks like any link. (e9bbfaf)

**P24. Joined chatter and joined pockets cannot be left; muted voices cannot be unmuted.** (medium) Fixed: The chatter has LEAVE THE CHATTER and a MUTED list where each voice can be heard again. A joined pocket has LEAVE THIS POCKET in the Log, which drops its key, log and sound from the phone. (e9bbfaf)

**P25. Pocket stations are offered a public share link, poster and QR.** (medium) Fixed: Pocket stations offer no PASS IT ON, no poster and no public link anywhere in the app; shareStation refuses a pocket as a backstop. (e9bbfaf)

**P30. Opening the app always autoplays.** (low) Fixed: The first open plays the busiest earned station once in the phone's life, kept in the sealed prefs; later opens stay silent until the owner tunes. (e9bbfaf)

**P7. Podcast feeds and "cover from a link" call the network straight from the phone, outside the node.** (medium) Fixed: The fetches stay on the phone, since the node would leave from the same address, but all of them now go through one guarded helper: a plain client name in place of Dart's own, timeouts on connecting and on every gap, a size cap, a client that is always closed. The feed screens say plainly that the feed's host sees this phone's address as it would any podcast app's. (0702d98)

**P8. Feed "keep the newest N" downloads the whole back catalogue, and the feed list can be overwritten.** (medium) Fixed: A feed's first reading takes its newest few and passes over the back catalogue for good; after that only episodes newer than the last one taken come aboard. Each feed's memory is written back alone, so a feed added or removed during a reading stays that way, and the memory is trimmed to what the feed still lists. (0702d98)

**P9. Podcast feeds are never refreshed on their own.** (medium) Fixed: The app reads its feeds every three hours, on Wi-Fi only, while it is open. (0702d98)

**P33. Feed and URL fetch code writes unsolicited temp files and the downloads can be stranded.** (low) Fixed: A fetch writes a .part file that takes its name only when whole and is deleted on any failure; the art and the episodes are deleted once set; and each start sweeps the cache of anything older than six hours that an earlier run left behind. (0702d98)

**P14. Temporary audio, pictures and APK copies are left on disk.** (medium) Fixed: Takes, picked files, pictures and fetches are dropped from the cache once set or discarded, through one helper that only ever deletes inside the app's own cache; each start sweeps anything an earlier run left there for more than six hours, the shared tapes and the APK copy included. Recordings are set one after another rather than all at once. (dd9d820)

**P21. RECORD A SEGMENT leaves the microphone open if the panel is closed.** (medium) Fixed: Closing the panel stops the microphone at once and drops the take; DISCARD deletes it; the hail recorder does the same when its sheet closes. (dd9d820)

**P22. The programme editor treats a failed load as loaded and can overwrite the real programme.** (medium) Fixed: Only a whole answer counts as read. A failed read keeps SET THE PROGRAMME shut, says what went wrong and offers TRY AGAIN, so a blank editor can never be saved over the programme on the air. (dd9d820)

**P18. The dial's PageView follows list position, not the station.** (medium) Fixed: The dial follows the station rather than its place in the list: when the Log reorders or shrinks, the face turns back to the tuned or shown station. Any turn the app makes itself goes through one path that tunes nothing, which also closes a hole in P19, where turning the dial to an invited station tuned it through the page listener before the owner said yes. (dea6713)

**P23. A hosted flock loses its code when the sheet is closed.** (medium) Fixed: The node's flock status carries the link for as long as the flock is hosted, and the sheet reads it back, so the code and its QR are there whenever the sheet is opened again. (36d90c2)

**P28. Direct fixes to misplaced results: CLEAR THE HOLD, strike and restore all write the same `error` field.** (low) Fixed: CLEAR THE HOLD and TAKE IT BACK each answer with their own word on the spot, success or failure, as the strike already does; neither writes the shared error line any more, and the hold is cleared off the UI thread. (36d90c2)

**P20. Microphone permission dead-ends and the messages mislead.** (medium) Fixed: Every microphone ask goes through one path that waits for the owner's answer rather than replying before the dialog shows. A refusal says to press again; a phone that will no longer ask says so and offers OPEN SETTINGS, straight to the app's own page; a microphone that would not start says another app may have it. (ca5bf40)

**P26. Bell ids differ between screens, depend on `String.hashCode`, and notifications are not checked.** (low) Fixed: A bell's id now comes from the station and the minute the show starts, by FNV-1a rather than the toolkit's hash, so the page and the watch bill agree and every build agrees. Setting or silencing a bell also clears any older bell for the same show, whatever id it was given, and a bell set while notifications are off for the app or its bells says so at once and offers OPEN SETTINGS. (a0d9777)

**P10. Drawer Lantern: the service restarts with no node, and the charging and Wi-Fi gate lives only in the Dart UI.** (medium) Fixed: The Lantern service starts the node itself when Android restarts it with no screen and reads its size back, and it keeps its own charger-and-Wi-Fi gate: power and network changes and a minute's check set it, and switching the Lantern off shuts it. A phone left as a Lantern comes back on after a reboot. (17e2416)

**P32. `pyrate_start` is not safe against two starters, and a failed start is invisible.** (low) Fixed: Starting is held under one lock, so the screen and a service starting at once make one node; the Kotlin side counts an already-running node as started; and a failed start is kept and shown on the dial in place of an endless search. (17e2416)

**B16. The Android side keeps listening notes in the clear.** The bells (each show's title, station and name), the wake-up station and the last station tuned sit in plain shared preferences beside the sealed hold, so a copy of the phone's storage says what its owner listens to and when. Does not hold. Fixed: the bells, the wake-up station and its name, and the last station tuned are sealed under the phone's hardware key, the same that wraps the hold key; a note written in the clear by an older build is read once and sealed when next written. Only a random bell key and on/off switches stay plain. (ab09d3d)

**P34. Brass (amber) is used throughout.** (medium) Fixed: Amber is gone: the update banner, SCANNING, the sleep timer, KEPT, the watch bill's days, ringing bells and the station-art note are all bone in its three weights. (bb90709)

**P35. Red is used beyond ON AIR, and there are two reds; M3 defaults bring rounded pickers and Roboto.** (low) Fixed: One red, #ed5555, kept to ON AIR, LIVE, the live dot and a microphone while it records (ruled in the Articles). Errors, STRIKE, MAROON, section heads, invitations and buttons are bone. The theme now sets Fell as the default face and squares dialogs, sheets, menus, toasts, the time picker, checkboxes and text buttons with hairline borders, with no tint. (bb90709)

**P36. The window behind Flutter is white in light mode.** (low) Fixed: The window behind the app, the splash and the system bars are the sheet's black whatever the phone's light or dark setting. (bb90709)

**P38. Manifest hygiene.** (low) Fixed: The unused Wi-Fi state permission is gone, and so is the toolkit's query for apps that process text, so selected words or a PIN are never offered to a translator or any other app; only text-to-speech engines are looked for. (f9984ff)

**P40. Passing the app on: a LAN HTTP server with no timeouts, binding every interface.** (low) Fixed: The server listens on the phone's own local address only, answers only under a random path carried in the QR (anything else gets an empty 404, so a scan of the room's Wi-Fi finds nothing naming the app), serves four at a time, drops a request not made within fifteen seconds, and shuts itself after fifteen minutes. (f9984ff)

**P17. Blocking native calls on the UI thread, in Dart and in the service.** (medium) Fixed: The dial's poll and every slow command (go on air, end, strike, tape, maroon, keep, flock join, clearing art, importing a maroon list) run off the screen's thread, the poll one at a time. In the playback service every call into the node, its start included, runs on one thread of its own; the lock screen, the speaker and the notification are touched only on the main thread, the service goes to the foreground before the node is asked anything, and the car's list of stations is built in the background. Built, not yet run on a phone: this build is in the APK for Dylan to sign and try. (79ce351)

**P27. The numbers kit decodes and rewrites WAV files sample by sample on the UI isolate.** (medium) Fixed: The message and its interval signal are read, joined and written in a background isolate from typed buffers in two writes, not sample by sample on the screen's thread. A round trip against Python's wave module (a stereo file in, its first channel out after the signal) matches sample for sample. (b96e1d4)

**P39. `setState` after await without `mounted`, and controllers that are never disposed.** (low) Fixed: Every setState that follows an await, twenty-three of them found by a scan of the three screens, now checks the screen is still there first, and the eighteen text controllers that screens own are disposed with them. (f3125f9)

**P31. Android App Links are not verified, so scanned posters open the browser.** (low) Fixed: The app now asks Android to verify both hostis.black link filters, and tools/assetlinks.py writes the site file from the Android certificate. Until hostis.black serves it, links open in the browser as before, so nothing regresses. What remains is Dylan's: the certificate and a yes to a file at the domain root (brief, section 8). (c9f3dae)

**C16. Chunk fetch is serial, has no failure memory, and retries dead peers every time.** (medium) Fixed: A chunk is asked of two carriers at once and the first good answer wins; carriers that failed lately are asked only after the rest, and at most eight are tried. (f2e0e41)

**C20. Unbounded growth: cards, listings, archives, rooms, connections, seen set.** (medium) Fixed: Once a minute a tab trims what it no longer needs: cards quiet for six hours, logs beyond the eight last played (the tuned station and pockets stay), their clocks, closed connections and old token marks. At most three chatter rooms stay open; joining a fourth leaves the oldest. (f2e0e41)

**C21. plan() re-hashes the whole log on every call.** (medium) Fixed: Each station's clock is kept and rebuilt only when its log grows, instead of on every one of the player's calls. (f2e0e41)

**C22. Struck station leaves the tab stuck "Searching the Log" and hammering carriers.** (low) Fixed: A struck station is remembered as struck: its card and log go, its cards are ignored from then on, and the set says the station has ended and stops asking for it. A log not found yet is looked for less often, up to every fifteen seconds. (f2e0e41)

**C31. Playback loop can die silently (exception, empty decode, missing decoder script).** (medium) Fixed: Every step of the player loop is caught: a stumble resets and starts again with a word on the set, a chunk that decodes to nothing is skipped like a missing one, and only after six stumbles in a row does the set stop and say this browser could not play the station. Played in Chromium through both decoders. (f2e0e41)

**C32. Going live after a track leaves silence and extra latency.** (medium) Fixed: Going from a track to live clears what was queued ahead, the end of the queue included, so the broadcast starts at once rather than after the track's twelve seconds of lead. (f2e0e41)

**C33. The "No carrier answered yet" message is overwritten within a second.** (low) Fixed: A trouble (no carrier answered, a stumble) stays on the set until it clears, instead of being overwritten by the title within a second. (f2e0e41)

**C40. No relay or no stations is a dead end with no message.** (medium) Fixed: A relay that does not answer is tried again, more slowly each time, with a line saying the network may block the radio; after ninety seconds with no station the list says whether the network is there but quiet or nothing has answered at all. (f2e0e41)

**C23. Flock: no way to leave, relay URL taken from the link without checks.** (low) Fixed: The tab has LEAVE THE FLOCK beside the signal line, which hands it back to the network's clock and its own station. A relay named in a flock or pocket link is used only if it is HTTPS (loopback allowed for tests), and a flock host can move the tab's clock by five minutes at most. (6c6c113)

**C24. Chat: the keeper label can be imitated, and bidi controls are not stripped.** (low) Fixed: Chat lines are shown, on the phone and in the tab, without control characters, bidi overrides and isolates or zero-width marks, and a name can never carry the words (the station), which only the keeper's key earns. Unit tested in core. (6c6c113)

**C26. Console logs identify the fresh node and the station being synced.** (low) Fixed: The tab writes its notes to the console only when the page is opened with ?debug; otherwise nothing names its node or the stations it syncs. (6c6c113)

**C35. Hail: wrong target after switching station, stale stop timer, mic left on.** (medium) Fixed: A hail goes to the station it was started for, switching station mid-hail drops it, its twenty-second stop belongs to that recording alone, and the microphone is let go however it ends, a browser that cannot record included. (6c6c113)

**C36. Chatter and rows are re-rendered wholesale on a timer.** (medium) Fixed: The list is rebuilt only when something in it changed, and the chatter only when its lines or mutes did. (6c6c113)

**C37. Cover art is fetched for every listed station, retried every 4 s, with no size cap.** (medium) Fixed: A row's cover is fetched once the row comes into view; a picture that will not come is not asked for again for two minutes; none over 2 MB is shown. (6c6c113)

**C38. Object URLs and animation work never released.** (low) Fixed: The tab keeps its last two hundred pictures and revokes the rest, revokes all of them when the art switch changes, and the meter's animation rests once nothing plays. (6c6c113)

**C39. Second tap on Listen while booting starts a second node (embed).** (low) Fixed: Listen while the tab is still coming aboard waits for the one boot under way rather than starting another node. (6c6c113)

**C41. ICS export can be injected with a bare CR in a title or about text.** (low) Fixed: Every line break in a calendar entry, a bare CR included, becomes the calendar's own escape. (6c6c113)

**C42. Pass-it-on, clip QR and ICS links are hard-wired to hostis.black.** (low) Fixed: Passed-on links, the clip's code and calendar entries point at the copy of the radio they were made on when it is a public HTTPS name, so they outlive hostis.black; a copy reached by a bare address, plain HTTP or a private name is never named, and those links go to hostis.black. (6c6c113)

**C44. Build: wasm is not cache-busted, so a deploy can mix new glue with old wasm.** (medium) Fixed: The wasm takes the build's version in its file name and the glue is rewritten to load that name, so a cached wasm can never meet newer glue. (6c6c113)

**C45. Build embeds env/config strings unescaped.** (low) Fixed: The build writes the harbour, relays and harbour stations into the page as JSON strings, and fails if a placeholder is missing. (6c6c113)

**C46. Android "open in the app" fallback goes to a 404.** (medium) Fixed: The Android fallback now resolves against the page itself, so it lands on hostis.black/pyrateradio/listen/ and not a 404. (584925b)

**C47. Landing build can publish placeholder text.** (low) Fixed: The landing build refuses to run without an APK and its version; a local look with placeholders needs --draft. (584925b)

**C48. Embedded set cannot record a hail and the copy there overpromises.** (low) Fixed: The landing says what the embedded set holds (HOSTIS's own stations) and that the full player has the whole Log, its chatter and its hails; a hail tried from inside another page says why the microphone cannot be lent and sends the listener to the full player. (584925b)

**C49. Red used as a general accent, pill buttons, and emoji-capable glyphs.** (low) Fixed: The pill buttons and blood-deep buttons stay, being the site's own compass and download buttons. Bright red is kept to ON AIR, LIVE, the live dot, the tuned needle with its blood diamond and the meter's hot end: section heads, the slot name, the keeper's name, the Stop state, the chart's chosen dot, checkboxes and the clip's progress bar are bone, and the focus ring is the site's own dashed blood. The play, stop and record glyphs carry the text selector so no phone draws them as emoji, in the app as in the tab. (584925b)

**C50. Informational text set in the ghost tone and at sub-10px sizes.** (low) Fixed: No text in the set is under .65rem, the site's own smallest, and times, notices, chat times and the meter's label are in the faint tone rather than the ghost. (584925b)

**B17. A keeper's Lantern files hails in the clear.** With PYRATE_HAILS set, the keeper's own Lantern opened each hail and wrote the voice to a folder in the clear, named with the sender's chosen name, against the ruling that a disk is noise without its own key and against the Articles, which said the hail stays sealed. Does not hold. Fixed: a kept hail is filed as it came, still sealed to the station, and sealed again under the Lantern's hold key, in a list of at most five hundred; nothing on disk shows a voice or a sender. lantern --open-hails <folder> opens them into the keeper's chosen folder and forgets them. Unit tested: the folder holds neither the voice nor the name, and the hail opens once, whole. (d67efa9)

**C13. /player/ mirror: broken home links, no redirect, no hardening headers.** (low) Fixed: /player redirects to /player/, and a copy of the set served anywhere but hostis.black/pyrateradio/listen/ points its links to the landing at hostis.black/pyrateradio/ rather than at the Lantern's own root. The mirror already sent nosniff, no-referrer and frame-ancestors (P-batch). (40316cb)

**C28. No CSP, no Referrer-Policy, inline script in head.** (medium) Fixed: The Lantern's page now loads its script from /listen.js and is served with a strict policy (scripts from the Lantern only, nothing inline, no plugins, no forms sent anywhere, framed only by itself), no referrer and nosniff. The browser set, on GitHub Pages, carries its policy in the page: its own scripts, the one embed line by its hash, wasm compiled, connections out only over TLS (a loopback relay in test builds alone), and no referrer. Chromium played through both decoders under it with nothing refused. (40316cb)

**C12. Lantern page and tower have no recovery when the stream ends.** (low) Fixed: When a Lantern stream ends or breaks while the listener still wants it (the tower came down over dead air, the network dropped), the page asks for it again, two seconds later and then longer each time up to thirty, saying Reconnecting meanwhile. Tested in Chromium against a Lantern: a stream broken mid-play came back by itself. (e7de7e6)

**C25. Wasm traps are unrecoverable. `Cargo.toml `[profile.web] panic = "abort"** (low) Fixed: The node in the tab still stops dead on a fault, by design, but the tab now notices (a trap thrown in the player loop, or anywhere as an error or a rejection), stops cleanly, says so, and comes back aboard once by itself on the same station (never putting a pocket's id in the address bar); a second trap within five minutes asks for a reload instead of looping. Tested with a simulated trap. (8418d64)

**C29. Storage and URL inventory (what ties a visit to the next, and what stays in history).** (medium) Fixed: The inventory is now on the page: under Your colours the set says what this browser keeps (switches, marooned stations, harbours met, name and mutes, the secret each room's voice is drawn from, pocket invitations), that none of it is sent, and that the address bar holds only a public station. FORGET THIS BROWSER clears every one of them, the session's own note included, and the tab comes back a stranger: a new voice in every room and no pockets. Tested in Chromium. (56b62a0)

**C34. Background and Safari playback: iPad detection, interruptions, meter, hidden tab buffer.** (medium) Fixed: An iPad, whose Safari calls itself a Mac, is now told by its touch screen and gets the lock-screen path; a call or another app taking the sound is followed by a resume when it is given back, or when the tab comes back into view; the lock-screen audio element restarts if the system pauses it; the meter stays wired on the fallback path; and a hidden tab keeps more than a minute queued, so a browser that wakes it once a minute never lets it run dry. The hidden-tab buffer is tested in Chromium (13.8 s in view, 80 s hidden); the Apple paths wait on a real iPhone (brief, section 8). (206b3ce)

**C43. Station chart, harbour merge and debug hook small defects.** (low) Fixed: Remembered harbours are checked for shape, this build's first, and capped at twenty-four; the chart keeps to the embedded set's stations, loads its map once however often the list redraws, and its dots answer Space as well as Enter; the debug tap makes one stream, not one per call, and returns nothing before the sound starts. (206b3ce)

**A4. `walk` gives up after 400,000 steps, so short tracks mean dead air late in the week.** (medium) Fixed: A walk now passes over whole rounds by arithmetic wherever no bell has to be kept: at the start of a round, every round that fits before the asked moment and before any of its tracks comes on or goes off the air is skipped at once, under a programme's modes and slots and under the old rota's whole-library shuffle. A round's length does not depend on its order, so nothing changes but the work: a test compares every mode against a clock that walks every track, at a moment every seven minutes across eight days with a track added and one withdrawn mid-week, and they agree. The step cap also now covers a week of the shortest recordings allowed, for the walks that keep a bell; a station of 1.5-second jingles plays to the end of Sunday, tested. (3b09737)

**A5. Fall-back hour: Daily and Weekly tapes rewind, slots drop out.** (medium) Fixed: Runs and tapes are read in UTC. A slot's or the hours' run is the one whose local start came latest (its first time round) and still has real minutes left, so a run lasts its length in real time; a daily or weekly tape, and the week's own start, take the latest of their local anchors to have come by the moment asked. The repeated hour now continues the tape and keeps the slot, and the page lists the run as it airs. Tested on Chicago's autumn change (the test fails on the old clock). (da3ec1d)

**A6. `upcoming()` (watch bill and the page's "next") ignores every cut.** (medium) Fixed: The watch bill now cuts each recording wherever the air changes hands: at every show, slot and on-air run boundary, every tape restart and every turn of the week, and the old rota's blocks; a recording that resumes after a cut is listed from where it resumes, and one that carries on across a cut that changed nothing stays one piece. Tested: every piece of a bill with a slot and on-air hours is what the air plays at its middle, pieces never overlap, the slot and the resumed recording are listed at their real times, and nothing runs past the end of the hours (the test fails on the old clock). (2d07732)

**A8. A show premiering before its track was added never airs, and the listing still promises it.** (medium) Fixed: A show's recordings are judged on the air as of its start or the moment it was put on the bill, whichever is later, the same in its length and in its walk; a premiere set for this minute of a recording added seconds ago airs it, and a show with nothing it can play and no live part is not listed. Tested (the test fails on the old clock). (8060919)

**A9. Call signs carry ~35 bits, so a lookalike can be ground out for a target.** (medium) Fixed: Call signs stay as drawn, since changing the draw would rename every station on the air, but they are no longer claimed as proof: the code and the Articles say a forger can grind out a lookalike, and each station's page, in the app and the tab, now shows its key in groups of four, selectable, beside the call sign. (c327e39)

**A11. `ChunkDecoder::decode` trusts the chunk's packet count and sizes. `core/src/audio.rs:166-174; archive.rs `Chunk::check** (low) Fixed: Each packet is played as one 20 ms frame: one that is empty, or holds more or less than a frame, stands as 20 ms of concealment, in the node and in the tab; and where a chunk's frame count is known (the phone's player, the Lantern's tower and episodes) a chunk whose packets do not number its frames is concealed for its length. A chunk always plays exactly as long as its station's clock says. (c327e39)

**A12. Ogg writer can overflow the lacing byte and drops bad chunks silently.** (low) Fixed: The tape writer fills each Ogg page by lacing segments, never past 255; it refuses, with a plain reason, a channel count other than one or two, a chunk that will not read, a packet that is not one 20 ms frame, and an empty tape, instead of writing a file that will not play. Tested, with ffprobe reading the file when it is installed. (c327e39)

**A14. `span_from` truncates `days` and accepts a span that never runs.** (low) Fixed: A span's days are masked before they are narrowed, and a span that names no day is refused with a word, so a station cannot be left dark by an hours list that never runs. Tested. (c327e39)

**A15. Hours plus a continuous mode silently skips what plays off the air.** (low) Fixed: With set hours, Shuffle, In order and Newest first now keep their clock running only while the station is on the air, so a library in order is heard in order across the days and nothing plays unheard while the station is off. Tested: twenty minutes a day of three twenty-minute recordings plays one a day, in order (the test fails on the old clock). (c327e39)

**A17. `art::accent` depends on HashMap iteration order for ties.** (low) Fixed: Ties between colours of equal weight go to the larger bucket key, so the same picture gives the same accent every time. Tested. (244c02d)

**A18. `art::prepare` ignores EXIF orientation.** (low) Fixed: A picture is turned the way its EXIF note says before it is redrawn, so a portrait phone photo comes out upright. Tested with a sideways JPEG (the test fails without the turn). (244c02d)

**A19. Ingest folds multichannel files badly.** (low) Fixed: More than two channels are folded by their places (centre and surrounds at -3 dB, the LFE left out), scaled so the fold cannot clip, with the loudness pass bringing it back to the house level; mono is the middle of that fold. A decoder reporting no channels is passed over rather than crashing, and a file of nothing but silence is refused. Tested with a 5.1 WAV whose only sound is its centre channel, and a silent one. (244c02d)

**A20. Hard seams at the week boundary (and at every anchor).** (low) Fixed: Holds by design, now ruled in the Articles: each week, slot and tape starts clean on its minute, so any node can work out any moment from that week alone. Letting the recording at the turn finish would make every week start where the one before it happened to end, and so depend on all the weeks before; the cut once a week is the price of a schedule nobody has to agree on. (244c02d)

**A21. Offset table ends: time zone freezes after the last entry.** (low) Fixed: The page now says where the station's time-zone table ends (zone_until), and the programme editor warns the keeper when it ends within two years. The app writes forty years of changes each time the programme is set, so a station set from a phone holds for decades; one set some other way is told. (244c02d)

**A23. Output and input streams ignore the device's sample format.** (low) Fixed: The speaker and microphone streams are built in whatever sample format the device asks for (float, 16-bit, unsigned 16-bit or 32-bit), converted at the edge, and a queue left poisoned elsewhere still plays rather than panicking the sound thread; a microphone reporting no channels is refused plainly. (244c02d)

**A24. `page_of` days overflow and repeated full-log hashing.** (low) Fixed: A page's window is at most sixty days and cannot overflow, and each track's words and each show's list are found once per page instead of by hashing the whole log again for every line. (244c02d)

**B18. Distribution: a release cut short is offered as it is, and one key named twice counts twice.** The in-network update was checked against its signed hash only when first assembled, in memory, and written in one go, so a file cut short by a closed app stayed in place and went to the installer next time unchecked (Android's own signature check stands behind it, but the app should never offer a broken file). Two signatures were counted by their place in the key list, so a list naming one key twice would let one key pass for two. Holds in part. Fixed: a release is written piece by piece while it is hashed, under a .part name, renamed only once it matches its signed hash, and checked again whenever it is found already on disk; older releases fetched before are cleared once a newer one is aboard. Signatures are counted by key, so one key named twice is still one key. Tested: two signatures by one key fail, two keys pass, and a signature for another build fails. (9a6a4ba)

**A25. feed2folder can hang or fill a Lantern's disk, and one missing episode ends the run.** Episodes were fetched with no timeout and no size limit, under a user agent naming the tool, and the first episode that failed (a 404) stopped the whole feed. Holds. Fixed: each episode is read with a minute's patience per read and a gigabyte at most, under a plain client name; a failed episode is skipped with a word and its part file removed, and the rest of the feed carries on. Tested against a local feed with one good episode and one missing. (1679833)
