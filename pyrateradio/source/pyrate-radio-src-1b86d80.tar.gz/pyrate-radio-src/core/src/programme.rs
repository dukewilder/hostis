//! The programme: when a station is on the air and what fills each hour, in the station's
//! own local time.
//!
//! A station keeps playing by itself for as long as anyone carries it, so the programme is
//! written once and holds for decades. Its time zone travels as a table of offsets the
//! keeper's device works out ahead, daylight saving included, and every node reads the
//! same table, so "six in the evening" stays six in the evening in the keeper's town.
//!
//! No rights reserved.

use serde::{Deserialize, Serialize};

use crate::Hash;

pub const DAY_MIN: i64 = 1440;
pub const WEEK_MIN: i64 = 7 * DAY_MIN;

/// A station's time zone, as offsets from UTC.
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct Zone {
    /// For people: "America/Chicago". Empty is UTC.
    pub name: String,
    /// Minutes east of UTC, each from a moment on, oldest first.
    pub offsets: Vec<(u64, i16)>,
}

impl Zone {
    pub fn utc() -> Self {
        Self::default()
    }

    pub fn offset_min(&self, t_ms: u64) -> i64 {
        let mut off = self.offsets.first().map(|o| o.1).unwrap_or(0);
        for (from, o) in &self.offsets {
            if *from <= t_ms {
                off = *o;
            } else {
                break;
            }
        }
        off as i64
    }

    /// Local minutes since 1970-01-01 00:00 in this zone.
    pub fn local_min(&self, t_ms: u64) -> i64 {
        (t_ms / 60_000) as i64 + self.offset_min(t_ms)
    }

    /// The moment a local minute begins. A minute the clocks skipped (the hour lost in spring)
    /// begins when the clocks changed; a minute that came twice (the hour gained in autumn)
    /// begins the first time. The same rule east and west of UTC.
    pub fn utc_ms(&self, local_min: i64) -> u64 {
        let at = |m: i64| (m.max(0) as u64).saturating_mul(60_000);
        // Every offset in force within a day either side is a candidate.
        let mut offs: Vec<i64> = [-24 * 60i64, 0, 24 * 60].iter().map(|d| self.offset_min(at(local_min + d))).collect();
        offs.sort_unstable();
        offs.dedup();
        let cands: Vec<u64> = offs.iter().map(|o| at(local_min - o)).collect();
        if let Some(first) = cands.iter().copied().filter(|u| self.local_min(*u) == local_min).min() {
            return first;
        }
        // Skipped: the change itself, the first table entry between the candidates.
        let (lo, hi) = (cands.iter().copied().min().unwrap_or(0), cands.iter().copied().max().unwrap_or(0));
        self.offsets.iter().map(|(from, _)| *from).find(|f| *f > lo && *f <= hi).unwrap_or(hi)
    }

    /// The run of `span` in force at `t`: when it began, in UTC, and its local start. A run
    /// lasts its length in real minutes from the first time its local start comes round, so
    /// the hour the clocks repeat neither cuts it short nor plays it twice, and the page and
    /// the air agree on it.
    pub fn run_at(&self, span: &Span, t: u64) -> Option<(u64, i64)> {
        if span.len_min == 0 {
            return None;
        }
        let lm = self.local_min(t);
        let len = span.len_min as i64;
        let mut best: Option<(u64, i64)> = None;
        for s in span.starts_between(lm - len - 2 * DAY_MIN, lm + 2 * DAY_MIN) {
            let u = self.utc_ms(s);
            if u <= t && t < u.saturating_add(len as u64 * 60_000) && best.is_none_or(|b| u > b.0) {
                best = Some((u, s));
            }
        }
        best
    }

    /// Of the local anchors `base` and one `step` either side, the latest whose moment has
    /// come by `t`: where a tape that restarts every day or week stands, read in UTC so a
    /// repeated hour does not rewind it.
    pub fn anchor_at(&self, base: i64, step: i64, t: u64) -> i64 {
        [base + step, base, base - step, base - 2 * step].into_iter().find(|a| self.utc_ms(*a) <= t).unwrap_or(base - 2 * step)
    }

    /// The local minute at which the week holding `lm` began: Monday 00:00.
    pub fn week_origin(lm: i64) -> i64 {
        // 1970-01-01 was a Thursday, day 3 of a Monday week.
        let dow = (lm.div_euclid(DAY_MIN) + 3).rem_euclid(7);
        lm - dow * DAY_MIN - lm.rem_euclid(DAY_MIN)
    }
}

/// A stretch of the week that repeats: days, a local starting time and a length.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct Span {
    /// Bit 0 is Monday, bit 6 is Sunday. 0x7f is every day.
    pub days: u8,
    /// Local minute of the day it starts.
    pub start_min: u16,
    /// Minutes it runs. It may run past midnight.
    pub len_min: u16,
}

impl Span {
    pub fn every_day(start_min: u16, len_min: u16) -> Self {
        Self { days: 0x7f, start_min, len_min }
    }

    /// If a run covers local minute `lm`, the local minute that run began.
    pub fn run_start(&self, lm: i64) -> Option<i64> {
        if self.len_min == 0 {
            return None;
        }
        let origin = Zone::week_origin(lm);
        let mut best: Option<i64> = None;
        for back in [0i64, 1] {
            for d in 0..7i64 {
                if self.days & (1 << d) == 0 {
                    continue;
                }
                let s = origin - back * WEEK_MIN + d * DAY_MIN + self.start_min as i64;
                if s <= lm && lm < s + self.len_min as i64 && best.is_none_or(|b| s > b) {
                    best = Some(s);
                }
            }
        }
        best
    }

    /// Runs that begin in [from, until), as local minutes.
    pub fn starts_between(&self, from: i64, until: i64) -> Vec<i64> {
        let mut out = Vec::new();
        let mut origin = Zone::week_origin(from) - WEEK_MIN;
        while origin < until {
            for d in 0..7i64 {
                if self.days & (1 << d) == 0 {
                    continue;
                }
                let s = origin + d * DAY_MIN + self.start_min as i64;
                if s + self.len_min as i64 > from && s < until {
                    out.push(s);
                }
            }
            origin += WEEK_MIN;
        }
        out.sort();
        out.dedup();
        out
    }
}

/// How the library fills the hours no slot has taken.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub enum Mode {
    /// Every track once a round, in a dealt order, before any plays twice.
    Shuffle,
    /// The library in the order it was added, round and round, from the top each Monday.
    InOrder,
    /// Newest first, round and round, from the top each Monday. For podcasts.
    NewestFirst,
    /// In order, from the top every day at this local minute. A day's tape.
    Daily { start_min: u16 },
    /// In order, from the top every week at this local day (0 Monday) and minute.
    Weekly { day: u8, start_min: u16 },
}

/// What plays in a slot.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub enum Fill {
    /// The whole library, shuffled for each run.
    Library,
    /// Chosen tracks, in this order or shuffled.
    Tracks { tracks: Vec<Hash>, shuffle: bool },
    /// What one hand added: a watch kept by that hand.
    Hand { key: [u8; 32] },
    /// The newest so many tracks, newest first.
    Newest { count: u16 },
}

/// A regular slot: a show, a watch, or the hour the keeper goes live.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct Slot {
    pub title: String,
    pub about: String,
    pub span: Span,
    pub fill: Fill,
    /// The keeper means to be live in this slot. When they are not, the fill plays.
    pub live: bool,
}

/// When the station is on the air and what fills each hour. The latest one rules.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct Programme {
    pub zone: Zone,
    pub mode: Mode,
    /// When the station is on the air. Empty: always. Slots are on the air whatever this says.
    pub hours: Vec<Span>,
    /// Checked in order; the first covering a moment has it.
    pub slots: Vec<Slot>,
    /// A recording played on the bell.
    pub ident: Option<Hash>,
    pub ident_every_min: u16,
}

impl Default for Programme {
    fn default() -> Self {
        Self { zone: Zone::utc(), mode: Mode::Shuffle, hours: Vec::new(), slots: Vec::new(), ident: None, ident_every_min: 30 }
    }
}

impl Programme {
    /// Whether the station is on the air at `t`, by its hours or a slot, each run read in UTC.
    pub fn on_air_at(&self, t: u64) -> bool {
        self.hours.is_empty() || self.hours.iter().chain(self.slots.iter().map(|s| &s.span)).any(|h| self.zone.run_at(h, t).is_some())
    }

    /// Whether the station is on the air at local minute `lm`, by its hours or a slot.
    pub fn on_air(&self, lm: i64) -> bool {
        self.hours.is_empty() || self.hours.iter().any(|h| h.run_start(lm).is_some()) || self.slots.iter().any(|s| s.span.run_start(lm).is_some())
    }
}
